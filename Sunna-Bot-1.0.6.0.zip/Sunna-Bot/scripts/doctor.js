const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');
const { loadConfig } = require('../core/config');
const { loadCommands } = require('../core/commandLoader');
const { loadEvents } = require('../core/eventLoader');

(async () => {
  const root = path.resolve(__dirname, '..');
  console.log('Sunna Bot doctor');
  console.log(`[OK] Node ${process.versions.node}`);
  const commands = loadCommands(root);
  const events = loadEvents(root);
  console.log(`[OK] Commands: ${new Set([...commands.values()].map(command => command.name)).size}`);
  console.log(`[OK] Events: ${events.length}`);
  console.log('[OK] Canvas: removed');
  const loaded = await loadConfig(root);
  console.log(`[OK] Configuration: ${loaded.config.version}`);
  const ai = loaded.config.ai;
  const keys = [loaded.credentials.geminiApiKey, loaded.credentials.groqApiKey].filter(value => value).length;
  console.log(`[OK] AI rooms: ${ai.chatGroupIds.length}`);
  console.log(`[INFO] AI keys configured: ${keys}/2`);
  const ffmpeg = childProcess.spawnSync('ffmpeg', ['-version'], { stdio: 'ignore' });
  console.log(ffmpeg.status === 0 ? '[OK] FFmpeg available' : '[WARN] FFmpeg not found; non-MP3 YouTube sources need it.');
  for (const file of ['config/appstate.json', 'config/admins.json', 'config/groups.json']) {
    if (!fs.existsSync(path.join(root, file))) throw new Error(`${file} غير موجود.`);
  }
  console.log('[OK] Structure and configuration checks passed.');
})().catch(error => {
  console.error(`[FAIL] ${error.message || error}`);
  process.exit(1);
});
