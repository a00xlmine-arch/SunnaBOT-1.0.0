const assert = require('assert');
const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');
const root = path.resolve(__dirname, '..');

function jsFiles(dir) {
  return fs.readdirSync(path.join(root, dir))
    .filter(file => file.endsWith('.js'))
    .map(file => path.join(root, dir, file));
}

function verifySyntax() {
  const dirs = ['core', 'commands', 'events', 'services', 'games', 'database', 'utils', 'scripts', 'tests'];
  const files = dirs.flatMap(jsFiles);
  for (const file of files) childProcess.execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });
  return files.length;
}

function readJson(rel) { return JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8')); }

const pkg = readJson('package.json');
assert.strictEqual(pkg.version, '1.0.6');
assert.ok(!fs.existsSync(path.join(root, 'canvas')));
assert.ok(pkg.dependencies['@google/genai']);
assert.ok(pkg.dependencies['groq-sdk']);
const cfg = readJson('config/config.json');
assert.ok(Array.isArray(cfg.ai.chatGroupIds));
assert.strictEqual(cfg.ai.geminiModel, 'gemini-3.8-flash');
assert.strictEqual(cfg.ai.groqModel, 'openai/gpt-oss-20b');
const example = readJson('config/secrets.example.json');
for (const key of ['puterAuthToken', 'geminiApiKey', 'groqApiKey']) assert.strictEqual(typeof example[key], 'string');

const syntaxCount = verifySyntax();
require('./structure');
console.log(`Verification passed: ${syntaxCount} JavaScript files parsed, AI configuration verified, Canvas removed.`);
