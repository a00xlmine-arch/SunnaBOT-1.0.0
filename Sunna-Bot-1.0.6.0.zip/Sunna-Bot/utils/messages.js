function cleanLines(lines) {
  return (Array.isArray(lines) ? lines : [lines])
    .map(line => String(line ?? '').trimEnd())
    .filter((line, index, arr) => !(line === '' && index === arr.length - 1));
}

function box(title, lines = []) {
  const heading = String(title ?? '').trim();
  return [heading, '', ...cleanLines(lines)].join('\n').trim();
}

function mainMenu() {
  return [
    '⟡ سونا ⟡',
    '',
    'الصور',
    '◇ صورة',
    '◇ بنترست',
    '',
    'الترفيه',
    '◇ الحب',
    '◇ حجر ورق مقص',
    '◇ التخمين',
    '◇ XO',
    '',
    'الموسيقى',
    '◇ اغنية',
    '',
    'المستوى',
    '◇ مستواي',
    '◇ المتصدرون',
    '',
    'الصلاة',
    '◇ مواقيت الصلاة',
    '',
    'النظام',
    '◇ معلومات',
    '◇ استجابة',
    '',
    'الادارة',
    '◇ تفعيل',
    '◇ تعطيل',
    '◇ قفل الصورة',
    '',
    '.مساعدة'
  ].join('\n');
}

function error(message = 'تعذر تنفيذ الطلب حاليا.') { return String(message).trim(); }

function trimText(text, max = 1800) {
  const value = String(text ?? '').trim();
  return value.length <= max ? value : `${value.slice(0, Math.max(1, max - 1))}…`;
}

function helpPrompt() { return 'لرؤية قائمة اوامر سونا ارسل help'; }

function loveResult({ firstName, secondName, score, verdict }) {
  const first = String(firstName || 'الاول');
  const second = String(secondName || 'الثاني');
  const pair = `\u2068${first} × ${second}\u2069`;
  return [
    '💗 اختبار الحب',
    '',
    pair,
    '',
    `الحب: ${score.love}%`,
    `التوافق: ${score.compatibility}%`,
    `الترابط: ${score.bond}%`,
    '',
    `التقييم: ${verdict}`
  ].join('\n');
}

module.exports = { box, mainMenu, error, trimText, helpPrompt, loveResult };
