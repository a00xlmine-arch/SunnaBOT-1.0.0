const assert = require('assert');
const path = require('path');
const fs = require('fs');
const Module = require('module');

const root = path.resolve(__dirname, '..');
const tempData = path.join(root, 'tmp-ai-test');
fs.mkdirSync(tempData, { recursive: true });
const realLoad = Module._load;
const calls = [];
let geminiFail = false;

const fakeGoogle = {
  GoogleGenAI: class {
    constructor(options) { assert.strictEqual(options.apiKey, 'gemini-key'); }
    interactions = {
      create: async options => {
        assert.strictEqual(options.model, 'gemini-test');
        assert.ok(options.system_instruction.includes('اسمك سونا'));
        assert.strictEqual(typeof options.input, 'string');
        assert.ok(options.input.includes('مرحبا سونا'));
        calls.push({ provider: 'gemini', input: options.input });
        if (geminiFail) throw new Error('Gemini unavailable');
        return { output_text: 'رد Gemini طبيعي.' };
      }
    };
  }
};

class FakeGroq {
  constructor(options) { assert.strictEqual(options.apiKey, 'groq-key'); }
  chat = { completions: { create: async options => {
    calls.push({ provider: 'groq', model: options.model, messages: options.messages });
    return { choices: [{ message: { content: 'رد Groq طبيعي.' } }], model: options.model };
  } } };
}

Module._load = function(request, parent, isMain) {
  if (request === 'fs-extra') {
    return {
      readFile: (...args) => fs.promises.readFile(...args),
      writeFile: (...args) => fs.promises.writeFile(...args),
      ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
      remove: async file => fs.promises.rm(file, { recursive: true, force: true }),
      readJson: async file => JSON.parse(await fs.promises.readFile(file, 'utf8')),
      writeJson: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
      rename: async (src, dest) => fs.promises.rename(src, dest),
      writeJsonAtomic: async (file, value) => { await fs.promises.mkdir(path.dirname(file), { recursive: true }); const tmp = `${file}.tmp`; await fs.promises.writeFile(tmp, JSON.stringify(value, null, 2)); await fs.promises.rename(tmp, file); },
      rename: async (src, dest) => fs.promises.rename(src, dest),
    };
  }
  if (request === '@google/genai') return fakeGoogle;
  if (request === 'groq-sdk') return FakeGroq;
  return realLoad.call(this, request, parent, isMain);
};

(async () => {
  try {
    const AIService = require('../services/ai');
    const service = new AIService({
      root: tempData,
      config: {
        prefix: '.',
        message: { maxLength: 1800 },
        ai: {
          enabled: true,
          provider: 'gemini',
          chatGroupIds: ['g1'],
          geminiModel: 'gemini-test',
          groqModel: 'groq-test',
          maxHistory: 12,
          maxOutputTokens: 100,
          temperature: 0.9,
          cooldownMs: 0
        }
      },
      credentials: { geminiApiKey: 'gemini-key', groqApiKey: 'groq-key' },
      profile: { getUser: async uid => ({ name: `User ${uid}` }) },
      messenger: { sendMessage: async (text, threadID) => { calls.push({ provider: 'messenger', text, threadID }); } },
      logger: { warn() {} }
    });

    await service.load();
    assert.strictEqual(service.isRoom('g1'), true);
    const handled = await service.handle({ threadID: 'g1', senderID: 'u1', body: 'مرحبا سونا' });
    assert.strictEqual(handled, true);
    assert.ok(calls.some(call => call.provider === 'gemini'));
    assert.ok(calls.some(call => call.provider === 'messenger' && call.text === 'رد Gemini طبيعي.'));

    service.bot.config.ai.provider = 'groq';
    service.bot.credentials.geminiApiKey = '';
    await service.handle({ threadID: 'g1', senderID: 'u2', body: 'اهلا' });
    assert.ok(calls.some(call => call.provider === 'messenger' && call.text === 'رد Groq طبيعي.'));

    geminiFail = true;
    service.bot.config.ai.provider = 'auto';
    service.bot.credentials.geminiApiKey = 'gemini-key';
    await service.handle({ threadID: 'g1', senderID: 'u3', body: 'هل انت هنا؟' });
    assert.ok(calls.some(call => call.provider === 'gemini'));
    assert.ok(calls.some(call => call.provider === 'groq'));
    assert.ok(calls.some(call => call.provider === 'messenger' && call.text === 'رد Groq طبيعي.'));

    console.log('AI configuration, shared personality, Gemini path, Groq path, and Gemini-to-Groq fallback smoke tests passed.');
  } finally {
    Module._load = realLoad;
    fs.rmSync(tempData, { recursive: true, force: true });
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
