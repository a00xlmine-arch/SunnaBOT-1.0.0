const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/files');
const prayer = require('./prayer');

function nowParts(timeZone) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());
  return Object.fromEntries(parts.filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
}

class Scheduler {
  constructor(bot) {
    this.bot = bot;
    this.timer = null;
    this.stateFile = path.join(bot.root, 'data/scheduleState.json');
    this.state = {};
  }

  async load() {
    this.state = await readJson(this.stateFile, {});
    return this;
  }

  async save() { await writeJsonAtomic(this.stateFile, this.state); }

  async start() {
    await this.load();
    if (this.timer) return;
    this.timer = setInterval(() => this.tick().catch(err => this.bot.logger.error({ err }, 'scheduler tick failed')), 20_000);
    this.timer.unref?.();
    await this.tick();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async tick() {
    const tz = this.bot.config.timezone || 'Asia/Riyadh';
    const p = nowParts(tz);
    const date = `${p.year}-${p.month}-${p.day}`;
    const hm = `${p.hour}:${p.minute}`;

    await this.simpleSchedule(date, hm, 'morning', 'صباح الخير جميعا.\n\nنتمنى لكم يوما جميلا وهادئا.');
    await this.simpleSchedule(date, hm, 'night', 'تصبحون على خير جميعا.\n\nنتمنى لكم ليلة هادئة.');
    if (this.bot.config.schedules?.prayerReminders !== false) {
      try {
        await this.prayerTick(date, hm);
      } catch (error) {
        this.bot.logger.warn({ err: error }, 'prayer scheduler failed');
      }
    }
  }

  async simpleSchedule(date, hm, key, message) {
    const target = this.bot.config.schedules?.[key];
    if (target !== hm) return;
    let changed = false;
    for (const threadID of this.bot.groupAccess.data.allowedThreadIds.map(String)) {
      const stateKey = `${date}:${key}:${threadID}`;
      if (this.state[stateKey]) continue;
      try {
        await this.bot.messenger.sendMessage(message, threadID);
        this.state[stateKey] = true;
        changed = true;
      } catch (error) {
        this.bot.logger.warn({ err: error, threadID, key }, 'scheduled message failed');
      }
    }
    if (changed) await this.save();
  }

  async prayerTick(date, hm) {
    const timings = await prayer.getToday();
    let changed = false;
    for (const [key, time] of Object.entries(timings)) {
      if (!/^\d{2}:\d{2}$/.test(time) || time !== hm) continue;
      const name = prayer.NAMES[key] || key;
      for (const threadID of this.bot.groupAccess.data.allowedThreadIds.map(String)) {
        const stateKey = `${date}:prayer:${key}:${threadID}`;
        if (this.state[stateKey]) continue;
        try {
          await this.bot.messenger.sendMessage(`حان وقت صلاة ${name}.\nبتوقيت مكة المكرمة.`, threadID);
          this.state[stateKey] = true;
          changed = true;
        } catch (error) {
          this.bot.logger.warn({ err: error, threadID, key }, 'prayer reminder failed');
        }
      }
    }
    if (changed) await this.save();
  }
}

module.exports = Scheduler;
