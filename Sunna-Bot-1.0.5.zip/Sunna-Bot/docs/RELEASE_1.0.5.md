# Sunna Bot 1.0.5

Release focus: media reliability, Arabic presentation, reply-based interactions, and Termux-safe temporary files.

## Media
- Pinterest now prefers metadata relevance over raw image variance.
- Low-information gradient/placeholder candidates are penalized.
- Pinterest images are validated and normalized to PNG before Messenger delivery.
- Song downloads are normalized to a real local MP3 and transcoded with FFmpeg when the provider returns another audio format.

## Messenger
- Avatar lookup supports the callback and Promise forms used by compatible Messenger adapters.
- Facebook profile pages are rejected as image sources.
- Automatic keyword replies use a real message reaction when the API supports it.

## Stability
- Temporary downloads can use the bot-local `tmp` directory, avoiding Termux `/tmp` permission problems.
- Arabic and English command aliases remain supported while the visible help menu stays Arabic.
