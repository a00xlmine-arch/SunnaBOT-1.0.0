# تثبيت Sunna Bot على Termux

## 1. تثبيت المتطلبات
```bash
pkg update -y
pkg install nodejs git unzip -y
node -v
npm -v
```

يجب ان يكون Node.js 24 او احدث.

## 2. جلب النسخة من GitHub
```bash
cd ~
git clone https://github.com/a00xlmine-arch/SunnaBOT-1.0.0.git SunnaBOT
cd SunnaBOT
unzip -o Sunna-Bot-1.0.5.zip
cd Sunna-Bot
```

## 3. اعداد الملفات المحلية
ضع AppState الحقيقي داخل `config/appstate.json`.
ضع UID الادمن داخل `config/admins.json`.
اضبط `config/groups.json` للمجموعات المسموحة.
ضع Puter token داخل `config/secrets.json` فقط عند استخدام `.image`.

لا ترفع `appstate.json` او `secrets.json` او ملفات الاعداد المحلية الى GitHub.

## 4. التثبيت والفحص
```bash
npm install
npm run verify:structure
npm test
npm run doctor
```

## 5. التشغيل
```bash
npm start
```
