# Migrate to Sunna Bot 1.0.3

The 1.0.3 patch does not overwrite appstate.json, admins.json, groups.json, or secrets.json.

After applying the patch and running `npm install`, run:

`node scripts/migrate-config-1.0.3.js`

Then run:

`npm test`
`npm run doctor`

Finally start the bot with `npm start`.
