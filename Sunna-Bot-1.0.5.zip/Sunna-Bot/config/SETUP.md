# اعداد Sunna Bot

ضع بيانات Messenger المحلية في `appstate.json`، ومعرفات الادمن في `admins.json`، ومعرفات المجموعات المسموح بها في `groups.json`.

ضع Puter Auth Token في `secrets.json` فقط اذا كنت ستستخدم `.image`.

لا ترفع الملفات الفعلية الى GitHub. القوالب الآمنة هي ملفات `*.example.json`.
