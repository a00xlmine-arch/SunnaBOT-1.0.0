# Sunna Bot 1.0.5

Sunna Bot is a modular Facebook Messenger group bot built around `@lazyneoaz/metachat`.

## Highlights

- English canonical commands with Arabic aliases.
- Arabic command menu with compact RTL-friendly formatting.
- Five-result song search with reply-based selection, verified MP3 output, and callback/promise-safe Messenger delivery.
- Pinterest image search with metadata-aware relevance ranking, image validation, and PNG normalization before delivery.
- Two-avatar Love cards using the real account images when Messenger exposes them.
- Canvas effects with Arabic and English effect names.
- XO, RPS and Guess reply-based games.
- Makkah prayer times and Makkah-time reminders.
- 08:00 morning and 23:00 night messages in `Asia/Riyadh`.
- Bot-keyword auto reaction with `✨️`.
- Group photo lock with `lockphoto on/off` for Bot Admins.

## Developer

Rin Il

## Security

Never commit `config/appstate.json`, `config/secrets.json`, `config/admins.json`, or `config/groups.json`.
Keep the real configuration files local. Use the `.example.json` files for repository templates.

## Termux

Install Node.js 24+ and FFmpeg:

```bash
pkg install nodejs ffmpeg -y
npm install
npm test
npm run doctor
npm start
```
