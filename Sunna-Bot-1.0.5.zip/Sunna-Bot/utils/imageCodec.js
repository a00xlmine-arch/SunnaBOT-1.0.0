let jimpPromise = null;

async function getJimp() {
  if (!jimpPromise) {
    jimpPromise = (async () => {
      const { createJimp } = require('@jimp/core');
      const { defaultFormats, defaultPlugins } = require('jimp');
      const webpModule = await import('@jimp/wasm-webp');
      const webp = webpModule.default || webpModule;
      return createJimp({
        formats: [...defaultFormats, webp],
        plugins: defaultPlugins
      });
    })();
  }
  return jimpPromise;
}

module.exports = { getJimp };
