const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const os = require('os');

const CONTENT_EXTENSIONS = new Map([
  ['image/jpeg', 'jpg'], ['image/jpg', 'jpg'], ['image/png', 'png'], ['image/gif', 'gif'],
  ['image/webp', 'webp'], ['image/bmp', 'bmp'], ['image/tiff', 'tiff'],
  ['audio/mpeg', 'mp3'], ['audio/mp3', 'mp3'], ['audio/webm', 'webm'], ['audio/ogg', 'ogg'],
  ['audio/mp4', 'm4a'], ['audio/x-m4a', 'm4a'], ['audio/wav', 'wav'], ['audio/x-wav', 'wav']
]);

function tempFile(prefix, ext = '', baseDir = process.env.SUNNA_TMP_DIR || os.tmpdir()) {
  const safeExt = ext ? (ext.startsWith('.') ? ext : `.${ext}`) : '';
  return path.join(baseDir, `sunna-${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${safeExt}`);
}

function extensionFromContentType(contentType = '') {
  return CONTENT_EXTENSIONS.get(String(contentType).split(';')[0].trim().toLowerCase()) || null;
}

function extensionFromUrl(url = '') {
  try {
    const pathname = new URL(url).pathname;
    const match = pathname.match(/\.([a-z0-9]{2,5})$/i);
    return match ? match[1].toLowerCase() : null;
  } catch (_) {
    return null;
  }
}

function sniffImageExtension(buffer) {
  if (!Buffer.isBuffer(buffer)) return null;
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpg';
  if (buffer.length >= 8 && buffer.readUInt32BE(0) === 0x89504e47 && buffer.readUInt32BE(4) === 0x0d0a1a0a) return 'png';
  if (buffer.length >= 6 && /^GIF8[79]a$/.test(buffer.toString('ascii', 0, 6))) return 'gif';
  if (buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (buffer.length >= 2 && buffer[0] === 0x42 && buffer[1] === 0x4d) return 'bmp';
  return null;
}

function sniffAudioExtension(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4) return null;
  if (buffer.subarray(0, 3).toString('ascii') === 'ID3') return 'mp3';
  if (buffer[0] === 0x4f && buffer[1] === 0x67 && buffer[2] === 0x67 && buffer[3] === 0x53) return 'ogg';
  if ((buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0)) return 'mp3';
  if (buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WAVE') return 'wav';
  if (buffer.length >= 12 && buffer.subarray(4, 8).toString('ascii') === 'ftyp') return 'm4a';
  return null;
}

async function ensureExtension(filePath, ext) {
  if (!ext || !filePath) return filePath;
  const normalized = String(ext).replace(/^\./, '').toLowerCase();
  if (path.extname(filePath).toLowerCase() === `.${normalized}`) return filePath;
  const target = `${filePath.replace(/\.[^.\/]+$/, '')}.${normalized}`;
  if (target === filePath) return filePath;
  await fs.move(filePath, target, { overwrite: true });
  return target;
}

async function downloadUrl(url, options = {}) {
  const maxBytes = options.maxBytes ?? 20 * 1024 * 1024;
  const requestedExt = options.ext ? String(options.ext).replace(/^\./, '') : null;
  const tempDir = options.tempDir || process.env.SUNNA_TMP_DIR || os.tmpdir();
  let filePath = options.filePath || tempFile(options.prefix || 'download', requestedExt || 'bin', tempDir);
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer', timeout: options.timeoutMs ?? 30000,
      maxContentLength: maxBytes, maxBodyLength: maxBytes,
      maxRedirects: options.maxRedirects ?? 8,
      validateStatus: status => status >= 200 && status < 300,
      headers: {
        'User-Agent': options.userAgent || 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
        Accept: options.accept || '*/*', ...(options.headers || {})
      }
    });
    const buffer = Buffer.from(response.data);
    if (!buffer.length) throw new Error('تم استلام ملف فارغ.');
    if (buffer.length > maxBytes) throw new Error('الملف اكبر من الحد المسموح.');
    const contentType = String(response.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    const detectedExt = extensionFromContentType(contentType)
      || (options.kind === 'image' ? sniffImageExtension(buffer) : options.kind === 'audio' ? sniffAudioExtension(buffer) : null)
      || extensionFromUrl(url);
    if (options.kind === 'image' && !contentType.startsWith('image/') && !sniffImageExtension(buffer)) {
      throw new Error(`المصدر لم يرجع صورة صالحة (${contentType || 'نوع غير معروف'}).`);
    }
    if (options.kind === 'audio' && !contentType.startsWith('audio/') && !sniffAudioExtension(buffer)) {
      throw new Error(`المصدر لم يرجع صوتا صالحا (${contentType || 'نوع غير معروف'}).`);
    }
    if (!options.filePath && detectedExt) filePath = tempFile(options.prefix || 'download', detectedExt, tempDir);
    if (options.filePath && detectedExt) filePath = await ensureExtension(filePath, detectedExt);
    await fs.ensureDir(path.dirname(filePath));
    await fs.writeFile(filePath, buffer);
    return filePath;
  } catch (error) {
    await fs.remove(filePath).catch(() => {});
    throw error;
  }
}

async function downloadMedia(url, kind, options = {}) {
  const { downloadToTemp } = require('@hiudyy/ytdl');
  const media = await downloadToTemp({
    url: String(url), kind, tempDir: options.tempDir || os.tmpdir(), headers: options.headers
  });
  if (!media?.path) throw new Error('لم يتم استلام الملف.');
  if (options.maxBytes && media.size > options.maxBytes) {
    await media.cleanup?.().catch(() => {});
    throw new Error('الملف اكبر من الحد المسموح.');
  }

  let currentPath = media.path;
  try {
    const buffer = await fs.readFile(currentPath);
    const hinted = extensionFromContentType(media.contentType);
    const detected = kind === 'image' ? sniffImageExtension(buffer) : kind === 'audio' ? sniffAudioExtension(buffer) : null;
    const ext = hinted || detected;
    if (ext) currentPath = await ensureExtension(currentPath, ext);
    return {
      ...media,
      path: currentPath,
      cleanup: async () => {
        await media.cleanup?.().catch(() => {});
        if (currentPath !== media.path) await fs.remove(currentPath).catch(() => {});
      }
    };
  } catch (error) {
    await media.cleanup?.().catch(() => {});
    throw error;
  }
}

function streamFile(filePath) { return fs.createReadStream(filePath); }

module.exports = { tempFile, downloadUrl, downloadMedia, streamFile, extensionFromContentType, sniffImageExtension, sniffAudioExtension, ensureExtension };
