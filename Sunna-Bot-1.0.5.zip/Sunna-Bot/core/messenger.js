const fs = require('fs-extra');
const { login } = require('@lazyneoaz/metachat');
const { streamFile } = require('../utils/downloader');

function invokeApi(api, method, args = []) {
  const fn = api?.[method];
  if (typeof fn !== 'function') return Promise.reject(new Error(`metachat لا يوفر ${method}.`));

  // MetaChat exposes promise APIs, while some compatible Messenger adapters
  // still expose callback signatures. Support both without duplicating calls.
  if (fn.length > args.length) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const callback = (error, result) => {
        if (settled) return;
        settled = true;
        if (error) reject(error);
        else resolve(result);
      };
      try {
        const maybe = fn.call(api, ...args, callback);
        if (maybe && typeof maybe.then === 'function') {
          maybe.then(result => callback(null, result)).catch(callback);
        }
      } catch (error) {
        callback(error);
      }
    });
  }

  try {
    return Promise.resolve(fn.call(api, ...args));
  } catch (error) {
    return Promise.reject(error);
  }
}

class MessengerAdapter {
  constructor(root, credentials, logger) {
    this.root = root;
    this.credentials = credentials;
    this.logger = logger;
    this.api = null;
  }

  async login() {
    const appState = this.credentials.appState;
    if (!Array.isArray(appState) || !appState.length) {
      throw new Error('AppState غير موجود داخل config/appstate.json.');
    }
    this.api = await login({ appState }, {
      selfListen: false,
      selfListenEvent: false,
      listenEvents: true,
      autoListen: false,
      autoReconnect: true,
      autoReLogin: false,
      online: true
    });
    return this.api;
  }

  listen(callback) {
    if (!this.api || typeof this.api.listenMqtt !== 'function') {
      throw new Error('metachat لا يوفر listenMqtt في هذه النسخة.');
    }
    this.api.listenMqtt(callback);
  }

  async sendMessage(message, threadID) {
    if (!this.api) throw new Error('Messenger غير متصل.');
    return invokeApi(this.api, 'sendMessage', [message, String(threadID)]);
  }

  async sendFile(filePath, threadID, body = '') {
    if (!this.api) throw new Error('Messenger غير متصل.');
    if (!filePath || !fs.existsSync(filePath)) throw new Error('ملف المرفق غير موجود.');
    const attachment = streamFile(filePath);
    const payload = body ? { body: String(body), attachment } : { attachment };
    return this.sendMessage(payload, threadID);
  }

  async reactToMessage(messageID, reaction = '✨️') {
    if (!this.api || !messageID) return false;
    const methods = ['setMessageReaction', 'setMessageReactionMqtt'];
    for (const method of methods) {
      if (typeof this.api?.[method] !== 'function') continue;
      try {
        await invokeApi(this.api, method, [String(reaction), String(messageID)]);
        return true;
      } catch (error) {
        this.logger?.debug?.({ err: error, method }, 'message reaction failed');
      }
    }
    return false;
  }

  async deleteMessage(messageID) {
    if (!messageID || !this.api) return false;
    if (typeof this.api.unsendMessage === 'function') {
      await invokeApi(this.api, 'unsendMessage', [String(messageID)]);
      return true;
    }
    if (typeof this.api.deleteMessage === 'function') {
      await invokeApi(this.api, 'deleteMessage', [String(messageID)]);
      return true;
    }
    return false;
  }

  async getUserInfo(uid) {
    return invokeApi(this.api, 'getUserInfo', [String(uid)]);
  }

  async getThreadInfo(threadID) {
    return invokeApi(this.api, 'getThreadInfo', [String(threadID)]);
  }

  async getAvatarUrl(uid) {
    const methods = ['getAvatarUser', 'getUserAvatar', 'getUserAvatarUrl'];
    for (const method of methods) {
      if (typeof this.api?.[method] !== 'function') continue;
      try {
        const result = await invokeApi(this.api, method, [String(uid)]);
        if (typeof result === 'string') return result;
        if (result?.url) return result.url;
        if (result?.thumbSrc) return result.thumbSrc;
        if (result?.profilePictureUrl) return result.profilePictureUrl;
      } catch (error) {
        this.logger?.debug?.({ err: error, uid: String(uid), method }, 'avatar lookup failed');
      }
    }
    return null;
  }

  async getProfilePicture(uid) {
    if (typeof this.api?.getProfilePicture !== 'function') return null;
    return invokeApi(this.api, 'getProfilePicture', [String(uid)]);
  }

  async changeGroupImage(filePath, threadID) {
    if (!this.api) throw new Error('Messenger غير متصل.');
    const method = typeof this.api.changeGroupImage === 'function'
      ? 'changeGroupImage'
      : typeof this.api.changeThreadImage === 'function'
        ? 'changeThreadImage'
        : null;
    if (!method) {
      throw new Error('هذه النسخة من MetaChat لا توفر API لتغيير صورة المجموعة.');
    }
    return invokeApi(this.api, method, [fs.createReadStream(filePath), String(threadID)]);
  }

  getCurrentUserId() {
    if (typeof this.api?.getCurrentUserID === 'function') return String(this.api.getCurrentUserID());
    if (this.api?.ctx?.userID) return String(this.api.ctx.userID);
    return null;
  }
}

module.exports = MessengerAdapter;
module.exports.invokeApi = invokeApi;
