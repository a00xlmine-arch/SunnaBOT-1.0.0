const path = require('path');
const { readJson } = require('../utils/files');

async function loadConfig(root) {
  const config = await readJson(path.join(root, 'config/config.json'), null);
  const appState = await readJson(path.join(root, 'config/appstate.json'), null);
  const secrets = await readJson(path.join(root, 'config/secrets.json'), null);
  const admins = await readJson(path.join(root, 'config/admins.json'), null);
  const groups = await readJson(path.join(root, 'config/groups.json'), null);
  if (!config) throw new Error('config/config.json غير موجود.');
  if (!Array.isArray(appState) || appState.length === 0) throw new Error('config/appstate.json يجب ان يحتوي على AppState صالح.');
  if (!secrets || typeof secrets !== 'object') throw new Error('config/secrets.json غير موجود او غير صالح.');
  if (!admins || !Array.isArray(admins.adminIds) || admins.adminIds.length === 0) throw new Error('config/admins.json يجب ان يحتوي على adminIds.');
  if (!groups || !Array.isArray(groups.allowedThreadIds)) throw new Error('config/groups.json غير صالح.');
  config.version = '1.0.5';
  config.timezone = 'Asia/Riyadh';
  config.schedules = { ...(config.schedules || {}), morning: '08:00', night: '23:00', prayerReminders: true };
  config.prayer = { ...(config.prayer || {}), city: 'Makkah', country: 'Saudi Arabia', method: 4 };
  return { config, credentials: { appState, puterAuthToken: String(secrets.puterAuthToken || '') }, admins, groups };
}
module.exports = { loadConfig };
