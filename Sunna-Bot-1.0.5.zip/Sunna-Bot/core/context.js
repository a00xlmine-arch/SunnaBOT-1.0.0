function createContext({ bot, event, args, command }) {
  return {
    bot,
    event,
    api: bot.messenger.api,
    messenger: bot.messenger,
    command,
    commandName: event.commandName || command?.name,
    args,
    senderID: event.senderID,
    threadID: event.threadID,
    messageID: event.messageID,
    body: event.body,
    replyTarget: event.replyTarget,
    attachments: event.attachments || [],
    async reply(message) { return bot.messenger.sendMessage(String(message), event.threadID); },
    async sendImage(filePath, message = '') { return bot.messenger.sendFile(filePath, event.threadID, message); },
    async sendAudio(filePath, message = '') { return bot.messenger.sendFile(filePath, event.threadID, message); }
  };
}
module.exports = { createContext };
