const path = require('path');
const fs = require('fs-extra');
const { getJimp } = require('../utils/imageCodec');

async function normalizeToPng(inputPath, outputPath = null) {
  const Jimp = await getJimp();
  const image = await Jimp.read(inputPath);
  const pixels = image.bitmap.width * image.bitmap.height;
  if (!image.bitmap.width || !image.bitmap.height) throw new Error('الصورة غير صالحة.');
  if (pixels > 16_000_000) throw new Error('الصورة كبيرة جدا.');
  const target = outputPath || path.join(path.dirname(inputPath), `${path.basename(inputPath, path.extname(inputPath))}.png`);
  await image.write(target);
  return target;
}

async function normalizeAvatarPairToPng(aPath, bPath, root, prefix = 'love') {
  const dir = path.join(root, 'tmp');
  await fs.ensureDir(dir);
  const aOut = path.join(dir, `${prefix}-a-${Date.now()}-${process.pid}.png`);
  const bOut = path.join(dir, `${prefix}-b-${Date.now()}-${process.pid}.png`);
  return [await normalizeToPng(aPath, aOut), await normalizeToPng(bPath, bOut)];
}

async function cleanupFiles(paths) {
  for (const file of paths) {
    if (file) await fs.remove(file).catch(() => {});
  }
}

module.exports = { normalizeToPng, normalizeAvatarPairToPng, cleanupFiles };
