class ProfileService {
  constructor(messenger) {
    this.messenger = messenger;
    this.cache = new Map();
    this.ttl = 10 * 60 * 1000;
  }

  async getUser(uid) {
    const key = String(uid);
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now()) return cached.value;

    let raw = {};
    try {
      raw = await this.messenger.getUserInfo(key);
    } catch (_) {
      raw = {};
    }

    const value = raw?.[key] || raw?.[String(key)] || raw || {};
    let avatarUrl = extractAvatarUrl(value);

    if (!avatarUrl && typeof this.messenger.getAvatarUrl === 'function') {
      try {
        avatarUrl = extractAvatarUrl(await this.messenger.getAvatarUrl(key));
      } catch (_) {}
    }

    if (!avatarUrl && typeof this.messenger.getProfilePicture === 'function') {
      try {
        avatarUrl = extractAvatarUrl(await this.messenger.getProfilePicture(key));
      } catch (_) {}
    }

    const normalized = {
      uid: key,
      name: String(value.name || value.fullName || value.firstName || key),
      avatarUrl
    };
    this.cache.set(key, { value: normalized, expiresAt: Date.now() + this.ttl });
    return normalized;
  }

  invalidate(uid) { this.cache.delete(String(uid)); }
}

function extractAvatarUrl(value) {
  const found = findImageUrl(value, new Set());
  return found || null;
}

function findImageUrl(value, visited) {
  if (!value || typeof value === 'function') return null;
  if (typeof value === 'string') return isUsableImageUrl(value) ? value : null;
  if (typeof value !== 'object') return null;
  if (visited.has(value)) return null;
  visited.add(value);

  const priorityKeys = [
    'thumbSrc', 'profilePictureUrl', 'profilePicUrl', 'profilePic',
    'avatarUrl', 'avatar', 'picture', 'imageUrl', 'photoUrl', 'thumbnailUrl', 'src'
  ];

  for (const key of priorityKeys) {
    const result = findImageUrl(value[key], visited);
    if (result) return result;
  }

  for (const child of Object.values(value)) {
    const result = findImageUrl(child, visited);
    if (result) return result;
  }

  return null;
}

function isUsableImageUrl(value) {
  if (!value || typeof value !== 'string') return false;
  if (/^data:image\//i.test(value)) return true;
  if (!/^https?:\/\//i.test(value)) return false;
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    const full = `${url.pathname}${url.search}`.toLowerCase();
    if (full.includes('/profile.php')) return false;
    if (host === 'facebook.com' || host.endsWith('.facebook.com')) return false;
    const imagePath = /\.(?:jpe?g|png|gif|webp|bmp|avif)(?:$|\?)/i.test(full);
    const knownImageHost = /(?:fbcdn|fbsbx|scontent|pinimg)\./i.test(host);
    return imagePath || knownImageHost;
  } catch (_) {
    return false;
  }
}

module.exports = ProfileService;
module.exports.isUsableImageUrl = isUsableImageUrl;
module.exports.extractAvatarUrl = extractAvatarUrl;
