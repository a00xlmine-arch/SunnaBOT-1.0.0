const path = require('path');
const crypto = require('crypto');
const fs = require('fs-extra');
const { downloadUrl } = require('../utils/downloader');
const { getJimp } = require('../utils/imageCodec');

function pairSeed(a, b) {
  const date = new Date().toISOString().slice(0, 10);
  return crypto.createHash('sha256')
    .update([String(a), String(b)].sort().join(':') + ':' + date)
    .digest();
}

function percentages(a, b) {
  const seed = pairSeed(a, b);
  const love = 35 + (seed[0] % 66);
  const compatibility = 35 + (seed[1] % 66);
  const bond = Math.round((love + compatibility) / 2);
  return { love, compatibility, bond };
}

function verdict(score) {
  if (score >= 95) return 'انسجام نادر.';
  if (score >= 85) return 'هناك انسجام واضح بين الطرفين.';
  if (score >= 70) return 'النتيجة جيدة.';
  if (score >= 50) return 'هناك توافق بين الطرفين.';
  if (score >= 30) return 'العلاقة تحتاج بعض الحظ.';
  return 'النتيجة منخفضة.';
}

async function downloadAvatar(url, root, label) {
  if (!url || /^https?:\/\/www\.facebook\.com\/profile\.php/i.test(String(url))) {
    throw new Error('رابط صورة الحساب غير صالح.');
  }
  return downloadUrl(url, {
    kind: 'image',
    prefix: `love-${label}`,
    tempDir: path.join(root, 'tmp'),
    maxBytes: 15 * 1024 * 1024,
    headers: {
      Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      Referer: 'https://www.facebook.com/'
    }
  });
}

function cropSquare(image) {
  const size = Math.min(image.bitmap.width, image.bitmap.height);
  const x = Math.floor((image.bitmap.width - size) / 2);
  const y = Math.floor((image.bitmap.height - size) / 2);
  return image.crop({ x, y, w: size, h: size });
}

function drawHeart(image, cx, cy, size) {
  const data = image.bitmap.data;
  const width = image.bitmap.width;
  for (let y = -size; y <= size; y += 1) {
    for (let x = -size; x <= size; x += 1) {
      const nx = x / size;
      const ny = y / size;
      const eq = Math.pow(nx * nx + ny * ny - 0.25, 3) - nx * nx * Math.pow(ny, 3);
      if (eq > 0) continue;
      const px = cx + x;
      const py = cy + y;
      if (px < 0 || py < 0 || px >= width || py >= image.bitmap.height) continue;
      const i = ((width * py) + px) * 4;
      data[i] = 220;
      data[i + 1] = 70;
      data[i + 2] = 110;
      data[i + 3] = 255;
    }
  }
}

async function compose(avatarA, avatarB, output) {
  const Jimp = await getJimp();
  const [sourceA, sourceB] = await Promise.all([Jimp.read(avatarA), Jimp.read(avatarB)]);
  if (!sourceA.bitmap.width || !sourceB.bitmap.width) throw new Error('صور الحسابات غير صالحة.');

  const a = cropSquare(sourceA).resize({ w: 440, h: 440 });
  const b = cropSquare(sourceB).resize({ w: 440, h: 440 });
  const card = new Jimp({ width: 960, height: 500, color: 0xf7f7f9ff });
  card.composite(a, 30, 30);
  card.composite(b, 490, 30);
  drawHeart(card, 480, 250, 26);
  await card.write(output);
  return output;
}

async function remove(paths) {
  await Promise.all(paths.filter(Boolean).map(file => fs.remove(file).catch(() => {})));
}

module.exports = { percentages, verdict, downloadAvatar, compose, remove };
