const path = require('path');
const fs = require('fs-extra');
const { downloadUrl } = require('../utils/downloader');
const { readJson, writeJsonAtomic } = require('../utils/files');

class GroupPhotoLock {
  constructor(bot) {
    this.bot = bot;
    this.file = path.join(bot.root, 'data/groupPhotoLocks.json');
    this.data = {};
    this.writeLock = Promise.resolve();
    this.restoring = new Map();
  }

  async load() {
    this.data = await readJson(this.file, {});
    return this;
  }

  async save() {
    this.writeLock = this.writeLock.then(() => writeJsonAtomic(this.file, this.data));
    return this.writeLock;
  }

  get(threadID) { return this.data[String(threadID)] || null; }
  isEnabled(threadID) { return Boolean(this.get(threadID)?.enabled); }

  async enable(threadID) {
    const id = String(threadID);
    const info = await this.bot.messenger.getThreadInfo(id);
    const admins = (info?.adminIDs || info?.adminIds || []).map(v => String(v?.id || v));
    if (admins.length && this.bot.botUserId && !admins.includes(String(this.bot.botUserId))) {
      throw new Error('يجب ان يكون البوت مشرفا في المجموعة.');
    }

    const imageUrl = info?.imageSrc || info?.imageUrl || info?.threadImageUrl || info?.photo || info?.thumbSrc;
    if (!imageUrl || /^https?:\/\/www\.facebook\.com\/profile\.php/i.test(String(imageUrl))) {
      throw new Error('تعذر الحصول على صورة المجموعة الحالية.');
    }

    const file = await downloadUrl(imageUrl, {
      kind: 'image',
      prefix: `group-${id}`,
      tempDir: path.join(this.bot.root, 'tmp'),
      maxBytes: 20 * 1024 * 1024,
      headers: {
        Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        Referer: 'https://www.facebook.com/'
      }
    });
    const permanentDir = path.join(this.bot.root, 'data/group-images');
    await fs.ensureDir(permanentDir);
    const permanent = path.join(permanentDir, `${id}${path.extname(file).toLowerCase() || '.jpg'}`);
    await fs.move(file, permanent, { overwrite: true });
    this.data[id] = { enabled: true, file: path.relative(this.bot.root, permanent), updatedAt: new Date().toISOString() };
    await this.save();
  }

  async disable(threadID) {
    const id = String(threadID);
    const item = this.get(id);
    delete this.data[id];
    await this.save();
    if (item?.file) await fs.remove(path.resolve(this.bot.root, item.file)).catch(() => {});
  }

  consumeRestoreEvent(threadID) {
    const id = String(threadID);
    const until = this.restoring.get(id) || 0;
    if (until > Date.now()) {
      this.restoring.delete(id);
      return true;
    }
    return false;
  }

  async restore(threadID) {
    const item = this.get(threadID);
    const file = item?.file ? path.resolve(this.bot.root, item.file) : null;
    if (!item?.enabled || !file || !fs.existsSync(file)) return false;
    this.restoring.set(String(threadID), Date.now() + 8000);
    try {
      await this.bot.messenger.changeGroupImage(file, threadID);
      return true;
    } catch (error) {
      this.restoring.delete(String(threadID));
      throw error;
    }
  }
}

module.exports = GroupPhotoLock;
