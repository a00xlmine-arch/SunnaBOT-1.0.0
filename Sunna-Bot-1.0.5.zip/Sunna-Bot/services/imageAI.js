const path = require('path');
const fs = require('fs-extra');
const { downloadUrl } = require('../utils/downloader');

let puterPromise = null;

async function getPuter(token) {
  if (!token) throw new Error('اضف Puter auth token داخل config/secrets.json لتفعيل الامر .image.');
  if (!puterPromise) {
    puterPromise = (async () => {
      const { init } = require('@heyputer/puter.js/src/init.cjs');
      return init(token);
    })();
  }
  return puterPromise;
}

async function generate({ token, prompt, tmpDir }) {
  const puter = await getPuter(token);
  const image = await puter.ai.txt2img(prompt, { model: 'gpt-image-1-mini' });
  const src = typeof image === 'string' ? image : image?.src;
  if (!src) throw new Error('خدمة الصور لم ترجع صورة صالحة.');
  await fs.ensureDir(tmpDir);
  if (src.startsWith('data:')) {
    const base64 = src.split(',')[1];
    const file = path.join(tmpDir, `sunna-ai-${Date.now()}.png`);
    await fs.writeFile(file, Buffer.from(base64, 'base64'));
    return file;
  }
  return downloadUrl(src, { prefix: 'sunna-ai', ext: 'png', maxBytes: 20 * 1024 * 1024 });
}

module.exports = { generate };
