const axios = require('axios');
const TIMEZONE = 'Asia/Riyadh';
const NAMES = { Fajr:'الفجر', Sunrise:'الشروق', Dhuhr:'الظهر', Asr:'العصر', Maghrib:'المغرب', Isha:'العشاء' };
let cache = null;

function makkahDateKey() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: TIMEZONE, year:'numeric', month:'2-digit', day:'2-digit' }).format(new Date());
}

async function getToday() {
  const key = makkahDateKey();
  if (cache?.key === key) return cache.timings;
  const response = await axios.get('https://api.aladhan.com/v1/timingsByCity', {
    params: { city: 'Makkah', country: 'Saudi Arabia', method: 4 }, timeout: 15000,
    headers: { Accept: 'application/json' }
  });
  const timings = response?.data?.data?.timings;
  if (!timings) throw new Error('تعذر الحصول على مواقيت مكة.');
  const normalized = Object.fromEntries(Object.keys(NAMES).map(keyName => [keyName, String(timings[keyName] || '').slice(0,5)]));
  cache = { key, timings: normalized };
  return normalized;
}

function format(timings) {
  return ['مواقيت الصلاة اليوم','',...Object.entries(NAMES).map(([key,label]) => `${label}: ${timings[key] || '--:--'}`),'','بتوقيت مكة المكرمة'].join('\n');
}

function timeForPrayer(timings, key) { return timings[key] || null; }
module.exports = { TIMEZONE, NAMES, getToday, format, timeForPrayer, makkahDateKey };
