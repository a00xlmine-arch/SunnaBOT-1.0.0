const fs = require('fs-extra');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const { tempFile, downloadUrl, sniffAudioExtension, ensureExtension } = require('../utils/downloader');

const execFileAsync = promisify(execFile);
let clientPromise = null;

function isYouTubeUrl(value) {
  try {
    const url = new URL(String(value));
    return /(^|\.)youtube\.com$|(^|\.)youtu\.be$/.test(url.hostname);
  } catch (_) {
    return false;
  }
}

function isRemoteUrl(value) { return /^https?:\/\//i.test(String(value || '').trim()); }

function titleOf(video) {
  return typeof video?.title === 'string' ? video.title : String(video?.title?.text || 'YouTube video');
}

async function getClient() {
  if (!clientPromise) {
    clientPromise = (async () => {
      const mod = await import('youtubei.js');
      const Innertube = mod.Innertube || mod.default;
      if (!Innertube) throw new Error('تعذر تحميل YouTube.js.');
      return Innertube.create({ lang: 'ar', location: 'SA', retrieve_player: false });
    })();
  }
  return clientPromise;
}

async function searchMany(query, limit = 5) {
  const value = String(query || '').trim();
  if (!value) return [];
  if (isYouTubeUrl(value)) return [{ url: value, title: 'YouTube video' }];
  const youtube = await getClient();
  const result = await youtube.search(value, { type: 'video' });
  const videos = Array.isArray(result?.videos) ? result.videos : [];
  return videos.filter(video => video?.id).slice(0, Math.min(5, limit)).map(video => ({
    id: String(video.id),
    url: video.url || `https://www.youtube.com/watch?v=${video.id}`,
    title: titleOf(video),
    author: typeof video.author?.name === 'string' ? video.author.name : String(video.author || '')
  }));
}

async function search(query) {
  return (await searchMany(query, 1))[0] || null;
}

async function verifyMp3(filePath) {
  const buffer = await fs.readFile(filePath);
  return sniffAudioExtension(buffer) === 'mp3' && buffer.length > 4096;
}

async function transcodeToMp3(inputPath, root) {
  const outputPath = tempFile('song', 'mp3', path.join(root, 'tmp'));
  try {
    await execFileAsync('ffmpeg', [
      '-hide_banner', '-loglevel', 'error', '-y',
      '-i', inputPath,
      '-vn', '-codec:a', 'libmp3lame', '-b:a', '192k',
      outputPath
    ], { timeout: 120_000 });
    return outputPath;
  } catch (error) {
    await fs.remove(outputPath).catch(() => {});
    if (error?.code === 'ENOENT') {
      throw new Error('الصوت ليس MP3 ويحتاج FFmpeg لتحويله. ثبته عبر: pkg install ffmpeg -y');
    }
    throw new Error(`تعذر تحويل الصوت الى MP3: ${error?.stderr || error?.message || 'خطا غير معروف'}`);
  }
}

async function normalizeDownloadResult(result, maxBytes, root) {
  if (!result?.success || !result.filePath) {
    throw new Error(result?.error || 'مزود التحميل لم يرجع صوتا.');
  }

  let filePath = String(result.filePath);
  let sourcePath = null;
  let remoteCleanup = null;
  let generatedPath = null;

  if (isRemoteUrl(filePath)) {
    const mediaPath = await downloadUrl(filePath, {
      kind: 'audio',
      prefix: 'song-download',
      tempDir: path.join(root, 'tmp'),
      ext: 'bin',
      maxBytes,
      timeoutMs: 60_000,
      headers: {
        Accept: 'audio/mpeg,audio/*;q=0.9,application/octet-stream;q=0.8,*/*;q=0.5',
        Referer: 'https://www.youtube.com/'
      }
    });
    filePath = mediaPath;
    sourcePath = mediaPath;
  } else {
    sourcePath = filePath;
  }

  if (isRemoteUrl(filePath) || !fs.existsSync(filePath)) {
    throw new Error('رابط الصوت لم يتحول الى ملف محلي.');
  }

  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile() || stat.size <= 0) throw new Error('ملف الصوت فارغ.');
    if (stat.size > maxBytes) throw new Error('الصوت اكبر من الحد المسموح.');

    const buffer = await fs.readFile(filePath);
    const detected = sniffAudioExtension(buffer);
    if (detected === 'mp3' && await verifyMp3(filePath)) {
      filePath = await ensureExtension(filePath, 'mp3');
    } else {
      generatedPath = await transcodeToMp3(filePath, root);
      if (!await verifyMp3(generatedPath)) throw new Error('تعذر انتاج ملف MP3 صالح.');
      if (generatedPath !== filePath) await fs.remove(filePath).catch(() => {});
      filePath = generatedPath;
    }

    const finalStat = await fs.stat(filePath);
    if (finalStat.size > maxBytes) throw new Error('الصوت اكبر من الحد المسموح بعد التحويل.');

    return {
      ...result,
      filePath,
      ext: 'mp3',
      size: finalStat.size,
      mimeType: 'audio/mpeg',
      cleanup: async () => {
        await remoteCleanup?.().catch(() => {});
        await fs.remove(filePath).catch(() => {});
      }
    };
  } catch (error) {
    await remoteCleanup?.().catch(() => {});
    if (generatedPath) await fs.remove(generatedPath).catch(() => {});
    if (sourcePath && sourcePath !== generatedPath && fs.existsSync(sourcePath)) {
      await fs.remove(sourcePath).catch(() => {});
    }
    throw error;
  }
}

async function downloadMp3(url, maxBytes = 40 * 1024 * 1024, root = process.cwd()) {
  const { downloadYouTube } = require('@hiudyy/ytdl');
  let lastError = null;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      const result = await downloadYouTube(String(url), 'mp3');
      return await normalizeDownloadResult(result, maxBytes, root);
    } catch (error) {
      lastError = error;
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1200));
    }
  }
  return { success: false, error: lastError?.message || 'تعذر استخراج الصوت.' };
}

module.exports = { search, searchMany, downloadMp3, isYouTubeUrl, verifyMp3 };
