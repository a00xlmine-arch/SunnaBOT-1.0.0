const axios = require('axios');
const { searchPinterest } = require('@hiudyy/ytdl');
const { getJimp } = require('../utils/imageCodec');

const PINTEREST_HEADERS = {
  Accept: 'application/json,text/plain,*/*',
  'X-Pinterest-AppState': 'active',
  'X-Pinterest-Source-Url': '/ideas/',
  'X-Pinterest-PWS-Handler': 'www/ideas.js',
  Referer: 'https://www.pinterest.com/'
};

function normalizeText(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[\u0640]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

function tokens(value) {
  return normalizeText(value).split(/\s+/u).filter(token => token.length >= 2);
}

function textRelevance(query, candidate) {
  const q = tokens(query);
  if (!q.length) return 0;
  const text = normalizeText([
    candidate.title,
    candidate.description,
    candidate.author,
    candidate.link
  ].join(' '));
  let score = 0;
  for (const token of q) {
    if (text.includes(token)) score += token === normalizeText(query) ? 40 : 18;
  }
  const exact = normalizeText(query);
  if (exact && text.includes(exact)) score += 45;
  return Math.min(100, score);
}

async function pinterestResourceSearch(term, limit = 20) {
  const data = encodeURIComponent(JSON.stringify({
    options: { query: term, bookmarks: [''] },
    context: {}
  }));

  const response = await axios.get(
    `https://www.pinterest.com/resource/BaseSearchResource/get/?data=${data}`,
    {
      headers: PINTEREST_HEADERS,
      timeout: 20_000,
      responseType: 'json',
      validateStatus: status => status >= 200 && status < 300
    }
  );

  const raw = response.data?.resource_response?.data?.results;
  if (!Array.isArray(raw)) return [];

  const results = [];
  for (const item of raw) {
    if (!item || item.type === 'story') continue;
    const image = item.images?.orig;
    if (!image?.url) continue;
    results.push({
      url: String(image.url),
      title: String(item.title || item.grid_title || ''),
      description: String(
        item.description || item.rich_summary?.display_description || ''
      ),
      author: String(item.pinner?.full_name || item.pinner?.username || ''),
      link: String(item.link || (item.id ? `https://www.pinterest.com/pin/${item.id}/` : '')),
      width: Number(image.width || 0),
      height: Number(image.height || 0)
    });
    if (results.length >= limit) break;
  }
  return results;
}

async function safeLegacySearch(term, limit = 20) {
  try {
    const urls = await searchPinterest(term, { limit });
    return Array.isArray(urls)
      ? urls.filter(url => /^https?:\/\//i.test(String(url))).map(url => ({ url: String(url) }))
      : [];
  } catch (_) {
    return [];
  }
}

function uniqueCandidates(items) {
  const map = new Map();
  for (const item of items) {
    const url = String(item?.url || '').split('#')[0];
    if (!/^https?:\/\//i.test(url) || map.has(url)) continue;
    map.set(url, { ...item, url });
  }
  return [...map.values()];
}

async function search(query, limit = 18) {
  const value = String(query || '').trim();
  if (!value) throw new Error('اكتب ما تريد البحث عنه بعد الامر.');

  const terms = [
    value,
    `${value} character`,
    `${value} anime character`,
    `${value} official art`,
    `${value} portrait`
  ];

  const detailed = [];
  for (const term of terms) {
    try {
      detailed.push(...await pinterestResourceSearch(term, 20));
    } catch (_) {
      // Fall back to the package search below.
    }
  }

  let candidates = uniqueCandidates(detailed);
  if (!candidates.length) {
    const legacy = [];
    for (const term of terms) legacy.push(...await safeLegacySearch(term, 20));
    candidates = uniqueCandidates(legacy);
  }

  return candidates
    .map(item => ({ ...item, relevance: textRelevance(value, item) }))
    .sort((a, b) => {
      const relevance = b.relevance - a.relevance;
      if (relevance) return relevance;
      const areaA = Number(a.width || 0) * Number(a.height || 0);
      const areaB = Number(b.width || 0) * Number(b.height || 0);
      return areaB - areaA;
    })
    .slice(0, limit);
}

async function imageQuality(filePath) {
  try {
    const Jimp = await getJimp();
    const image = await Jimp.read(filePath);
    const { width, height, data } = image.bitmap;
    const pixels = width * height;
    if (width < 250 || height < 250 || pixels > 18_000_000) return -1;

    const ratio = width / height;
    if (ratio < 0.45 || ratio > 2.3) return -1;

    const stepX = Math.max(1, Math.floor(width / 32));
    const stepY = Math.max(1, Math.floor(height / 32));
    let edgeSum = 0;
    let edgeSamples = 0;

    const luminance = (x, y) => {
      const index = ((y * width) + x) * 4;
      return (0.2126 * data[index]) + (0.7152 * data[index + 1]) + (0.0722 * data[index + 2]);
    };

    for (let y = 0; y < height - stepY; y += stepY) {
      for (let x = 0; x < width - stepX; x += stepX) {
        const here = luminance(x, y);
        const right = luminance(Math.min(width - 1, x + stepX), y);
        const down = luminance(x, Math.min(height - 1, y + stepY));
        edgeSum += Math.abs(here - right) + Math.abs(here - down);
        edgeSamples += 2;
      }
    }

    if (!edgeSamples) return -1;
    const edgeScore = Math.min(70, (edgeSum / edgeSamples) * 1.8);
    const sizeScore = Math.min(30, Math.log10(Math.max(1, pixels)) * 4.2);
    return Math.round(edgeScore + sizeScore);
  } catch (_) {
    return -1;
  }
}

module.exports = { search, imageQuality, normalizeText, textRelevance };
