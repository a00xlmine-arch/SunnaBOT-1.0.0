const { mainMenu, helpPrompt } = require('../utils/messages');

class InteractionService {
  constructor(bot) {
    this.bot = bot;
    this.prompts = new Map();
  }

  cleanup() {
    const now = Date.now();
    for (const [messageID, item] of this.prompts) {
      if (item.expiresAt <= now) this.prompts.delete(messageID);
    }
  }

  async handle(event) {
    this.cleanup();
    if (!event?.body) return false;

    const body = String(event.body).trim();
    const replyID = event.replyTarget?.messageID || event.replyTarget?.messageId || event.replyTarget?.id;

    if (replyID) {
      const prompt = this.prompts.get(String(replyID));
      if (prompt && prompt.threadID === String(event.threadID) && prompt.senderID === String(event.senderID)) {
        if (/^help$/i.test(body)) {
          this.prompts.delete(String(replyID));
          await this.bot.messenger.sendMessage(mainMenu(), event.threadID);
          return true;
        }
      }
    }

    if (body === '.') {
      const sent = await this.bot.messenger.sendMessage(helpPrompt(), event.threadID);
      const messageID = sent?.messageID || sent?.messageId || sent?.id || sent?.mid;
      if (messageID) {
        this.prompts.set(String(messageID), {
          threadID: String(event.threadID),
          senderID: String(event.senderID),
          expiresAt: Date.now() + 90_000
        });
      }
      return true;
    }

    // Do not add an extra sparkle to actual commands; the dot trigger applies to normal messages.
    if (body.startsWith(this.bot.config.prefix)) return false;

    const lower = body.toLowerCase();
    if (/بوت|bot|سونا|sunna/.test(lower) || body.includes('.')) {
      const reacted = typeof this.bot.messenger.reactToMessage === 'function'
        ? await this.bot.messenger.reactToMessage(event.messageID, '✨️')
        : false;
      if (!reacted) {
        await this.bot.messenger.sendMessage('✨️', event.threadID);
      }
    }
    return false;
  }
}

module.exports = InteractionService;
