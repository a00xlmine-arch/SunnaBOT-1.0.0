const games = new Map();
function key(threadID, senderID) { return `${threadID}:${senderID}`; }
function start() { return Math.floor(Math.random() * 100) + 1; }
module.exports = { games, key, start };
