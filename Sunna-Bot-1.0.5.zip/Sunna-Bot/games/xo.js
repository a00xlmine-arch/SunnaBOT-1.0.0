const games = new Map();
function newGame(player) { return { board: Array(9).fill(''), player: String(player) }; }
module.exports = { games, newGame };
