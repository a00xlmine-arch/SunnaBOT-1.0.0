module.exports = { name: 'mirror', apply(image) { return image.flip({ horizontal: true }); } };
