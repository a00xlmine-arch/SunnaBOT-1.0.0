module.exports = { name: 'rotate', apply(image) { return image.rotate(90); } };
