module.exports = { name: 'fisheye', apply(image) { return image.fisheye({ radius: 1.3 }); } };
