module.exports = { name: 'heart', apply(image) {
  const { data } = image.bitmap;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = 255 - data[i]; data[i + 1] = 255 - data[i + 1]; data[i + 2] = 255 - data[i + 2];
  }
  return image;
} };
