module.exports = { name: 'blur', apply(image) { return image.blur(8); } };
