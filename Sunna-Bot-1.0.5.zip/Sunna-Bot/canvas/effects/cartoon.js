module.exports = { name: 'cartoon', apply(image) {
  image.posterize?.(6);
  return image.contrast(0.25);
} };
