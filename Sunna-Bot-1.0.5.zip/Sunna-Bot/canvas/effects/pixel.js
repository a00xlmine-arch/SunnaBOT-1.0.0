module.exports = { name: 'pixel', apply(image) {
  const { data } = image.bitmap;
  const w = image.bitmap.width, h = image.bitmap.height, size = 12;
  for (let y = 0; y < h; y += size) {
    for (let x = 0; x < w; x += size) {
      const src = ((w * y) + x) * 4;
      for (let yy = y; yy < Math.min(y + size, h); yy += 1) {
        for (let xx = x; xx < Math.min(x + size, w); xx += 1) {
          const i = ((w * yy) + xx) * 4;
          data[i] = data[src]; data[i + 1] = data[src + 1]; data[i + 2] = data[src + 2];
        }
      }
    }
  }
  return image;
} };
