const path = require('path');
const fs = require('fs-extra');
const { downloadMedia } = require('../utils/downloader');
const { getJimp } = require('../utils/imageCodec');

function findImageUrl(attachments) {
  for (const item of attachments || []) {
    const url = item?.url || item?.imageUrl || item?.href || item?.largePreviewUrl || item?.previewUrl || item?.thumbnailUrl;
    const type = String(item?.type || '').toLowerCase();
    if (url && (!type || type.includes('image') || type.includes('photo') || /\.(png|jpe?g|gif|webp|bmp|tiff)(\?|$)/i.test(url))) return url;
  }
  return null;
}

function findReplyImage(reply) {
  return findImageUrl(reply?.attachments || reply?.messageAttachments || reply?.raw?.attachments);
}

async function sourceFor(ctx) {
  const replyUrl = findReplyImage(ctx.replyTarget);
  if (replyUrl) return replyUrl;

  const ownUrl = findImageUrl(ctx.attachments);
  if (ownUrl) return ownUrl;

  const profile = await ctx.bot.profile.getUser(ctx.senderID);
  if (!profile.avatarUrl) throw new Error('لم استطع الحصول على صورة الحساب.');
  return profile.avatarUrl;
}

async function downloadImage(url, root) {
  const media = await downloadMedia(url, 'image', {
    tempDir: path.join(root, 'tmp'),
    maxBytes: 20 * 1024 * 1024,
    headers: {
      Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      Referer: 'https://www.facebook.com/'
    }
  });

  try {
    const Jimp = await getJimp();
    const image = await Jimp.read(media.path);
    if (image.bitmap.width * image.bitmap.height > 16_000_000) throw new Error('الصورة كبيرة جدا للمعالجة.');
    return media.path;
  } catch (error) {
    await media.cleanup?.().catch(() => {});
    throw error;
  }
}

module.exports = { sourceFor, downloadImage };
