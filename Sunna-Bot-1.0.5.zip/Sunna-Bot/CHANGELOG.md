# Changelog

## 1.0.5
- Fixed Messenger avatar lookup to support both Promise and callback API signatures.
- Fixed profile-image discovery so Facebook profile page URLs are never treated as image URLs.
- Reworked Pinterest selection to prefer query-relevant pin metadata before image quality.
- Added edge/detail scoring to reject low-information gradient/placeholder images.
- Hardened song delivery: remote CDN results are downloaded locally, verified as real MP3 data, and transcoded with FFmpeg when necessary.
- Messenger media sending now always uses the verified local file path and its real extension.
- Preserved the five-result reply-based `.song` workflow and menu deletion after successful delivery.

## 1.0.4
- Added Arabic aliases for every English command while keeping English canonical names.
- Rebuilt the Arabic command menu using the approved compact RTL-friendly design.
- Added `.prayer` using Makkah time and Umm Al-Qura method 4.
- Added automatic 08:00 morning and 23:00 night messages in `Asia/Riyadh`.
- Added `🧩 | Restarting bot...` startup announcement.
- Added `.` -> `help` reply flow for the command menu.
- Added automatic `✨️` reaction to bot/sunna mentions in normal messages.
- Added `lockphoto on/off` for Bot Admins and group photo restoration.
- Reworked `song` into a five-result reply-selection flow with local MP3 validation and optional FFmpeg transcoding.
- Reworked Pinterest delivery to decode and normalize images to PNG before sending and rank candidates by image quality.
- Improved profile avatar discovery and blocked Facebook profile pages from being used as image sources.
- Rebuilt Love cards around two real account avatars and improved mixed Arabic/Latin text direction.
- Hardened scheduler state per group to avoid one failed group preventing other groups from receiving scheduled messages.
- Added feature smoke tests and stronger doctor checks.
