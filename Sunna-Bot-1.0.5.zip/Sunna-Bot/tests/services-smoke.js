const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const Module = require('module');
const dir = path.join(os.tmpdir(), `sunna-service-test-${Date.now()}`);
const local = path.join(dir, 'audio.mp3');
const remote = path.join(dir, 'remote.mp3');
fs.mkdirSync(dir, { recursive: true });
const mp3 = Buffer.concat([Buffer.from('ID3'), Buffer.alloc(5000)]);
fs.writeFileSync(local, mp3); fs.writeFileSync(remote, mp3);
const realLoad = Module._load;
const fsExtra = Object.assign({}, fs, {
  readFile: fs.promises.readFile,
  writeFile: fs.promises.writeFile,
  move: async (src, dest) => { await fs.promises.rename(src, dest); },
  remove: async p => { await fs.promises.rm(p, { recursive: true, force: true }); },
  stat: async p => fs.promises.stat(p),
  ensureDir: async p => fs.promises.mkdir(p, { recursive: true })
});
const downloader = {
  downloadYouTube: async () => ({ success: true, filePath: local, title: 'Local' }),
  downloadToTemp: async ({ url, kind }) => ({ path: remote, size: mp3.length, contentType: kind === 'audio' ? 'audio/mpeg' : 'image/png', cleanup: async () => {} })
};
Module._load = function(request, parent, isMain) {
  if (request === '@hiudyy/ytdl') return downloader;
  if (request === 'axios') return { get: async () => ({ data: Buffer.alloc(0), headers: {}, status: 200 }) };
  if (request === 'fs-extra') return fsExtra;
  return realLoad.call(this, request, parent, isMain);
};
(async()=>{try{
  delete require.cache[require.resolve('../services/youtube')];
  const y = require('../services/youtube');
  const result = await y.downloadMp3('https://www.youtube.com/watch?v=test', 1024 * 1024, dir);
  assert.strictEqual(result.success, true);
  assert.ok(result.filePath.endsWith('.mp3'));
  assert.strictEqual(fs.statSync(result.filePath).size, mp3.length);
  console.log('YouTube MP3 normalization smoke tests passed.');
}finally{Module._load=realLoad;fs.rmSync(dir,{recursive:true,force:true});}})().catch(e=>{console.error(e.stack||e);process.exit(1);});
