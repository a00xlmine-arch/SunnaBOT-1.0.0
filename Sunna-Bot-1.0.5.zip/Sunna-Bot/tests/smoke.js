const assert = require('assert');
const path = require('path');
const fs = require('fs');
const Module = require('module');
const root = path.resolve(__dirname, '..');
const realLoad = Module._load;

const fsExtra = Object.assign({}, fs, {
  ensureDirSync: dir => fs.mkdirSync(dir, { recursive: true }),
  ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
  readJson: async file => JSON.parse(await fs.promises.readFile(file, 'utf8')),
  writeJsonAtomic: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
  remove: async file => fs.promises.rm(file, { recursive: true, force: true })
});
const mocks = {
  'fs-extra': fsExtra,
  axios: { get: async () => ({ data: Buffer.alloc(0), headers: { 'content-type': 'image/png' }, status: 200 }) },
  pino: Object.assign(() => ({ info() {}, warn() {}, error() {}, debug() {} }), { stdTimeFunctions: { isoTime: () => '' } }),
  '@hiudyy/ytdl': { searchPinterest: async () => [], downloadYouTube: async () => ({ success: false, error: 'mock' }), downloadToTemp: async () => ({ path: '', size: 0, contentType: 'image/png', cleanup: async () => {} }) }
};
Module._load = function(request, parent, isMain) { return Object.prototype.hasOwnProperty.call(mocks, request) ? mocks[request] : realLoad.call(this, request, parent, isMain); };
try {
  const cfg = JSON.parse(fs.readFileSync(path.join(root, 'config/config.json'), 'utf8'));
  assert.strictEqual(cfg.developer, 'Rin Il');
  assert.strictEqual(cfg.prefix, '.');
  assert.strictEqual(cfg.version, '1.0.5');
  assert.strictEqual(cfg.timezone, 'Asia/Riyadh');
  assert.strictEqual(cfg.schedules.morning, '08:00');
  assert.strictEqual(cfg.schedules.night, '23:00');
  const messages = require('../utils/messages');
  const menu = messages.mainMenu();
  const expectedMenu = [
    '⟡ سونا ⟡', '',
    'الصور', '◇ صورة', '◇ بنترست', '◇ كانفس', '',
    'الترفيه', '◇ الحب', '◇ حجر ورق مقص', '◇ التخمين', '◇ XO', '',
    'الموسيقى', '◇ اغنية', '',
    'المستوى', '◇ مستواي', '◇ المتصدرون', '',
    'الصلاة', '◇ مواقيت الصلاة', '',
    'النظام', '◇ معلومات', '◇ استجابة', '',
    'الادارة', '◇ تفعيل', '◇ تعطيل', '◇ قفل الصورة', '',
    '.مساعدة'
  ].join('\n');
  assert.strictEqual(menu, expectedMenu);
  assert.ok(menu.includes('◇ قفل الصورة'));
  assert.ok(menu.includes('◇ مواقيت الصلاة'));
  const { loadCommands } = require('../core/commandLoader');
  const commands = loadCommands(root);
  assert.strictEqual(new Set([...commands.values()].map(c => c.name)).size, 17);
  assert.strictEqual(commands.get('صورة').name, 'image');
  assert.strictEqual(commands.get('حب').name, 'love');
  assert.strictEqual(commands.get('اغنيه').name, 'song');
  assert.strictEqual(commands.get('صلاه').name, 'prayer');
  assert.strictEqual(commands.get('قفل_الصوره').name, 'lockphoto');
  assert.strictEqual(commands.get('قفل').name, 'lockphoto');
  const { registerDefaults, effects, getEffectNames } = require('../canvas/engine');
  registerDefaults();
  for (const name of getEffectNames()) assert.ok(effects.has(name));
  assert.strictEqual(getEffectNames().length, 13);
  console.log('Configuration, aliases, menu, and Canvas registry smoke tests passed.');
} finally { Module._load = realLoad; }
