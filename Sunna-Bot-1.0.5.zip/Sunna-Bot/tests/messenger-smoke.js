const assert = require('assert');
const Module = require('module');
const realLoad = Module._load;
const fs = require('fs');
const fsExtra = {
  ...fs,
  createReadStream: fs.createReadStream,
  existsSync: fs.existsSync
};

const fakeLogin = async () => ({ });
Module._load = function(request, parent, isMain) {
  if (request === '@lazyneoaz/metachat') return { login: fakeLogin };
  if (request === 'fs-extra') return fsExtra;
  if (request === 'axios') return { get: async () => ({ data: Buffer.alloc(0), headers: {}, status: 200 }) };
  return realLoad.call(this, request, parent, isMain);
};

(async () => {
  try {
    const MessengerAdapter = require('../core/messenger');
    const { invokeApi } = MessengerAdapter;

    const callbackApi = {
      getAvatarUser(uid, callback) {
        setImmediate(() => callback(null, { thumbSrc: `https://scontent.example/${uid}.jpg` }));
      },
      setMessageReaction(reaction, messageID, callback) {
        assert.strictEqual(reaction, '✨️');
        assert.strictEqual(messageID, 'm1');
        setImmediate(() => callback(null, true));
      }
    };

    const avatar = await invokeApi(callbackApi, 'getAvatarUser', ['u1']);
    assert.strictEqual(avatar.thumbSrc, 'https://scontent.example/u1.jpg');

    const adapter = new MessengerAdapter(process.cwd(), { appState: [{}] }, { debug(){} });
    adapter.api = callbackApi;
    assert.strictEqual(await adapter.reactToMessage('m1', '✨️'), true);
    assert.strictEqual(await adapter.getAvatarUrl('u1'), 'https://scontent.example/u1.jpg');

    console.log('Messenger callback and reaction smoke tests passed.');
  } finally {
    Module._load = realLoad;
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
