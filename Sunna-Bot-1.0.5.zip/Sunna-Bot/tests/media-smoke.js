const assert = require('assert');
const Module = require('module');
const realLoad = Module._load;
const fsExtra = {
  readFile: (...args) => require('fs').promises.readFile(...args),
  writeFile: (...args) => require('fs').promises.writeFile(...args),
  move: async (src, dest) => require('fs').promises.rename(src, dest),
  remove: async p => require('fs').promises.rm(p, { recursive: true, force: true }),
  ensureDir: async p => require('fs').promises.mkdir(p, { recursive: true }),
  createReadStream: require('fs').createReadStream,
  existsSync: require('fs').existsSync
};
Module._load = function(request, parent, isMain) {
  if (request === 'fs-extra') return fsExtra;
  if (request === 'axios') return { get: async () => ({ data: Buffer.alloc(0), headers: {}, status: 200 }) };
  return realLoad.call(this, request, parent, isMain);
};
try {
  const { sniffImageExtension, sniffAudioExtension, extensionFromContentType } = require('../utils/downloader');
  assert.strictEqual(extensionFromContentType('image/jpeg'), 'jpg');
  assert.strictEqual(extensionFromContentType('audio/mpeg'), 'mp3');
  assert.strictEqual(sniffImageExtension(Buffer.from([0xff,0xd8,0xff,0xe0])), 'jpg');
  assert.strictEqual(sniffImageExtension(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a])), 'png');
  assert.strictEqual(sniffAudioExtension(Buffer.from('ID3audio')), 'mp3');
  console.log('Media utility tests passed.');
} finally { Module._load = realLoad; }
