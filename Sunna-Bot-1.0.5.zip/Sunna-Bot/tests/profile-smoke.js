const assert = require('assert');
const ProfileService = require('../services/profile');

(async () => {
  const messenger = {
    async getUserInfo() {
      return {
        '123': {
          name: 'Test User',
          profilePicUrl: 'https://scontent.example/avatar.jpg',
          url: 'https://www.facebook.com/profile.php?id=123'
        }
      };
    }
  };

  const profiles = new ProfileService(messenger);
  const user = await profiles.getUser('123');
  assert.strictEqual(user.name, 'Test User');
  assert.strictEqual(user.avatarUrl, 'https://scontent.example/avatar.jpg');

  const secondMessenger = {
    async getUserInfo() {
      return {
        '456': {
          name: 'Invalid Avatar',
          url: 'https://www.facebook.com/profile.php?id=456'
        }
      };
    }
  };
  const second = await new ProfileService(secondMessenger).getUser('456');
  assert.strictEqual(second.avatarUrl, null);

  console.log('Profile smoke tests passed.');
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
