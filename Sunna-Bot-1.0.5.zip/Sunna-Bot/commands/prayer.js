const { getToday, format } = require('../services/prayer');
module.exports={name:'prayer',aliases:['صلاه','صلاة','مواقيت','مواقيت_الصلاة'],description:'عرض مواقيت الصلاة في مكة',cooldownMs:3000,async execute(ctx){const timings=await getToday();await ctx.reply(format(timings));}};
