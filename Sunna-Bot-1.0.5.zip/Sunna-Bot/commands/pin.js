const path = require('path');
const fs = require('fs-extra');
const { search, imageQuality } = require('../services/pinterest');
const { downloadMedia } = require('../utils/downloader');
const { normalizeToPng } = require('../services/imageMedia');

module.exports = {
  name: 'pin',
  aliases: ['بنترست', 'بن'],
  description: 'البحث عن صورة في Pinterest',
  cooldownMs: 6000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply('اكتب اسم الشخصية او الصورة التي تريد البحث عنها بعد الامر.');
      return;
    }

    const candidates = await search(query, 18);
    if (!candidates.length) {
      await ctx.reply('لم يتم العثور على صور مناسبة.');
      return;
    }

    const prepared = [];
    for (const candidate of candidates) {
      let media = null;
      let output = null;
      try {
        media = await downloadMedia(candidate.url, 'image', {
          tempDir: path.join(ctx.bot.root, 'tmp'),
          maxBytes: Number(ctx.bot.config.limits?.maxDownloadedImageBytes || 20 * 1024 * 1024),
          headers: {
            Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            Referer: 'https://www.pinterest.com/'
          }
        });

        const quality = await imageQuality(media.path);
        if (quality < 0) continue;

        output = path.join(
          ctx.bot.root,
          'tmp',
          `pin-${Date.now()}-${Math.random().toString(16).slice(2)}.png`
        );
        await normalizeToPng(media.path, output);

        const relevance = Number(candidate.relevance || 0);
        prepared.push({
          path: output,
          score: (relevance * 5) + quality,
          cleanup: async () => {
            await media?.cleanup?.().catch(() => {});
            await fs.remove(output).catch(() => {});
          }
        });
        media = null;
        output = null;
      } catch (error) {
        ctx.bot.logger.warn({ err: error, url: candidate.url }, 'Pinterest candidate failed');
      } finally {
        await media?.cleanup?.().catch(() => {});
        if (output) await fs.remove(output).catch(() => {});
      }
    }

    if (!prepared.length) throw new Error('تعذر تجهيز صورة Pinterest صالحة.');
    prepared.sort((a, b) => b.score - a.score);
    const best = prepared[0];

    try {
      await ctx.sendImage(best.path, `بنترست\nالبحث: ${query}`);
    } finally {
      await Promise.all(prepared.map(item => item.cleanup()));
    }
  }
};
