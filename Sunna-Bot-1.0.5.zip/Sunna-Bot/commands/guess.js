const { box } = require('../utils/messages'); const { normalizeMessageId } = require('../core/gameSessions');
module.exports={name:'guess',aliases:['تخمين'],description:'لعبة تخمين الرقم بالرد',async execute(ctx){
  if(ctx.bot.gameSessions.hasActive(ctx.threadID,ctx.senderID,'guess')){await ctx.reply('لديك لعبة نشطة بالفعل. رد على رسالة اللعبة الحالية.');return;}
  const sent=await ctx.reply(box('خمن الرقم',['لدي رقم بين 1 و100.','رد على هذه الرسالة بالرقم الذي تتوقعه.'])); const id=normalizeMessageId(sent); if(!id)throw new Error('تعذر تتبع رسالة اللعبة.');
  const session=ctx.bot.gameSessions.create({id,type:'guess',threadID:ctx.threadID,playerID:ctx.senderID,expiresMs:180000,data:{target:Math.floor(Math.random()*100)+1,attempts:0}});
  session.onExpire=async()=>ctx.bot.messenger.deleteMessage(id).catch(()=>{});
  session.handle=async event=>{const n=Number(String(event.body||'').trim());if(!Number.isInteger(n)||n<1||n>100){await ctx.bot.messenger.sendMessage('رد برقم بين 1 و100.',ctx.threadID);return;}session.data.attempts+=1;if(n===session.data.target){ctx.bot.gameSessions.finish(session.id);await ctx.bot.xp.addGameXP(ctx.threadID,ctx.senderID);await ctx.bot.messenger.sendMessage(box('خمن الرقم',[`اصبت الرقم بعد ${session.data.attempts} محاولات.`,'+15 XP']),ctx.threadID);return;}await ctx.bot.messenger.sendMessage(n<session.data.target?'الرقم اكبر.':'الرقم اصغر.',ctx.threadID);};
}};
