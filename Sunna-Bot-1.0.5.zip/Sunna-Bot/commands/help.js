const { mainMenu } = require('../utils/messages');
module.exports = {
  name: 'help', aliases: ['مساعده', 'مساعدة'], description: 'عرض قائمة الاوامر', cooldownMs: 1000,
  async execute(ctx) { await ctx.reply(mainMenu()); }
};
