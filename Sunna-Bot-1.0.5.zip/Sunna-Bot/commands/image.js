const path = require('path');
const fs = require('fs-extra');
const { box } = require('../utils/messages');
const { generate } = require('../services/imageAI');
module.exports = {
  name: 'image', aliases: ['صوره', 'صورة'], description: 'توليد صورة بالذكاء الاصطناعي', cooldownMs: 10000,
  async execute(ctx) {
    const prompt = ctx.args.join(' ').trim();
    if (!prompt) { await ctx.reply(box('توليد صورة', ['اكتب وصف الصورة بعد الامر.', '', '.image فتاة انمي في مدينة ليلية'])); return; }
    const file = await ctx.bot.queues.image.add(() => generate({ token: ctx.bot.credentials?.puterAuthToken, prompt, tmpDir: path.join(ctx.bot.root, 'tmp') }));
    try { await ctx.sendImage(file, 'تم انشاء الصورة.'); } finally { await fs.remove(file).catch(() => {}); }
  }
};
