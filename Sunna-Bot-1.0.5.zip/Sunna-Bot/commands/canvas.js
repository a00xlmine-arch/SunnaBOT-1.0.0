const path = require('path');
const fs = require('fs-extra');
const { sourceFor, downloadImage } = require('../canvas/imageSource');
const { processImage, registerDefaults, getEffectNames } = require('../canvas/engine');

const effectAliases = {
  'قلب': 'heart', 'رمادي': 'gray', 'ضباب': 'blur', 'بكسل': 'pixel', 'مراة': 'mirror', 'دوران': 'rotate',
  'خلل': 'glitch', 'الوان': 'colors', 'موجة': 'wave', 'عدسة': 'fisheye', 'كرتوني': 'cartoon', 'شبح': 'ghost', 'ملعون': 'cursed'
};
const effects = [
  ['heart', 'قلب'], ['gray', 'رمادي'], ['blur', 'ضباب'], ['pixel', 'بكسل'], ['mirror', 'مراة'], ['rotate', 'دوران'],
  ['glitch', 'خلل'], ['colors', 'الوان'], ['wave', 'موجة'], ['fisheye', 'عدسة'], ['cartoon', 'كرتوني'], ['ghost', 'شبح'], ['cursed', 'ملعون']
];

module.exports = {
  name: 'canvas',
  aliases: ['كانفس'],
  description: 'معالجة الصور بالمؤثرات',
  cooldownMs: 5000,
  async execute(ctx) {
    registerDefaults();
    const inputName = String(ctx.args[0] || '').toLowerCase();
    const requested = effectAliases[inputName] || inputName;
    if (!requested) {
      await ctx.reply(['كانفس', '', ...effects.map(([name, label]) => `◇ ${label}`), '', 'رد على صورة ثم اكتب .canvas <المؤثر>'].join('\n'));
      return;
    }
    if (!getEffectNames().includes(requested)) {
      await ctx.reply('هذا المؤثر غير موجود.\nاكتب .canvas لرؤية القائمة.');
      return;
    }

    const inputUrl = await sourceFor(ctx);
    const input = await downloadImage(inputUrl, ctx.bot.root);
    const output = path.join(ctx.bot.root, 'tmp', `canvas-${Date.now()}-${process.pid}.png`);
    try {
      await ctx.bot.queues.canvas.add(() => processImage(input, requested, output));
      await ctx.sendImage(output);
    } finally {
      await fs.remove(input).catch(() => {});
      await fs.remove(output).catch(() => {});
    }
  }
};
