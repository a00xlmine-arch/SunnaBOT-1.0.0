const fs = require('fs-extra');
const { box } = require('../utils/messages');
const { normalizeMessageId } = require('../core/gameSessions');
const youtube = require('../services/youtube');

module.exports = {
  name: 'song',
  aliases: ['اغنيه', 'اغنية'],
  description: 'البحث عن خمس اغاني واختيار واحدة',
  cooldownMs: 12000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply(box('اغنية', ['اكتب اسم الاغنية بعد الامر.', '', '.song اسم الاغنية']));
      return;
    }

    const results = await youtube.searchMany(query, 5);
    if (!results.length) {
      await ctx.reply('لم يتم العثور على اغاني مناسبة.');
      return;
    }

    const lines = ['نتائج البحث', ''];
    results.slice(0, 5).forEach((item, index) => lines.push(`${index + 1}. ${item.title}`));
    lines.push('', 'رد على هذه الرسالة برقم الاغنية التي تريدها.');
    const sent = await ctx.reply(lines.join('\n'));
    const menuMessageID = normalizeMessageId(sent);
    if (!menuMessageID) throw new Error('تعذر تتبع قائمة الاغاني.');

    const session = ctx.bot.gameSessions.create({
      id: menuMessageID,
      type: 'song',
      threadID: ctx.threadID,
      playerID: ctx.senderID,
      expiresMs: 180000,
      data: { results, menuMessageID }
    });

    session.onExpire = async () => ctx.bot.messenger.deleteMessage(menuMessageID).catch(() => {});

    session.handle = async event => {
      const index = Number(String(event.body || '').trim()) - 1;
      if (!Number.isInteger(index) || index < 0 || index >= session.data.results.length) {
        await ctx.bot.messenger.sendMessage('الاختيار غير صالح. رد برقم من 1 الى 5.', ctx.threadID);
        return;
      }

      const selected = session.data.results[index];
      let download = null;
      try {
        download = await ctx.bot.queues.music.add(() => youtube.downloadMp3(
          selected.url,
          Number(ctx.bot.config.limits?.maxAudioBytes || 40 * 1024 * 1024),
          ctx.bot.root
        ));
        if (!download?.success || !download.filePath) {
          throw new Error(download?.error || 'تعذر استخراج الصوت.');
        }

        await ctx.sendAudio(download.filePath, box('اغنية', [`تم اختيار: ${selected.title}`]));
        ctx.bot.gameSessions.finish(session.id);
        await ctx.bot.messenger.deleteMessage(session.data.menuMessageID).catch(() => {});
      } finally {
        await download?.cleanup?.().catch(() => {});
        if (download?.filePath) await fs.remove(download.filePath).catch(() => {});
      }
    };
  }
};
