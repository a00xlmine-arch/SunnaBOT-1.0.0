const { box } = require('../utils/messages');
const { normalizeMessageId } = require('../core/gameSessions');
const CHOICES = { حجر:'rock','✊':'rock',rock:'rock',ورق:'paper','✋':'paper',paper:'paper',مقص:'scissors','✌️':'scissors','✌':'scissors',scissors:'scissors' };
const LABELS = { rock:'حجر', paper:'ورق', scissors:'مقص' }; const BEATS = { rock:'scissors', paper:'rock', scissors:'paper' };
module.exports = {
  name:'rps', aliases:['حجر','حجر_ورق_مقص'], description:'لعبة حجر ورق مقص بالرد',
  async execute(ctx){
    if(ctx.bot.gameSessions.hasActive(ctx.threadID,ctx.senderID,'rps')){await ctx.reply('لديك لعبة نشطة بالفعل.');return;}
    const sent=await ctx.reply(box('حجر ورق مقص',['اختر: حجر او ورق او مقص.','رد على هذه الرسالة باختيارك.']));
    const messageID=normalizeMessageId(sent); if(!messageID) throw new Error('تعذر تتبع رسالة اللعبة.');
    const session=ctx.bot.gameSessions.create({id:messageID,type:'rps',threadID:ctx.threadID,playerID:ctx.senderID,expiresMs:180000,data:{}});
    session.onExpire=async()=>ctx.bot.messenger.deleteMessage(messageID).catch(()=>{});
    session.handle=async event=>{
      const choice=CHOICES[String(event.body||'').trim().toLowerCase()];
      if(!choice){await ctx.bot.messenger.sendMessage('الاختيار غير صالح. رد بحجر او ورق او مقص.',ctx.threadID);return;}
      const botChoice=['rock','paper','scissors'][Math.floor(Math.random()*3)];
      const result=choice===botChoice?'تعادل.':BEATS[choice]===botChoice?'فزت.':'خسرت.';
      ctx.bot.gameSessions.finish(session.id);
      if(result==='فزت.') await ctx.bot.xp.addGameXP(ctx.threadID,ctx.senderID);
      await ctx.bot.messenger.sendMessage(box('نتيجة اللعبة',[`اختيارك: ${LABELS[choice]}`,`اختيار Sunna: ${LABELS[botChoice]}`,`النتيجة: ${result}`,result==='فزت.'?'+15 XP':'']),ctx.threadID);
    };
  }
};
