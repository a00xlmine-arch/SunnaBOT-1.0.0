const { box } = require('../utils/messages');
module.exports={name:'enable',aliases:['تفعيل'],description:'تفعيل البوت في المجموعة الحالية',adminOnly:true,async execute(ctx){await ctx.bot.groupAccess.enable(ctx.threadID);await ctx.reply('تم تفعيل Sunna Bot في هذه المجموعة.');}};
