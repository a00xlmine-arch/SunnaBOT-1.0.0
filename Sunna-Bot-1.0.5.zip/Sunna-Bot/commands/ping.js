const { box } = require('../utils/messages');
module.exports = {
  name: 'ping', aliases: ['استجابه', 'بنغ'], description: 'فحص الاستجابة', cooldownMs: 1000,
  async execute(ctx) {
    const started = Date.now();
    const sent = await ctx.messenger.sendMessage('⟡', ctx.threadID);
    const ms = Date.now() - started;
    const messageID = sent?.messageID || sent?.messageId || sent?.id;
    if (messageID) await ctx.bot.messenger.deleteMessage(messageID).catch(() => {});
    await ctx.reply(box('استجابة Sunna', [`${ms} ms`]));
  }
};
