const { box } = require('../utils/messages');
module.exports = {
  type: 'join',
  async handle(bot, event) {
    for (const participant of event.participants || []) {
      const uid = participant.userFbId || participant.userId || participant.id || participant.uid;
      if (!uid || String(uid) === String(bot.botUserId)) continue;
      let name = participant.fullName || participant.name || participant.firstName;
      if (!name) { try { name = (await bot.profile.getUser(uid)).name; } catch (_) {} }
      name = name || String(uid);
      await bot.messenger.sendMessage(box('👋 عضو جديد', [`اهلا ${name}!`, 'نورت المجموعة، نتمنى لك وقتا ممتعا.']), event.threadID);
    }
  }
};
