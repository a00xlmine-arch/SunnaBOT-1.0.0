module.exports={type:'startup',async handle(bot){
  const message='🧩 | Restarting bot...';
  for(const threadID of bot.groupAccess.data.allowedThreadIds.map(String)){try{await bot.messenger.sendMessage(message,threadID);}catch(error){bot.logger.warn({err:error,threadID},'startup announcement failed');}}
  await bot.scheduler.start();
}};
