const fs = require('fs-extra');
const path = require('path');

async function main() {
  const file = path.join(__dirname, '..', 'config', 'config.json');
  const config = await fs.readJson(file);
  config.version = '1.0.3';
  config.timezone = 'Asia/Riyadh';
  config.schedules = {
    ...(config.schedules || {}),
    morning: '08:00',
    night: '23:00',
    prayerReminders: true
  };
  config.prayer = {
    ...(config.prayer || {}),
    city: 'Makkah',
    country: 'Saudi Arabia',
    method: 4
  };
  await fs.writeJson(file, config, { spaces: 2 });
  console.log('Config migrated to Sunna Bot 1.0.3.');
}

main().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
