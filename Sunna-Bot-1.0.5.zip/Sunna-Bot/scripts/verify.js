const assert = require('assert');
const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

const root = path.resolve(__dirname, '..');

function jsFiles(dir) {
  const full = path.join(root, dir);
  return fs.readdirSync(full)
    .filter(file => file.endsWith('.js'))
    .map(file => path.join(full, file));
}

function verifySyntax() {
  const dirs = ['core', 'commands', 'events', 'services', 'canvas', 'canvas/effects', 'games', 'database', 'utils', 'scripts', 'tests'];
  const files = dirs.flatMap(jsFiles);
  for (const file of files) {
    childProcess.execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });
  }
  return files.length;
}

function verifySafeFiles() {
  const pick = (real, example) => {
    const rp = path.join(root, real);
    return fs.existsSync(rp) ? rp : path.join(root, example);
  };
  const current = {
    appstate: JSON.parse(fs.readFileSync(pick('config/appstate.json','config/appstate.example.json'), 'utf8')),
    secrets: JSON.parse(fs.readFileSync(pick('config/secrets.json','config/secrets.example.json'), 'utf8')),
    admins: JSON.parse(fs.readFileSync(pick('config/admins.json','config/admins.example.json'), 'utf8')),
    groups: JSON.parse(fs.readFileSync(pick('config/groups.json','config/groups.example.json'), 'utf8'))
  };
  assert.ok(Array.isArray(current.appstate), 'appstate configuration must be a JSON array.');
  assert.strictEqual(Array.isArray(current.admins.adminIds), true, 'admins configuration must expose adminIds.');
  assert.strictEqual(Array.isArray(current.groups.allowedThreadIds), true, 'groups configuration must expose allowedThreadIds.');
  assert.strictEqual(typeof current.secrets.puterAuthToken, 'string', 'secrets configuration must expose puterAuthToken.');
}

const syntaxCount = verifySyntax();
verifySafeFiles();
require('./structure');
console.log(`Verification passed: ${syntaxCount} JavaScript files parsed and configuration shapes verified.`);
