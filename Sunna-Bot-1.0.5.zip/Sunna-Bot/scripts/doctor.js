const fs = require('fs-extra');
const path = require('path');
const { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..');

function fail(message) {
  console.error(`[FAIL] ${message}`);
  process.exitCode = 1;
}

function readJson(rel) {
  return fs.readJsonSync(path.join(root, rel));
}

function main() {
  console.log('Sunna Bot doctor');
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 24) fail(`Node.js ${process.versions.node} detected. Sunna Bot requires Node.js 24+.`);

  const config = readJson('config/config.json');
  if (config.developer !== 'Rin Il') fail('Developer metadata is not Rin Il.');
  if (config.prefix !== '.') fail('Prefix is not configured as .');
  if (config.timezone !== 'Asia/Riyadh') fail('Timezone must be Asia/Riyadh.');
  if (config.schedules?.morning !== '08:00' || config.schedules?.night !== '23:00') fail('Morning/night schedule mismatch.');

  for (const rel of ['config/config.json','config/appstate.json','config/secrets.json','config/admins.json','config/groups.json','data/users.json']) {
    const full = path.join(root, rel);
    if (!fs.existsSync(full) || !fs.statSync(full).isFile() || fs.statSync(full).size === 0) fail(`Missing or empty file: ${rel}`);
  }

  const app = readJson('config/appstate.json');
  const secrets = readJson('config/secrets.json');
  const admins = readJson('config/admins.json');
  const groups = readJson('config/groups.json');
  if (!Array.isArray(app) || app.length === 0) fail('AppState must be a non-empty array.');
  if (!Array.isArray(admins.adminIds) || admins.adminIds.length === 0) fail('admins.json must contain adminIds.');
  if (groups.mode !== 'allowlist' || !Array.isArray(groups.allowedThreadIds)) fail('groups.json must use allowlist mode.');
  if (!secrets || typeof secrets.puterAuthToken !== 'string') fail('secrets.json must contain puterAuthToken.');

  const ffmpeg = (() => {
    try { execFileSync('ffmpeg', ['-version'], { stdio: 'ignore' }); return true; } catch (_) { return false; }
  })();

  console.log(`[OK] Node ${process.versions.node}`);
  console.log(`[OK] Commands: ${fs.readdirSync(path.join(root, 'commands')).filter(f => f.endsWith('.js')).length}`);
  console.log(`[OK] Canvas effects: ${fs.readdirSync(path.join(root, 'canvas/effects')).filter(f => f.endsWith('.js')).length}`);
  console.log(`[OK] Events: ${fs.readdirSync(path.join(root, 'events')).filter(f => f.endsWith('.js')).length}`);
  console.log(`[OK] Runtime configuration loaded`);
  console.log(`[${ffmpeg ? 'OK' : 'WARN'}] FFmpeg ${ffmpeg ? 'available' : 'not installed; only direct MP3 providers will work'}`);
  require('./structure');
  if (process.exitCode) process.exit(1);
  console.log('[OK] Structure and configuration checks passed.');
}

main();
