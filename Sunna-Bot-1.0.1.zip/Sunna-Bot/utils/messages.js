function cleanLines(lines) {
  return (Array.isArray(lines) ? lines : [lines])
    .map(line => String(line ?? '').trimEnd())
    .filter((line, index, arr) => !(line === '' && index === arr.length - 1));
}

function box(title, lines = []) {
  const heading = String(title ?? '').trim();
  const body = cleanLines(lines);
  return [heading, '', ...body].join('\n').trim();
}

function menu(title, sections = []) {
  const lines = [];
  for (const section of sections) {
    if (!section || !section.title) continue;
    if (lines.length) lines.push('');
    lines.push(String(section.title).trim());
    for (const item of section.items || []) lines.push(`  ${String(item).trim()}`);
  }
  return box(title, lines);
}

function error(message = 'تعذر تنفيذ الطلب حاليا.') {
  return box('تعذر التنفيذ', [String(message)]);
}

function trimText(text, max = 1800) {
  const value = String(text ?? '').trim();
  if (value.length <= max) return value;
  return `${value.slice(0, Math.max(1, max - 1))}…`;
}

module.exports = { box, menu, error, trimText };
