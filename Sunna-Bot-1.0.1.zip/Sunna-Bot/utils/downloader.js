const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const os = require('os');

const IMAGE_EXTENSIONS = new Map([
  ['image/jpeg', 'jpg'],
  ['image/jpg', 'jpg'],
  ['image/png', 'png'],
  ['image/gif', 'gif'],
  ['image/webp', 'webp'],
  ['image/bmp', 'bmp'],
  ['image/tiff', 'tiff']
]);

function tempFile(prefix, ext = '') {
  const safeExt = ext ? (ext.startsWith('.') ? ext : `.${ext}`) : '';
  return path.join(os.tmpdir(), `sunna-${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${safeExt}`);
}

function extensionFromContentType(contentType = '') {
  return IMAGE_EXTENSIONS.get(String(contentType).split(';')[0].trim().toLowerCase()) || null;
}

function extensionFromUrl(url = '') {
  try {
    const pathname = new URL(url).pathname;
    const match = pathname.match(/\.([a-z0-9]{2,5})$/i);
    return match ? match[1].toLowerCase() : null;
  } catch (_) {
    return null;
  }
}

function sniffImageExtension(buffer) {
  if (!Buffer.isBuffer(buffer)) return null;
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpg';
  if (buffer.length >= 8 && buffer.readUInt32BE(0) === 0x89504e47 && buffer.readUInt32BE(4) === 0x0d0a1a0a) return 'png';
  if (buffer.length >= 6 && buffer.toString('ascii', 0, 6) === 'GIF87a') return 'gif';
  if (buffer.length >= 6 && buffer.toString('ascii', 0, 6) === 'GIF89a') return 'gif';
  if (buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (buffer.length >= 2 && buffer[0] === 0x42 && buffer[1] === 0x4d) return 'bmp';
  return null;
}

async function downloadUrl(url, options = {}) {
  const maxBytes = options.maxBytes ?? 20 * 1024 * 1024;
  const requestedExt = options.ext ? String(options.ext).replace(/^\./, '') : null;
  let filePath = options.filePath || tempFile(options.prefix || 'download', requestedExt || 'bin');

  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: options.timeoutMs ?? 30000,
      maxContentLength: maxBytes,
      maxBodyLength: maxBytes,
      maxRedirects: options.maxRedirects ?? 8,
      validateStatus: status => status >= 200 && status < 300,
      headers: {
        'User-Agent': options.userAgent || 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
        Accept: options.accept || '*/*',
        ...(options.headers || {})
      }
    });

    const buffer = Buffer.from(response.data);
    if (buffer.length === 0) throw new Error('تم استلام ملف فارغ.');
    if (buffer.length > maxBytes) throw new Error('الملف اكبر من الحد المسموح.');

    const contentType = String(response.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    const detectedExt = extensionFromContentType(contentType) || sniffImageExtension(buffer) || extensionFromUrl(url);

    if (options.kind === 'image') {
      if (!contentType.startsWith('image/') && !detectedExt) {
        throw new Error(`المصدر لم يرجع صورة صالحة (${contentType || 'نوع غير معروف'}).`);
      }
    }

    if (!options.filePath && detectedExt && !requestedExt) {
      filePath = tempFile(options.prefix || 'download', detectedExt);
    } else if (options.filePath && detectedExt && path.extname(filePath).toLowerCase() === '.bin') {
      const renamed = `${filePath.slice(0, -4)}.${detectedExt}`;
      await fs.remove(renamed).catch(() => {});
      filePath = renamed;
    }

    await fs.ensureDir(path.dirname(filePath));
    await fs.writeFile(filePath, buffer);

    return filePath;
  } catch (error) {
    await fs.remove(filePath).catch(() => {});
    throw error;
  }
}

async function downloadMedia(url, kind, options = {}) {
  const { downloadToTemp } = require('@hiudyy/ytdl');
  const media = await downloadToTemp({
    url: String(url),
    kind,
    tempDir: options.tempDir || os.tmpdir(),
    headers: options.headers
  });
  if (!media?.path) throw new Error('لم يتم استلام الملف.');
  if (options.maxBytes && media.size > options.maxBytes) {
    await media.cleanup?.().catch(() => {});
    throw new Error('الملف اكبر من الحد المسموح.');
  }
  return media;
}

function streamFile(filePath) {
  return fs.createReadStream(filePath);
}

module.exports = {
  tempFile,
  downloadUrl,
  downloadMedia,
  streamFile,
  extensionFromContentType,
  sniffImageExtension
};
