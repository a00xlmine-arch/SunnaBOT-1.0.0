const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

const requiredFiles = [
  'index.js', 'package.json', '.gitignore',
  'config/config.json', 'config/appstate.json', 'config/secrets.json', 'config/admins.json', 'config/groups.json',
  'data/users.json', 'core/messenger.js', 'core/dispatcher.js', 'core/commandRouter.js',
  'core/commandLoader.js', 'core/eventLoader.js', 'core/permissions.js', 'core/groupAccess.js',
  'core/cooldowns.js', 'core/queue.js', 'core/deduplication.js',
  'services/profile.js', 'services/love.js', 'services/imageAI.js', 'services/imageMedia.js', 'services/pinterest.js', 'services/youtube.js',
  'canvas/engine.js', 'canvas/imageSource.js',
  'games/guess.js', 'games/xo.js', 'database/xp.js',
  'utils/messages.js', 'utils/files.js', 'utils/downloader.js', 'utils/logger.js'
];

const expectedCommands = [
  'مساعدة','معلومات','بينغ','صورة','بن','اغنية','كانفس','حب',
  'رتبتي','المتصدرين','حجر','خمن','اكس','تفعيل','تعطيل'
];

const expectedEffects = [
  'قلب','رمادي','ضباب','بكسل','مراة','دوران','خلل','الوان','موجة','عين','كرتون','شبح','ملعون'
];

const expectedEvents = ['startup','join','leave'];

function read(file) {
  return fs.readFileSync(path.join(root, file), 'utf8');
}

function json(file) {
  return JSON.parse(read(file));
}

function jsFiles(dir) {
  const fullDir = path.join(root, dir);
  return fs.readdirSync(fullDir).filter(file => file.endsWith('.js')).sort();
}

function extractProperty(file, property) {
  const source = read(file);
  const regex = new RegExp(`\\b${property}\\s*:\\s*['"]([^'"]+)['"]`);
  return source.match(regex)?.[1] || null;
}

for (const file of requiredFiles) {
  const full = path.join(root, file);
  assert.ok(fs.existsSync(full), `Missing required file: ${file}`);
  assert.ok(fs.statSync(full).isFile(), `Not a file: ${file}`);
  assert.ok(fs.statSync(full).size > 0, `Empty required file: ${file}`);
}

for (const dir of ['core','commands','events','services','canvas','canvas/effects','games','database','utils','scripts','tests','docs','config','data']) {
  assert.ok(fs.existsSync(path.join(root, dir)), `Missing directory: ${dir}`);
  assert.ok(fs.readdirSync(path.join(root, dir)).length > 0, `Empty directory: ${dir}`);
}

const pkg = json('package.json');
assert.strictEqual(pkg.name, 'sunna-bot');
assert.strictEqual(pkg.type, 'commonjs');
assert.ok(pkg.engines?.node?.startsWith('>=24'), 'Node engine must be >=24.');
for (const dep of ['@lazyneoaz/metachat','@heyputer/puter.js','@hiudyy/ytdl','axios','dotenv','fs-extra','jimp','@jimp/wasm-webp','pino','youtubei.js']) {
  assert.ok(pkg.dependencies?.[dep], `Missing dependency: ${dep}`);
}

const config = json('config/config.json');
assert.strictEqual(config.developer, 'Rin Il');
assert.strictEqual(config.prefix, '.');
assert.strictEqual(config.groupMode, 'allowlist');

const appState = json('config/appstate.json');
assert.ok(Array.isArray(appState), 'config/appstate.json must be an array.');
const admins = json('config/admins.json');
assert.ok(Array.isArray(admins.adminIds), 'adminIds must be an array.');
const groups = json('config/groups.json');
assert.strictEqual(groups.mode, 'allowlist');
assert.ok(Array.isArray(groups.allowedThreadIds));
const secrets = json('config/secrets.json');
assert.ok(secrets && typeof secrets === 'object' && !Array.isArray(secrets));
assert.ok(typeof secrets.puterAuthToken === 'string', 'puterAuthToken must be a string.');
const users = json('data/users.json');
assert.ok(users && users.threads && typeof users.threads === 'object');

const commandSources = new Map();
for (const file of jsFiles('commands')) {
  const rel = `commands/${file}`;
  const name = extractProperty(rel, 'name');
  assert.ok(name, `Command has no static name: ${file}`);
  assert.ok(!commandSources.has(name), `Duplicate command name: ${name}`);
  commandSources.set(name, file);
  assert.ok(!/^[A-Za-z]/.test(name), `Non-Arabic command name: ${name}`);
  const source = read(rel);
  assert.ok(!/aliases\\s*:\\s*\\[[^\]]*['"][A-Za-z]/s.test(source), `English command alias found: ${file}`);
}
for (const name of expectedCommands) assert.ok(commandSources.has(name), `Missing command source: ${name}`);

const effectSources = new Map();
for (const file of jsFiles('canvas/effects')) {
  const rel = `canvas/effects/${file}`;
  const name = extractProperty(rel, 'name');
  assert.ok(name, `Canvas effect has no static name: ${file}`);
  assert.ok(!effectSources.has(name), `Duplicate Canvas effect: ${name}`);
  effectSources.set(name, file);
  assert.ok(read(rel).includes('apply'), `Canvas effect missing apply export reference: ${file}`);
}
for (const name of expectedEffects) assert.ok(effectSources.has(name), `Missing Canvas effect source: ${name}`);

for (const file of jsFiles('events')) {
  const rel = `events/${file}`;
  const type = extractProperty(rel, 'type');
  assert.ok(type, `Event has no static type: ${file}`);
  assert.ok(read(rel).includes('handle'), `Event missing handle implementation: ${file}`);
}
for (const type of expectedEvents) assert.ok(jsFiles('events').some(file => file.startsWith(type + '.')), `Missing event source: ${type}`);

// Verify local relative imports point to real source files. External packages are ignored.
const sourceDirs = ['core','commands','events','services','canvas','canvas/effects','games','database','utils','scripts','tests'];
const importRegex = /require\((['"])(\.{1,2}\/[^'"]+)\1\)/g;
for (const dir of sourceDirs) {
  for (const file of jsFiles(dir)) {
    const rel = `${dir}/${file}`;
    const source = read(rel);
    let match;
    while ((match = importRegex.exec(source)) !== null) {
      const target = path.resolve(root, path.dirname(rel), match[2]);
      const candidates = [target, `${target}.js`, path.join(target, 'index.js')];
      assert.ok(candidates.some(fs.existsSync), `Broken local require in ${rel}: ${match[2]}`);
    }
  }
}

assert.ok(!fs.existsSync(path.join(root, 'config/credentials.json')), 'Legacy credentials.json should not exist.');
assert.ok(!fs.existsSync(path.join(root, 'config/credentials.example.json')), 'Legacy credentials.example.json should not exist.');

console.log(`Structure verified: ${requiredFiles.length} required files, ${commandSources.size} command modules, ${effectSources.size} Canvas effects.`);
