const { trimText } = require('../utils/messages');

function normalizeParticipant(item) {
  if (!item) return null;
  if (typeof item === 'string' || typeof item === 'number') return { userFbId: String(item) };
  return item;
}

function normalizeEvent(raw) {
  if (!raw) return null;

  if (raw.type === 'message' || raw.type === 'message_reply') {
    const threadID = raw.threadID || raw.threadId;
    const senderID = raw.senderID || raw.senderId;
    const messageID = raw.messageID || raw.messageId;
    return {
      id: messageID || `${threadID || 'unknown'}:${senderID || 'unknown'}:${raw.timestamp || Date.now()}`,
      type: 'message',
      isReply: raw.type === 'message_reply',
      threadID,
      senderID,
      messageID,
      body: trimText(raw.body || raw.text || ''),
      replyTarget: raw.messageReply || raw.replyTo || raw.replyMessage || null,
      attachments: Array.isArray(raw.attachments) ? raw.attachments : [],
      raw
    };
  }

  if (raw.type === 'event' || raw.type === 'log' || raw.logMessageType || raw.eventType) {
    const logType = raw.logMessageType || raw.eventType || raw.event;
    const threadID = raw.threadID || raw.threadId;
    const author = raw.author || raw.senderID || raw.senderId || null;

    if (logType === 'log:subscribe' || logType === 'participant_added' || raw.event === 'participant_added') {
      const added = raw.logMessageData?.addedParticipants || raw.addedParticipants || raw.participants || [];
      return {
        id: raw.messageID || `join:${threadID}:${raw.timestamp || Date.now()}`,
        type: 'join',
        threadID,
        senderID: author,
        participants: added.map(normalizeParticipant).filter(Boolean),
        raw
      };
    }

    if (logType === 'log:unsubscribe' || logType === 'participant_removed' || raw.event === 'participant_removed') {
      const data = raw.logMessageData || {};
      return {
        id: raw.messageID || `leave:${threadID}:${raw.timestamp || Date.now()}`,
        type: 'leave',
        threadID,
        senderID: author,
        participantID: data.leftParticipantFbId || data.leftParticipantId || raw.leftParticipantFbId || raw.participantID,
        participantName: data.leftParticipantName || raw.leftParticipantName || raw.participantName,
        raw
      };
    }
  }

  return null;
}

class Dispatcher {
  constructor(bot) {
    this.bot = bot;
  }

  async dispatch(raw) {
    const event = normalizeEvent(raw);
    if (!event || !event.threadID) return;
    if (this.bot.dedup.has(event.id)) return;
    this.bot.dedup.add(event.id);

    if (event.type === 'message') {
      if (!event.senderID) return;
      if (String(event.senderID) === String(this.bot.botUserId)) return;
      const allowed = this.bot.groupAccess.isAllowed(event.threadID);
      const isCommand = Boolean(event.body && event.body.startsWith(this.bot.config.prefix));
      if (allowed && !isCommand && this.bot.config.xp?.enabled !== false) {
        await this.bot.xp.recordMessage(event.threadID, event.senderID);
      }
      await this.bot.router.handle(event);
      return;
    }

    if (!this.bot.groupAccess.isAllowed(event.threadID)) return;
    for (const handler of this.bot.events) {
      if (handler.type === event.type) await handler.handle(this.bot, event);
    }
  }
}

module.exports = { Dispatcher, normalizeEvent };
