const { searchPinterest } = require('@hiudyy/ytdl');

async function search(query, limit = 4) {
  const value = String(query || '').trim();
  if (!value) throw new Error('اكتب ما تريد البحث عنه بعد .بن.');
  const urls = await searchPinterest(value, { limit: Math.max(1, Math.min(Number(limit) || 4, 8)) });
  if (!Array.isArray(urls)) return [];
  return urls.filter(url => /^https?:\/\//i.test(String(url))).slice(0, limit);
}

module.exports = { search };
