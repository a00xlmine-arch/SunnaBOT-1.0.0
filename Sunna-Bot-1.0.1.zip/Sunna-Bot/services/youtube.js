const fs = require('fs-extra');

let clientPromise = null;

function isYouTubeUrl(value) {
  try {
    const url = new URL(String(value));
    return /(^|\.)youtube\.com$|(^|\.)youtu\.be$/.test(url.hostname);
  } catch (_) {
    return false;
  }
}

async function getClient() {
  if (!clientPromise) {
    clientPromise = (async () => {
      const mod = await import('youtubei.js');
      const Innertube = mod.Innertube || mod.default;
      if (!Innertube) throw new Error('تعذر تحميل YouTube.js.');
      return Innertube.create({ lang: 'ar', location: 'MA', retrieve_player: false });
    })();
  }
  return clientPromise;
}

async function search(query) {
  const value = String(query || '').trim();
  if (!value) return null;

  if (isYouTubeUrl(value)) {
    return { url: value, title: 'YouTube video' };
  }

  const youtube = await getClient();
  const result = await youtube.search(value, { type: 'video' });
  const videos = Array.isArray(result?.videos) ? result.videos : [];
  const first = videos.find(video => video?.id);
  if (!first) return null;

  const title = typeof first.title === 'string'
    ? first.title
    : String(first.title?.text || 'YouTube video');

  return {
    id: String(first.id),
    url: first.url || `https://www.youtube.com/watch?v=${first.id}`,
    title
  };
}

async function downloadMp3(url, maxBytes = 40 * 1024 * 1024) {
  const { downloadYouTube } = require('@hiudyy/ytdl');
  let lastError = null;

  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      const result = await downloadYouTube(String(url), 'mp3');
      if (result?.success && result.filePath) {
        const stat = await fs.stat(result.filePath);
        if (stat.size > maxBytes) {
          await fs.remove(result.filePath).catch(() => {});
          return { success: false, error: 'الصوت اكبر من الحد المسموح.' };
        }
        return result;
      }
      lastError = new Error(result?.error || 'مزود التحميل لم يرجع ملفا صالحا.');
    } catch (error) {
      lastError = error;
    }
    if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1500));
  }

  return { success: false, error: lastError?.message || 'تعذر استخراج الصوت.' };
}

module.exports = { search, downloadMp3 };
