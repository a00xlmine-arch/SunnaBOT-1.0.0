const path = require('path');
const fs = require('fs-extra');
const { getJimp } = require('../utils/imageCodec');

async function normalizeToPng(inputPath, outputPath = null) {
  const Jimp = await getJimp();
  const image = await Jimp.read(inputPath);
  if (image.bitmap.width * image.bitmap.height > 16_000_000) {
    throw new Error('الصورة كبيرة جدا.');
  }
  const target = outputPath || path.join(path.dirname(inputPath), `${path.basename(inputPath, path.extname(inputPath))}.png`);
  await image.write(target);
  return target;
}

async function cleanupFiles(paths) {
  for (const file of paths) {
    if (file) await fs.remove(file).catch(() => {});
  }
}

module.exports = { normalizeToPng, cleanupFiles };
