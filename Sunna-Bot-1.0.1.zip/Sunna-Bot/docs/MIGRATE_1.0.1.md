# تحديث Sunna Bot الى 1.0.1

هذه النسخة تصلح معالجة الصور وPinterest والرد على الرسائل ومسار YouTube وتستبدل شكل القوائم بتنسيق نصي بسيط.

اذا كان لديك تثبيت قائم يحتوي على `config/appstate.json` و`config/admins.json` و`config/groups.json` و`config/secrets.json`، احتفظ بها ولا تستبدلها بالقوالب الموجودة في الارشيف الكامل.

بعد نسخ ملفات التحديث الى مجلد المشروع:

```bash
npm install
npm test
npm run doctor
npm start
```

تمت اضافة `@jimp/wasm-webp` لدعم صور WebP داخل Canvas والحب، لذلك يجب تشغيل `npm install` مرة واحدة بعد التحديث.

اختبار `.اغنية` الخارجي يحتاج اتصال YouTube فعليا. اختبار الوحدة داخل المشروع يتحقق من مسار البحث/التنزيل بدون الاعتماد على الشبكة.
