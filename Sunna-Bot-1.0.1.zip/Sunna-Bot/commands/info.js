const { box } = require('../utils/messages');

module.exports = {
  name: 'معلومات',
  description: 'معلومات البوت',
  cooldownMs: 1000,
  async execute(ctx) {
    await ctx.reply(box('Sunna Bot', [
      `الاصدار: ${ctx.bot.config.version || '1.0.1'}`,
      `المطور: ${ctx.bot.config.developer}`,
      `البادئة: ${ctx.bot.config.prefix}`
    ]));
  }
};
