const path = require('path');
const { box } = require('../utils/messages');
const { search } = require('../services/pinterest');
const { downloadMedia } = require('../utils/downloader');
const { normalizeToPng } = require('../services/imageMedia');
const fs = require('fs-extra');

module.exports = {
  name: 'بن',
  description: 'البحث عن صور في Pinterest',
  cooldownMs: 6000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply(box('Pinterest', ['اكتب عبارة البحث بعد الامر.', '', '.بن فتاة انمي']));
      return;
    }

    const urls = await search(query, 4);
    if (!urls.length) {
      await ctx.reply(box('Pinterest', ['لم يتم العثور على صور.']));
      return;
    }

    let sent = 0;
    for (let i = 0; i < urls.length; i += 1) {
      let media = null;
      let normalizedPath = null;
      try {
        media = await downloadMedia(urls[i], 'image', {
          tempDir: path.join(ctx.bot.root, 'tmp'),
          maxBytes: 20 * 1024 * 1024,
          headers: {
            Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            Referer: 'https://www.pinterest.com/'
          }
        });
        normalizedPath = path.join(ctx.bot.root, 'tmp', `pinterest-${Date.now()}-${process.pid}-${i}.png`);
        await normalizeToPng(media.path, normalizedPath);
        const caption = sent === 0
          ? box('Pinterest', [`نتائج البحث عن: ${query}`, `تم ارسال ${urls.length} صور.`])
          : '';
        await ctx.sendImage(normalizedPath, caption);
        sent += 1;
      } catch (error) {
        ctx.bot.logger.warn({ err: error, url: urls[i] }, 'Pinterest image failed');
      } finally {
        if (media?.cleanup) await media.cleanup().catch(() => {});
        if (normalizedPath) await fs.remove(normalizedPath).catch(() => {});
      }
    }

    if (!sent) throw new Error('تعذر تحميل نتائج Pinterest كصور.');
  }
};
