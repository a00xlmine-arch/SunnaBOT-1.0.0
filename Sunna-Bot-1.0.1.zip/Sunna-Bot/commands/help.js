const { menu } = require('../utils/messages');

module.exports = {
  name: 'مساعدة',
  description: 'عرض قائمة الاوامر',
  cooldownMs: 1000,
  async execute(ctx) {
    const text = menu('Sunna Bot', [
      { title: 'الصور', items: ['.صورة', '.بن', '.كانفس', '.حب'] },
      { title: 'الموسيقى', items: ['.اغنية'] },
      { title: 'العاب', items: ['.حجر', '.خمن', '.اكس'] },
      { title: 'المستوى', items: ['.رتبتي', '.المتصدرين'] },
      { title: 'المجموعة', items: ['.معلومات', '.بينغ'] }
    ]);
    await ctx.reply(`${text}\n\nاكتب .كانفس لعرض مؤثرات الصور.`);
  }
};
