const assert = require('assert');
const { sniffImageExtension, extensionFromContentType } = require('../utils/downloader');

assert.strictEqual(extensionFromContentType('image/jpeg'), 'jpg');
assert.strictEqual(extensionFromContentType('image/png; charset=binary'), 'png');
assert.strictEqual(extensionFromContentType('image/webp'), 'webp');
assert.strictEqual(sniffImageExtension(Buffer.from([0xff, 0xd8, 0xff, 0xe0])), 'jpg');
assert.strictEqual(sniffImageExtension(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])), 'png');
assert.strictEqual(sniffImageExtension(Buffer.from('RIFFxxxxWEBP')), 'webp');
console.log('Media utility tests passed.');
