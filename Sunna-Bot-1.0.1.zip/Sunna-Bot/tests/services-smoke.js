const assert = require('assert');
const Module = require('module');
const fs = require('fs');

async function withMocks(mocks, fn) {
  const original = Module._load;
  Module._load = function(request, parent, isMain) {
    if (Object.prototype.hasOwnProperty.call(mocks, request)) return mocks[request];
    return original.call(this, request, parent, isMain);
  };
  try {
    return await fn();
  } finally {
    Module._load = original;
  }
}

async function testYoutubeUrlAndDownload() {
  fs.writeFileSync('/tmp/sunna-test.mp3', Buffer.from('test-audio'));

  const fakeDownloader = {
    async downloadYouTube(url, format) {
      assert.strictEqual(url, 'https://www.youtube.com/watch?v=abc123');
      assert.strictEqual(format, 'mp3');
      return { success: true, filePath: '/tmp/sunna-test.mp3', size: 1000, title: 'Test' };
    }
  };

  await withMocks({ '@hiudyy/ytdl': fakeDownloader }, async () => {
    delete require.cache[require.resolve('../services/youtube')];
    const youtube = require('../services/youtube');
    const direct = await youtube.search('https://www.youtube.com/watch?v=abc123');
    assert.strictEqual(direct.url, 'https://www.youtube.com/watch?v=abc123');
    const download = await youtube.downloadMp3(direct.url, 40 * 1024 * 1024);
    assert.strictEqual(download.success, true);
    assert.strictEqual(download.filePath, '/tmp/sunna-test.mp3');
    fs.unlinkSync('/tmp/sunna-test.mp3');
  });
}

async function main() {
  await testYoutubeUrlAndDownload();
  console.log('Service smoke tests passed.');
}

main().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
