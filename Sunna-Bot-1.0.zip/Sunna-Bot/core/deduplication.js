class Deduplication {
  constructor(ttlMs = 120000) {
    this.ttlMs = ttlMs;
    this.seen = new Map();
    this.timer = setInterval(() => this.cleanup(), Math.min(ttlMs, 30000));
    this.timer.unref?.();
  }

  has(key) {
    return this.seen.has(String(key));
  }

  add(key) {
    this.seen.set(String(key), Date.now());
  }

  cleanup() {
    const cutoff = Date.now() - this.ttlMs;
    for (const [key, time] of this.seen) {
      if (time < cutoff) this.seen.delete(key);
    }
  }
}

module.exports = Deduplication;
