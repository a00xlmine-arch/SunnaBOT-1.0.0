function normalizeIds(ids) {
  return new Set((Array.isArray(ids) ? ids : []).map(String));
}

function createPermissions(adminIds) {
  const admins = normalizeIds(adminIds);
  return {
    isBotAdmin(uid) {
      return admins.has(String(uid));
    },
    requireBotAdmin(uid) {
      return admins.has(String(uid));
    },
    listAdmins() {
      return [...admins];
    }
  };
}

module.exports = { createPermissions };
