const { createContext } = require('./context');
const { box } = require('../utils/messages');

class CommandRouter {
  constructor(bot, registry) {
    this.bot = bot;
    this.registry = registry;
  }

  parse(body) {
    const prefix = this.bot.config.prefix;
    if (!body || !body.startsWith(prefix)) return null;
    const raw = body.slice(prefix.length).trim();
    if (!raw) return null;
    const parts = raw.split(/\s+/);
    return { name: parts.shift(), args: parts };
  }

  async handle(event) {
    const parsed = this.parse(event.body);
    if (!parsed) return false;
    const command = this.registry.get(parsed.name) || (parsed.name.startsWith('كانفس_') ? this.registry.get('كانفس') : null);
    if (!command) return false;

    const isBootstrapAdminCommand = command.name === 'تفعيل' || command.name === 'تعطيل';
    if (!this.bot.groupAccess.isAllowed(event.threadID, event.senderID) && !isBootstrapAdminCommand) {
      return true;
    }

    if (command.adminOnly && !this.bot.permissions.isBotAdmin(event.senderID)) {
      await this.bot.messenger.sendMessage(box('الصلاحيات', ['هذا الامر مخصص لادمن البوت.']), event.threadID);
      return true;
    }

    const cooldownMs = command.cooldownMs ?? this.bot.config.cooldowns.defaultMs;
    const remaining = this.bot.cooldowns.check(`${event.threadID}:${event.senderID}:${command.name}`, cooldownMs);
    if (remaining > 0) {
      await this.bot.messenger.sendMessage(`انتظر ${Math.ceil(remaining / 1000)} ثانية قبل استخدام الامر مرة اخرى.`, event.threadID);
      return true;
    }

    event.commandName = parsed.name;
    const ctx = createContext({ bot: this.bot, event, args: parsed.args, command });
    try {
      await command.execute(ctx);
    } catch (error) {
      this.bot.logger.error({ err: error, command: command.name, threadID: event.threadID }, 'command failed');
      await this.bot.messenger.sendMessage(box('تعذر التنفيذ', ['حدث خطا اثناء تنفيذ الامر.', 'حاول مرة اخرى لاحقا.']), event.threadID);
    }
    return true;
  }
}

module.exports = CommandRouter;
