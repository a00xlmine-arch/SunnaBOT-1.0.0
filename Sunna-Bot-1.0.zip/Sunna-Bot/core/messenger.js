const fs = require('fs-extra');
const path = require('path');
const { login } = require('@lazyneoaz/metachat');
const { streamFile } = require('../utils/downloader');

class MessengerAdapter {
  constructor(root, credentials, logger) {
    this.root = root;
    this.credentials = credentials;
    this.logger = logger;
    this.api = null;
  }

  async login() {
    const appState = this.credentials.appState;
    if (!Array.isArray(appState) || !appState.length) throw new Error('AppState غير موجود داخل config/appstate.json.');
    this.api = await login({ appState }, {
      selfListen: false,
      selfListenEvent: false,
      listenEvents: true,
      autoListen: false,
      autoReconnect: true,
      autoReLogin: false,
      online: true
    });
    return this.api;
  }

  listen(callback) {
    if (!this.api || typeof this.api.listenMqtt !== 'function') throw new Error('metachat لا يوفر listenMqtt في هذه النسخة.');
    this.api.listenMqtt(callback);
  }

  async sendMessage(message, threadID) {
    if (!this.api) throw new Error('Messenger غير متصل.');
    return this.api.sendMessage(String(message), threadID);
  }

  async sendFile(filePath, threadID, body = '') {
    if (!this.api) throw new Error('Messenger غير متصل.');
    const attachment = streamFile(filePath);
    const payload = body ? { body: String(body), attachment } : { attachment };
    return this.api.sendMessage(payload, threadID);
  }

  async getUserInfo(uid) {
    return this.api.getUserInfo(String(uid));
  }

  async getThreadInfo(threadID) {
    return this.api.getThreadInfo(String(threadID));
  }

  getCurrentUserId() {
    if (typeof this.api.getCurrentUserID === 'function') return String(this.api.getCurrentUserID());
    if (this.api?.ctx?.userID) return String(this.api.ctx.userID);
    return null;
  }
}

module.exports = MessengerAdapter;
