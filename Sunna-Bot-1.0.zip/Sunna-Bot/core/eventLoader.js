const fs = require('fs-extra');
const path = require('path');

function loadEvents(root) {
  const dir = path.join(root, 'events');
  const events = [];
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort()) {
    const full = path.join(dir, file);
    delete require.cache[require.resolve(full)];
    const handler = require(full);
    if (!handler || typeof handler !== 'object' || typeof handler.handle !== 'function' || !handler.type) {
      throw new Error(`بنية حدث غير صالحة: ${file}`);
    }
    events.push(handler);
  }
  return events;
}

module.exports = { loadEvents };
