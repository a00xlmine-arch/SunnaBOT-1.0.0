class Cooldowns {
  constructor() {
    this.map = new Map();
  }

  check(key, ms) {
    const now = Date.now();
    const prev = this.map.get(String(key)) || 0;
    const remaining = Math.max(0, prev + ms - now);
    if (remaining === 0) this.map.set(String(key), now);
    return remaining;
  }

  clear(key) {
    this.map.delete(String(key));
  }
}

module.exports = Cooldowns;
