function box(title, lines = []) {
  const body = Array.isArray(lines) ? lines : [String(lines)];
  return [
    `╭─〔 ${title} 〕`,
    ...body.map(line => `│ ${line}`),
    '╰────────────'
  ].join('\n');
}

function trimText(text, max = 1800) {
  const value = String(text ?? '').trim();
  if (value.length <= max) return value;
  return `${value.slice(0, Math.max(1, max - 1))}…`;
}

module.exports = { box, trimText };
