const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const os = require('os');

function tempFile(prefix, ext = '') {
  const safeExt = ext ? (ext.startsWith('.') ? ext : `.${ext}`) : '';
  return path.join(os.tmpdir(), `sunna-${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}${safeExt}`);
}

async function downloadUrl(url, options = {}) {
  const maxBytes = options.maxBytes ?? 20 * 1024 * 1024;
  const filePath = options.filePath || tempFile(options.prefix || 'download', options.ext || 'bin');

  try {
    const response = await axios.get(url, {
      responseType: 'stream',
      timeout: options.timeoutMs ?? 30000,
      maxContentLength: maxBytes,
      maxBodyLength: maxBytes,
      headers: options.headers || {}
    });

    const length = Number(response.headers['content-length'] || 0);
    if (length > maxBytes) throw new Error('الملف اكبر من الحد المسموح.');

    await new Promise((resolve, reject) => {
      let total = 0;
      const out = fs.createWriteStream(filePath);
      let settled = false;
      const fail = error => {
        if (settled) return;
        settled = true;
        out.destroy();
        reject(error);
      };

      response.data.on('data', chunk => {
        total += chunk.length;
        if (total > maxBytes) {
          response.data.destroy(new Error('الملف اكبر من الحد المسموح.'));
        }
      });
      response.data.on('error', fail);
      out.on('error', fail);
      out.on('finish', () => {
        if (!settled) {
          settled = true;
          resolve();
        }
      });
      response.data.pipe(out);
    });

    const stat = await fs.stat(filePath);
    if (stat.size > maxBytes) throw new Error('الملف اكبر من الحد المسموح.');
    return filePath;
  } catch (error) {
    await fs.remove(filePath).catch(() => {});
    throw error;
  }
}

function streamFile(filePath) {
  return fs.createReadStream(filePath);
}

module.exports = { downloadUrl, streamFile, tempFile };
