const fs = require('fs-extra');
const path = require('path');

async function readJson(file, fallback) {
  try {
    return await fs.readJson(file);
  } catch (error) {
    if (error.code === 'ENOENT') return fallback;
    throw error;
  }
}

async function writeJsonAtomic(file, value) {
  await fs.ensureDir(path.dirname(file));
  const tmp = `${file}.tmp-${process.pid}-${Date.now()}`;
  await fs.writeJson(tmp, value, { spaces: 2 });
  await fs.rename(tmp, file);
}

module.exports = { readJson, writeJsonAtomic };
