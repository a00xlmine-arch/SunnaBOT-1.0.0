class ProfileService {
  constructor(messenger) {
    this.messenger = messenger;
    this.cache = new Map();
    this.ttl = 10 * 60 * 1000;
  }

  async getUser(uid) {
    const key = String(uid);
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now()) return cached.value;
    const raw = await this.messenger.getUserInfo(key);
    const value = raw?.[key] || raw?.[String(key)] || raw;
    const normalized = {
      uid: key,
      name: value?.name || value?.fullName || value?.firstName || key,
      avatarUrl: value?.thumbSrc || value?.profileUrl || value?.url || value?.thumb || null
    };
    this.cache.set(key, { value: normalized, expiresAt: Date.now() + this.ttl });
    return normalized;
  }

  invalidate(uid) {
    this.cache.delete(String(uid));
  }
}

module.exports = ProfileService;
