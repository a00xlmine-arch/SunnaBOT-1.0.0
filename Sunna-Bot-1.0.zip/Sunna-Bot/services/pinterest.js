async function search(query, limit = 4) {
  if (!query) throw new Error('اكتب ما تريد البحث عنه بعد .بن.');
  const { searchPinterest } = require('@hiudyy/ytdl');
  const urls = await searchPinterest(query);
  if (!Array.isArray(urls)) return [];
  return urls.filter(Boolean).slice(0, limit);
}

module.exports = { search };
