const fs = require('fs-extra');

let clientPromise = null;

async function getClient() {
  if (!clientPromise) {
    clientPromise = (async () => {
      const mod = await import('youtubei.js');
      const Innertube = mod.Innertube || mod.default;
      if (!Innertube) throw new Error('تعذر تحميل YouTube.js.');
      return Innertube.create({ lang: 'ar', location: 'MA', enable_session_cache: true });
    })();
  }
  return clientPromise;
}

async function search(query) {
  const youtube = await getClient();
  const result = await youtube.search(query, { type: 'video' }).catch(async () => youtube.search(query));
  const videos = Array.isArray(result?.videos) ? result.videos : [];
  const first = videos.find(video => video?.id);
  if (!first) return null;
  const title = typeof first.title === 'string' ? first.title : String(first.title?.text || 'YouTube video');
  return {
    id: String(first.id),
    url: first.url || `https://www.youtube.com/watch?v=${first.id}`,
    title
  };
}

async function downloadMp3(url, maxBytes = 40 * 1024 * 1024) {
  const { downloadYouTube } = require('@hiudyy/ytdl');
  const result = await downloadYouTube(url, 'mp3');
  if (!result?.success || !result.filePath) return result;
  const stat = await fs.stat(result.filePath);
  if (stat.size > maxBytes) {
    await fs.remove(result.filePath).catch(() => {});
    return { success: false, error: 'الصوت اكبر من الحد المسموح.' };
  }
  return result;
}

module.exports = { search, downloadMp3 };
