const crypto = require('crypto');
const path = require('path');
const fs = require('fs-extra');
const { Jimp } = require('jimp');
const { downloadUrl } = require('../utils/downloader');

function pairSeed(a, b) {
  const date = new Date().toISOString().slice(0, 10);
  return crypto.createHash('sha256').update([String(a), String(b)].sort().join(':') + ':' + date).digest();
}

function percentages(a, b) {
  const seed = pairSeed(a, b);
  const love = 35 + (seed[0] % 66);
  const compatibility = 35 + (seed[1] % 66);
  const bond = Math.round((love + compatibility) / 2);
  return { love, compatibility, bond };
}

function verdict(score) {
  if (score >= 95) return 'حتى البوت بدأ يشك في الامر.';
  if (score >= 85) return 'هناك انسجام واضح بين الطرفين.';
  if (score >= 70) return 'قد يكون هذا الاختيار افضل مما توقعنا.';
  if (score >= 50) return 'هناك شيء ما بينكما.';
  if (score >= 30) return 'العلاقة تحتاج بعض الحظ.';
  return 'يبدو ان العلاقة تحتاج الى معجزة.';
}

async function downloadAvatar(url, root, label) {
  const file = path.join(root, 'tmp', `love-${label}-${Date.now()}.img`);
  await downloadUrl(url, { filePath: file, prefix: 'love', ext: 'img', maxBytes: 15 * 1024 * 1024, timeoutMs: 20000 });
  return file;
}

function cropSquare(image) {
  const size = Math.min(image.bitmap.width, image.bitmap.height);
  const x = Math.floor((image.bitmap.width - size) / 2);
  const y = Math.floor((image.bitmap.height - size) / 2);
  return image.crop({ x, y, w: size, h: size });
}

function drawHeart(image, cx, cy, size) {
  const data = image.bitmap.data;
  const w = image.bitmap.width;
  for (let y = -size; y <= size; y += 1) {
    for (let x = -size; x <= size; x += 1) {
      const nx = x / size, ny = y / size;
      const eq = Math.pow(nx * nx + ny * ny - 0.25, 3) - nx * nx * Math.pow(ny, 3);
      if (eq <= 0) {
        const px = cx + x, py = cy + y;
        if (px < 0 || py < 0 || px >= w || py >= image.bitmap.height) continue;
        const i = ((w * py) + px) * 4;
        data[i] = 224; data[i + 1] = 72; data[i + 2] = 102; data[i + 3] = 255;
      }
    }
  }
}

async function compose(avatarA, avatarB, output) {
  const [a, b] = await Promise.all([Jimp.read(avatarA), Jimp.read(avatarB)]);
  cropSquare(a); cropSquare(b);
  a.resize({ w: 470, h: 470 });
  b.resize({ w: 470, h: 470 });
  const card = new Jimp({ width: 1000, height: 560, color: 0xf7f7f9ff });
  card.composite(a, 20, 45);
  card.composite(b, 510, 45);
  drawHeart(card, 500, 280, 42);
  await card.write(output);
  return output;
}

module.exports = { percentages, verdict, downloadAvatar, compose };
