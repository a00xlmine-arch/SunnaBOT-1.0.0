# Sunna Bot

بوت Facebook Messenger للمجموعات، مبني بنظام modular مستقل، مع Commands وEvents وCanvas وXP والعاب وخدمات خارجية. المطور: Rin Il.

## البيئة
- Node.js 24+
- CommonJS
- @lazyneoaz/metachat 1.2.2

## اعداد الحساب
ضع AppState الحقيقي داخل:

`config/appstate.json`

وضع UID الخاص بادمن البوت داخل:

`config/admins.json`

ولا حاجة لكتابة هذه القيم في Termux عند كل تشغيل.

اضبط المجموعات المسموحة في:

`config/groups.json`

الوضع الافتراضي `allowlist`. يمكن لادمن البوت استخدام `.تفعيل` داخل مجموعة لإضافتها، و`.تعطيل` لحذفها من القائمة. الاوامر العادية لا تعمل خارج المجموعات المسموحة.

## صورة AI
اذا رغبت في استخدام `.صورة` ضع Puter auth token داخل:

`config/secrets.json`

## التشغيل
```bash
npm install
npm run verify:structure
npm test
npm start
```

`npm run doctor` يفحص البيئة والاعدادات قبل التشغيل.

## الاوامر الرئيسية
```text
.مساعدة
.معلومات
.بينغ
.صورة
.بن
.اغنية
.كانفس
.حب
.رتبتي
.المتصدرين
.حجر
.خمن
.اكس
```

### Canvas
`.كانفس` يعرض المؤثرات. عند استخدام اي مؤثر يبدأ بـ `.كانفس_` يتم استخدام الصورة التي تم الرد عليها، وان لم توجد يستخدم صورة حساب منفذ الامر.

### الحب
`.حب` بدون Reply يختار عضوا اخر من المجموعة. عند الرد على رسالة عضو، يستخدم ذلك العضو تحديدا. يتم عرض الاسماء كنص عادي دون Mention.

## حماية الملفات
لا ترفع الملفات التالية الى GitHub:
- `config/appstate.json`
- `config/admins.json`
- `config/groups.json`
- `config/secrets.json`
- `.env`
- `data/users.json`

## ملاحظات معمارية
- Messenger معزول خلف Adapter.
- Commands وEvents محملة تلقائيا.
- الخدمات الخارجية منفصلة عن Commands.
- XP محفوظ حسب `threadID` وUID.
- العمليات الثقيلة تستخدم Queue وCooldown.
- الاحداث المتكررة تمنع عبر Deduplication.
- Canvas يستخدم Jimp لتجنب dependency native ثقيلة، مع الحفاظ على نظام المؤثرات المطلوب.
