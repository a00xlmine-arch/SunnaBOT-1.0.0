const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/files');

class XPService {
  constructor(root, config, profileService, logger) {
    this.file = path.join(root, 'data/users.json');
    this.config = config;
    this.profileService = profileService;
    this.logger = logger;
    this.data = { threads: {} };
    this.writeLock = Promise.resolve();
    this.lastMessageXp = new Map();
  }

  async load() {
    const raw = await readJson(this.file, { threads: {} });
    this.data = raw?.threads ? raw : { threads: {} };
    return this;
  }

  #ensure(threadID, uid) {
    const t = String(threadID);
    const u = String(uid);
    if (!this.data.threads[t]) this.data.threads[t] = { users: {} };
    if (!this.data.threads[t].users[u]) {
      this.data.threads[t].users[u] = { uid: u, xp: 0, level: 1, messageCount: 0, rank: 'مبتدي', updatedAt: Date.now(), name: '' };
    }
    return this.data.threads[t].users[u];
  }

  levelForXp(xp) {
    const base = Number(this.config.xp.levelBase || 100);
    const step = Number(this.config.xp.levelStep || 50);
    let level = 1;
    let required = base;
    let total = Number(xp) || 0;
    while (total >= required && level < 1000) {
      total -= required;
      level += 1;
      required = base + ((level - 1) * step);
    }
    return level;
  }

  rankForLevel(level) {
    if (level >= 50) return 'اسطوري';
    if (level >= 30) return 'خبير';
    if (level >= 20) return 'متقدم';
    if (level >= 10) return 'محترف';
    if (level >= 5) return 'نشط';
    return 'مبتدي';
  }

  async recordMessage(threadID, uid) {
    const id = String(uid);
    const now = Date.now();
    const key = `${threadID}:${id}`;
    const user = this.#ensure(threadID, id);
    const last = this.lastMessageXp.get(key) || 0;
    user.messageCount += 1;
    if (now - last >= Number(this.config.xp.messageCooldownMs || 45000)) {
      user.xp += Number(this.config.xp.messageXP || 5);
      this.lastMessageXp.set(key, now);
    }
    user.level = this.levelForXp(user.xp);
    user.rank = this.rankForLevel(user.level);
    user.updatedAt = now;
    await this.#save();
  }

  async addGameXP(threadID, uid, amount = null) {
    const user = this.#ensure(threadID, uid);
    user.xp += Number(amount ?? this.config.xp.gameXP ?? 15);
    user.level = this.levelForXp(user.xp);
    user.rank = this.rankForLevel(user.level);
    user.updatedAt = Date.now();
    await this.#save();
    return user;
  }

  async getUser(threadID, uid) {
    const user = this.#ensure(threadID, uid);
    try {
      const info = await this.profileService.getUser(uid);
      if (info?.name) user.name = info.name;
    } catch (_) {}
    return user;
  }

  async leaderboard(threadID, limit = 10) {
    const users = Object.values(this.data.threads[String(threadID)]?.users || {})
      .sort((a, b) => b.xp - a.xp)
      .slice(0, limit);
    const result = [];
    for (const user of users) {
      let name = user.name || user.uid;
      try {
        const info = await this.profileService.getUser(user.uid);
        if (info?.name) name = info.name;
      } catch (_) {}
      result.push({ ...user, name });
    }
    return result;
  }

  async #save() {
    this.writeLock = this.writeLock.then(() => writeJsonAtomic(this.file, this.data));
    return this.writeLock;
  }
}

module.exports = XPService;
