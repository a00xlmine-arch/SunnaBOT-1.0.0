# Changelog

## 1.0.0
- Initial Sunna Bot modular architecture.
- Arabic simplified command names and clean message style.
- Messenger Adapter via @lazyneoaz/metachat.
- Strict group allowlist with `.تفعيل` and `.تعطيل`.
- XP, levels, leaderboard, games, Canvas, Love, Pinterest, YouTube and AI image service.
- AppState and admin IDs are stored inside project config files.
- Canvas uses Jimp to avoid native canvas build requirements on Android.
