const games = new Map();
function newGame(player) { return { board: Array(9).fill(''), player, turn: 'X', finished: false }; }
module.exports = { games, newGame };
