const fs = require('fs-extra');
const path = require('path');
const { Jimp } = require('jimp');

const effects = new Map();
let registered = false;

function registerDefaults() {
  if (registered) return effects;
  const dir = path.join(__dirname, 'effects');
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort()) {
    const effect = require(path.join(dir, file));
    if (!effect?.name || typeof effect.apply !== 'function') throw new Error(`Canvas effect invalid: ${file}`);
    effects.set(effect.name, effect.apply);
  }
  registered = true;
  return effects;
}

async function processImage(inputPath, effectName, outputPath) {
  registerDefaults();
  const image = await Jimp.read(inputPath);
  const pixels = image.bitmap.width * image.bitmap.height;
  if (pixels > 16_000_000) throw new Error('الصورة كبيرة جدا للمعالجة.');
  const fn = effects.get(effectName);
  if (!fn) throw new Error(`تاثير Canvas غير معروف: ${effectName}`);
  await Promise.resolve(fn(image));
  await image.write(outputPath);
  return outputPath;
}

module.exports = { effects, registerDefaults, processImage };
