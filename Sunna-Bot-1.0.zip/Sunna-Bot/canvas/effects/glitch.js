module.exports = { name: 'خلل', apply(image) {
  const src = Buffer.from(image.bitmap.data);
  const { width: w, height: h } = image.bitmap;
  const shift = Math.max(2, Math.floor(w * 0.025));
  const data = image.bitmap.data;
  for (let y = 0; y < h; y += 1) {
    const offset = y % 3 === 0 ? shift : y % 3 === 1 ? -shift : 0;
    for (let x = 0; x < w; x += 1) {
      const sx = Math.max(0, Math.min(w - 1, x + offset));
      const i = ((w * y) + x) * 4, si = ((w * y) + sx) * 4;
      data[i] = src[si]; data[i + 1] = src[si + 1]; data[i + 2] = src[si + 2];
    }
  }
  return image;
} };
