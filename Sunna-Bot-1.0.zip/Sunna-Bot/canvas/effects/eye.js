module.exports = { name: 'عين', apply(image) { return image.fisheye({ radius: 1.3 }); } };
