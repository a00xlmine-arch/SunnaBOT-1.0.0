module.exports = { name: 'دوران', apply(image) { return image.rotate(90); } };
