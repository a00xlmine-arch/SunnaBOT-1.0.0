module.exports = { name: 'ضباب', apply(image) { return image.blur(8); } };
