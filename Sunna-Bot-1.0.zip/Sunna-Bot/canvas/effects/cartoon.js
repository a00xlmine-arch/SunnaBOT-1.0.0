module.exports = { name: 'كرتون', apply(image) {
  image.posterize?.(6);
  return image.contrast(0.25);
} };
