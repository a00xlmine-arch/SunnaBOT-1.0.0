module.exports = { name: 'موجة', apply(image) {
  const src = Buffer.from(image.bitmap.data);
  const { width: w, height: h } = image.bitmap;
  const data = image.bitmap.data;
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const sx = Math.max(0, Math.min(w - 1, Math.round(x + Math.sin(y / 9) * 8)));
      const sy = Math.max(0, Math.min(h - 1, Math.round(y + Math.sin(x / 14) * 3)));
      const i = ((w * y) + x) * 4, si = ((w * sy) + sx) * 4;
      data[i] = src[si]; data[i + 1] = src[si + 1]; data[i + 2] = src[si + 2]; data[i + 3] = src[si + 3];
    }
  }
  return image;
} };
