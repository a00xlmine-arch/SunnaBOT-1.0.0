module.exports = { name: 'مراة', apply(image) { return image.flip({ horizontal: true }); } };
