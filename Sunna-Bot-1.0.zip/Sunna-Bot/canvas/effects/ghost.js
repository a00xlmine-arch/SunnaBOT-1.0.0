module.exports = {
  name: 'شبح',
  apply(image) {
    const { data } = image.bitmap;
    for (let i = 0; i < data.length; i += 4) {
      data[i + 3] = Math.round(data[i + 3] * 0.65);
    }
    image.blur(3);
    return image;
  }
};
