module.exports = { name: 'ملعون', apply(image) {
  image.contrast(0.25).brightness(-0.05);
  const { data } = image.bitmap;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    data[i] = Math.min(255, Math.abs(g - b) + 80);
    data[i + 1] = Math.min(255, Math.abs(b - r) + 60);
    data[i + 2] = Math.min(255, Math.abs(r - g) + 40);
  }
  return image;
} };
