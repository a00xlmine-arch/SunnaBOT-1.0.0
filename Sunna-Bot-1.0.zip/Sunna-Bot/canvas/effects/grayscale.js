module.exports = { name: 'رمادي', apply(image) {
  const { data } = image.bitmap;
  for (let i = 0; i < data.length; i += 4) {
    const g = Math.round(data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
    data[i] = data[i + 1] = data[i + 2] = g;
  }
  return image;
} };
