const path = require('path');
const fs = require('fs-extra');
const { Jimp } = require('jimp');
const { downloadUrl } = require('../utils/downloader');

function findImageUrl(attachments) {
  for (const item of attachments || []) {
    const url = item?.url || item?.imageUrl || item?.href || item?.largePreviewUrl || item?.previewUrl;
    const type = String(item?.type || '').toLowerCase();
    if (url && (!type || type.includes('image') || type.includes('photo') || /\.(png|jpe?g|gif|webp)(\?|$)/i.test(url))) return url;
  }
  return null;
}

async function sourceFor(ctx) {
  const reply = ctx.replyTarget;
  const replyUrl = findImageUrl(reply?.attachments || reply?.messageAttachments || reply?.raw?.attachments);
  if (!reply && ctx.raw?.replyTarget) {
    const fallback = findImageUrl(ctx.raw.replyTarget?.attachments || ctx.raw.replyTarget?.messageAttachments);
    if (fallback) return fallback;
  }
  if (replyUrl) return replyUrl;
  const ownUrl = findImageUrl(ctx.attachments);
  if (ownUrl) return ownUrl;
  const profile = await ctx.bot.profile.getUser(ctx.senderID);
  if (!profile.avatarUrl) throw new Error('لم استطع الحصول على صورة حسابك.');
  return profile.avatarUrl;
}

async function downloadImage(url, root) {
  const file = path.join(root, 'tmp', `canvas-input-${Date.now()}-${process.pid}.bin`);
  await fs.ensureDir(path.dirname(file));
  const downloaded = await downloadUrl(url, {
    filePath: file,
    prefix: 'canvas-input',
    ext: 'bin',
    maxBytes: 20 * 1024 * 1024
  });
  try {
    const image = await Jimp.read(downloaded);
    if (image.bitmap.width * image.bitmap.height > 16_000_000) throw new Error('الصورة كبيرة جدا للمعالجة.');
  } catch (error) {
    await fs.remove(downloaded).catch(() => {});
    throw error;
  }
  return downloaded;
}

module.exports = { sourceFor, downloadImage };
