const { box } = require('../utils/messages');

module.exports = {
  name: 'المتصدرين',
  description: 'عرض اعلى المستخدمين في XP',
  async execute(ctx) {
    const rows = await ctx.bot.xp.leaderboard(ctx.threadID, 10);
    const lines = ['اعلى المستخدمين في XP', ''];
    rows.forEach((u, i) => lines.push(`${String(i + 1).padStart(2, '0')}  ${u.name || u.uid} — Lv. ${u.level} — ${u.xp} XP`));
    await ctx.reply(box('المتصدرين', lines));
  }
};
