const path = require('path');
const { box } = require('../utils/messages');
const { generate } = require('../services/imageAI');

module.exports = {
  name: 'صورة',
  description: 'توليد صورة بالذكاء الاصطناعي',
  cooldownMs: 10000,
  async execute(ctx) {
    const prompt = ctx.args.join(' ').trim();
    if (!prompt) {
      await ctx.reply(box('صورة', ['اكتب وصف الصورة بعد الامر.', '', '.صورة فتاة انمي في مدينة ليلية']));
      return;
    }
    const file = await ctx.bot.queues.image.add(() => generate({ token: ctx.bot.credentials?.puterAuthToken, prompt, tmpDir: path.join(ctx.bot.root, 'tmp') }));
    try { await ctx.sendImage(file, box('صورة', ['تم انشاء الصورة.'])); }
    finally { require('fs-extra').remove(file).catch(() => {}); }
  }
};
