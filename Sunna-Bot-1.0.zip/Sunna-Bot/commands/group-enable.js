const { box } = require('../utils/messages');

module.exports = {
  name: 'تفعيل',
  description: 'تفعيل البوت في المجموعة الحالية',
  adminOnly: true,
  cooldownMs: 1000,
  async execute(ctx) {
    await ctx.bot.groupAccess.enable(ctx.threadID);
    await ctx.reply(box('المجموعة', ['تم تفعيل Sunna Bot في هذه المجموعة.']));
  }
};
