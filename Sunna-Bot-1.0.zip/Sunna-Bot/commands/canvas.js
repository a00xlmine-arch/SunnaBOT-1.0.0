const path = require('path');
const fs = require('fs-extra');
const { box } = require('../utils/messages');
const { processImage, registerDefaults } = require('../canvas/engine');
const { sourceFor, downloadImage } = require('../canvas/imageSource');

const effects = ['قلب','رمادي','ضباب','بكسل','مراة','دوران','خلل','الوان','موجة','عين','كرتون','شبح','ملعون'];

module.exports = {
  name: 'كانفس',
  description: 'معالجة الصور ومؤثراتها',
  cooldownMs: 5000,
  async execute(ctx) {
    registerDefaults();
    const requested = ctx.commandName.startsWith('كانفس_')
      ? ctx.commandName.slice('كانفس_'.length)
      : (ctx.args[0] || null);

    if (!requested) {
      await ctx.reply(box('كانفس', [
        'تاثيرات الصور',
        '',
        ...effects.map(x => `• .كانفس_${x}`),
        '',
        'رد على صورة ثم استخدم التاثير.',
        'بدون رد على صورة سيستخدم البوت صورة حسابك.'
      ]));
      return;
    }
    if (!effects.includes(requested)) {
      await ctx.reply(box('كانفس', ['التاثير غير موجود.', 'اكتب .كانفس لعرض القائمة.']));
      return;
    }

    const inputUrl = await sourceFor(ctx);
    const input = await downloadImage(inputUrl, ctx.bot.root);
    const output = path.join(ctx.bot.root, 'tmp', `canvas-output-${Date.now()}-${process.pid}.png`);
    try {
      await processImage(input, requested, output);
      await ctx.sendImage(output);
    } finally {
      await fs.remove(input).catch(() => {});
      await fs.remove(output).catch(() => {});
    }
  }
};
