const { box } = require('../utils/messages');

const choices = ['حجر', 'ورق', 'مقص'];
const wins = { حجر: 'مقص', ورق: 'حجر', مقص: 'ورق' };

module.exports = {
  name: 'حجر',
  description: 'لعبة حجر ورق مقص',
  async execute(ctx) {
    const user = ctx.args[0] || choices[Math.floor(Math.random() * choices.length)];
    if (!choices.includes(user)) {
      await ctx.reply(box('حجر ورق مقص', ['استخدم: .حجر حجر', '.حجر ورق', 'او .حجر مقص']));
      return;
    }
    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    const result = user === botChoice ? 'تعادل.' : wins[user] === botChoice ? 'فزت.' : 'خسرت.';
    if (result === 'فزت.') await ctx.bot.xp.addGameXP(ctx.threadID, ctx.senderID);
    await ctx.reply(box('حجر ورق مقص', [`اختيارك: ${user}`, `اختيار Sunna: ${botChoice}`, `النتيجة: ${result}`, result === 'فزت.' ? '+15 XP' : '']));
  }
};
