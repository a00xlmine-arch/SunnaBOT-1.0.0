const fs = require('fs-extra');
const { box } = require('../utils/messages');
const youtube = require('../services/youtube');

module.exports = {
  name: 'اغنية',
  description: 'البحث عن اغنية واستخراجها MP3',
  cooldownMs: 12000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply(box('اغنية', ['اكتب اسم الاغنية بعد الامر.', '', '.اغنية اسم الاغنية']));
      return;
    }
    const result = await youtube.search(query);
    if (!result) {
      await ctx.reply(box('اغنية', ['لم يتم العثور على نتيجة مناسبة.']));
      return;
    }
    const download = await ctx.bot.queues.music.add(() => youtube.downloadMp3(result.url, Number(ctx.bot.config.limits?.maxAudioBytes || 40 * 1024 * 1024)));
    if (!download?.success || !download.filePath) throw new Error(download?.error || 'تعذر استخراج الصوت.');
    try {
      await ctx.sendAudio(download.filePath, box('اغنية', [`${result.title}`, 'تم تجهيز الصوت بصيغة MP3.']));
    } finally {
      await fs.remove(download.filePath).catch(() => {});
    }
  }
};
