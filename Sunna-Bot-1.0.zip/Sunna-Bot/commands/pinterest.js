const path = require('path');
const fs = require('fs-extra');
const { box } = require('../utils/messages');
const { search } = require('../services/pinterest');
const { downloadUrl } = require('../utils/downloader');

module.exports = {
  name: 'بن',
  description: 'البحث عن صور في Pinterest',
  cooldownMs: 6000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply(box('Pinterest', ['اكتب عبارة البحث بعد الامر.', '', '.بن فتاة انمي']));
      return;
    }
    const urls = await search(query, 4);
    if (!urls.length) {
      await ctx.reply(box('Pinterest', ['لم يتم العثور على صور.']));
      return;
    }
    for (let i = 0; i < urls.length; i += 1) {
      const url = urls[i];
      const file = path.join(ctx.bot.root, 'tmp', `pin-${Date.now()}-${i}.img`);
      try {
        await downloadUrl(url, { filePath: file, prefix: 'pin', ext: 'img', maxBytes: 20 * 1024 * 1024, timeoutMs: 20000 });
        await ctx.sendImage(file, i === 0 ? box('Pinterest', [`نتائج: ${query}`, `عرض ${urls.length} صور.`]) : '');
      } catch (error) {
        ctx.bot.logger.warn({ err: error }, 'Pinterest image download failed');
      } finally {
        await fs.remove(file).catch(() => {});
      }
    }
  }
};
