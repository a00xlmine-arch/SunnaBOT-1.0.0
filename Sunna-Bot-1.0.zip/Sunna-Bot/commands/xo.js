const { box } = require('../utils/messages');
const { games, newGame } = require('../games/xo');

function winner(board) {
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for (const [a,b,c] of lines) if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  return board.every(Boolean) ? 'draw' : null;
}
function render(board) {
  const v = board.map((x, i) => x || String(i + 1));
  return [`${v[0]} │ ${v[1]} │ ${v[2]}`, '───┼───┼───', `${v[3]} │ ${v[4]} │ ${v[5]}`, '───┼───┼───', `${v[6]} │ ${v[7]} │ ${v[8]}`];
}

module.exports = {
  name: 'اكس',
  description: 'لعبة XO',
  async execute(ctx) {
    const k = `${ctx.threadID}:${ctx.senderID}`;
    let game = games.get(k);
    if (!game) {
      game = newGame(ctx.senderID);
      games.set(k, game);
      await ctx.reply(box('اكس', [...render(game.board), '', 'دورك. استخدم .اكس 1-9']));
      return;
    }
    const pos = Number(ctx.args[0]) - 1;
    if (!Number.isInteger(pos) || pos < 0 || pos > 8 || game.board[pos]) {
      await ctx.reply(box('اكس', [...render(game.board), '', 'اختر خانة صحيحة وفارغة من 1 الى 9.']));
      return;
    }
    game.board[pos] = 'X';
    let result = winner(game.board);
    if (result === 'X') {
      games.delete(k);
      await ctx.bot.xp.addGameXP(ctx.threadID, ctx.senderID);
      await ctx.reply(box('اكس', [...render(game.board), '', 'فزت.', '+15 XP']));
      return;
    }
    if (result === 'draw') {
      games.delete(k);
      await ctx.reply(box('اكس', [...render(game.board), '', 'تعادل.']));
      return;
    }
    const empties = game.board.map((x, i) => x ? -1 : i).filter(i => i >= 0);
    const aiMove = empties[Math.floor(Math.random() * empties.length)];
    game.board[aiMove] = 'O';
    result = winner(game.board);
    if (result === 'O') {
      games.delete(k);
      await ctx.reply(box('اكس', [...render(game.board), '', 'فازت Sunna.']));
      return;
    }
    await ctx.reply(box('اكس', [...render(game.board), '', 'دورك.']));
  }
};
