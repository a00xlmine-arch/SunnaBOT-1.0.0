const { box } = require('../utils/messages');

module.exports = {
  name: 'بينغ',
  description: 'فحص الاستجابة',
  cooldownMs: 1000,
  async execute(ctx) {
    const start = Date.now();
    await ctx.reply(box('بينغ', [`النظام يعمل.`, `زمن التنفيذ: ${Date.now() - start}ms`]));
  }
};
