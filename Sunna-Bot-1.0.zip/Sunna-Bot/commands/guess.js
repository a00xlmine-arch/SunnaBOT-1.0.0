const { box } = require('../utils/messages');
const state = require('../games/guess');

module.exports = {
  name: 'خمن',
  description: 'لعبة تخمين الرقم',
  cooldownMs: 800,
  async execute(ctx) {
    const k = state.key(ctx.threadID, ctx.senderID);
    let game = state.games.get(k);
    if (!game) {
      game = { target: state.start(), attempts: 0 };
      state.games.set(k, game);
      await ctx.reply(box('خمن الرقم', ['لدي رقم بين 1 و100.', 'ارسل تخمينك بعد .خمن.']));
      return;
    }
    const guess = Number(ctx.args[0]);
    if (!Number.isInteger(guess) || guess < 1 || guess > 100) {
      await ctx.reply(box('خمن الرقم', ['اكتب رقما صحيحا بين 1 و100.']));
      return;
    }
    game.attempts += 1;
    if (guess === game.target) {
      state.games.delete(k);
      await ctx.bot.xp.addGameXP(ctx.threadID, ctx.senderID);
      await ctx.reply(box('خمن الرقم', [`اصبت الرقم بعد ${game.attempts} محاولات.`, '+15 XP']));
      return;
    }
    await ctx.reply(guess < game.target ? 'اعلى.' : 'اقل.');
  }
};
