const { box } = require('../utils/messages');

module.exports = {
  name: 'معلومات',
  description: 'معلومات البوت',
  cooldownMs: 1000,
  async execute(ctx) {
    await ctx.reply(box('معلومات', [
      `الاسم: ${ctx.bot.config.botName}`,
      `الاصدار: 1.0.0`,
      `المطور: ${ctx.bot.config.developer}`,
      `البادئة: ${ctx.bot.config.prefix}`
    ]));
  }
};
