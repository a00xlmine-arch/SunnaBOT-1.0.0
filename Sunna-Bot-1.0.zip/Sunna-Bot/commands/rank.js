const { box } = require('../utils/messages');

module.exports = {
  name: 'رتبتي',
  description: 'عرض XP والمستوى والرتبة',
  async execute(ctx) {
    const user = await ctx.bot.xp.getUser(ctx.threadID, ctx.senderID);
    const all = await ctx.bot.xp.leaderboard(ctx.threadID, Object.keys(ctx.bot.xp.data.threads[String(ctx.threadID)]?.users || {}).length || 1);
    const position = Math.max(1, all.findIndex(x => String(x.uid) === String(ctx.senderID)) + 1);
    await ctx.reply(box('رتبتي', [
      `الاسم: ${user.name || ctx.senderID}`,
      `المستوى: ${user.level}`,
      `XP: ${user.xp}`,
      `الرتبة: ${user.rank}`,
      `الترتيب: #${position}`,
      `الرسائل: ${user.messageCount}`
    ]));
  }
};
