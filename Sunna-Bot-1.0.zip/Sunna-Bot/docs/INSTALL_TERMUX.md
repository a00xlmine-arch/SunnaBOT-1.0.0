# تثبيت Sunna Bot على Termux

## 1. تثبيت المتطلبات
```bash
pkg update -y
pkg install nodejs-lts git -y
node -v
npm -v
```

يجب ان يكون Node.js 24 او احدث. لا تستخدم Node 16 لهذا المشروع.

## 2. جلب المشروع
```bash
git clone https://github.com/a00xlmine-arch/Sunna.git Sunna-Bot
cd Sunna-Bot
```

او استخدم مجلد المشروع الذي تم تنزيله سابقا.

## 3. اعداد الملفات
ضع AppState داخل `config/appstate.json`.
ضع UID الادمن داخل `config/admins.json`.
اضبط `config/groups.json` للمجموعات المسموحة.
ضع Puter token في `config/secrets.json` اذا كنت ستستخدم `.صورة`.

## 4. التثبيت والفحص
```bash
npm install
npm run verify:structure
npm test
npm run doctor
```

## 5. التشغيل
```bash
npm start
```
