const { box } = require('../utils/messages');

module.exports = {
  type: 'leave',
  async handle(bot, event) {
    const uid = event.participantID;
    if (uid && String(uid) === String(bot.botUserId)) return;
    let name = event.participantName;
    if (!name && uid) {
      try { name = (await bot.profile.getUser(uid)).name; } catch (_) {}
    }
    name = name || uid || 'عضو';
    const author = String(event.senderID || '');
    let kicked = false;
    if (author && uid && author !== String(uid)) {
      try {
        const info = await bot.messenger.getThreadInfo(event.threadID);
        const admins = (info?.adminIDs || info?.adminIds || []).map(v => String(v.id || v));
        kicked = admins.includes(author);
      } catch (_) {}
    }
    if (kicked) {
      await bot.messenger.sendMessage(box('اشعار', [`تم طرد ${name} من المجموعة.`]), event.threadID);
    } else {
      await bot.messenger.sendMessage(box('مغادرة', [`غادر ${name} المجموعة.`, 'كانت رحلة قصيرة، لكننا لن ننسى مرورك.']), event.threadID);
    }
  }
};
