const { box } = require('../utils/messages');

module.exports = {
  type: 'startup',
  async handle(bot) {
    const message = box('Sunna Bot', ['تم تشغيل البوت بنجاح.', `البادئة: ${bot.config.prefix}`]);
    const allowed = bot.groupAccess.data.allowedThreadIds.map(String);
    for (const threadID of allowed) {
      try { await bot.messenger.sendMessage(message, threadID); } catch (error) {
        bot.logger.warn({ err: error, threadID }, 'startup announcement failed');
      }
    }
  }
};
