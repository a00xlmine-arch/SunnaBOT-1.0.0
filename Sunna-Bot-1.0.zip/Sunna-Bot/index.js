const path = require('path');
const fs = require('fs-extra');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const logger = require('./utils/logger');
const { loadConfig } = require('./core/config');
const MessengerAdapter = require('./core/messenger');
const { createPermissions } = require('./core/permissions');
const GroupAccess = require('./core/groupAccess');
const Cooldowns = require('./core/cooldowns');
const TaskQueue = require('./core/queue');
const Deduplication = require('./core/deduplication');
const CommandRouter = require('./core/commandRouter');
const { Dispatcher } = require('./core/dispatcher');
const { loadCommands } = require('./core/commandLoader');
const { loadEvents } = require('./core/eventLoader');
const ProfileService = require('./services/profile');
const XPService = require('./database/xp');

async function main() {
  const root = __dirname;
  const loaded = await loadConfig(root);
  const { config, credentials, admins } = loaded;
  await fs.ensureDir(path.join(root, 'data'));
  await fs.ensureDir(path.join(root, 'tmp'));
  await fs.ensureDir(path.join(root, 'logs'));

  const permissions = createPermissions(admins.adminIds);
  const groupAccess = await new GroupAccess(root).load();
  const messenger = new MessengerAdapter(root, credentials, logger);
  const profile = new ProfileService(messenger);
  const xp = await new XPService(root, config, profile, logger).load();
  const commands = loadCommands(root);
  const events = loadEvents(root);
  const bot = {
    root,
    config,
    credentials,
    logger,
    permissions,
    groupAccess,
    messenger,
    profile,
    xp,
    commands,
    events,
    cooldowns: new Cooldowns(),
    dedup: new Deduplication(),
    queues: {
      default: new TaskQueue(config.queues.default),
      image: new TaskQueue(config.queues.image),
      music: new TaskQueue(config.queues.music),
      canvas: new TaskQueue(config.queues.canvas)
    },
    botUserId: null,
    router: null
  };
  bot.router = new CommandRouter(bot, commands);
  bot.dispatcher = new Dispatcher(bot);

  logger.info({ developer: config.developer, commands: commands.size, events: events.length }, 'starting Sunna Bot');
  await messenger.login();
  bot.botUserId = messenger.getCurrentUserId();
  logger.info({ botUserId: bot.botUserId || 'unknown' }, 'Messenger connected');

  messenger.listen((error, rawEvent) => {
    if (error) {
      logger.error({ err: error }, 'Messenger listener error');
      return;
    }
    bot.dispatcher.dispatch(rawEvent).catch(err => logger.error({ err }, 'event dispatch failed'));
  });

  const startup = events.find(e => e.type === 'startup');
  if (startup) await startup.handle(bot, { type: 'startup', threadID: null });

  const shutdown = async signal => {
    logger.info({ signal }, 'shutting down');
    try {
      await xp.shutdown?.();
      bot.messenger.api?.logout?.();
    } catch (error) {
      logger.error({ err: error }, 'shutdown failed');
    } finally {
      process.exit(0);
    }
  };
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));

  logger.info('Sunna Bot is ready');
}

main().catch(error => {
  logger.error({ err: error }, 'startup failed');
  process.exitCode = 1;
});
