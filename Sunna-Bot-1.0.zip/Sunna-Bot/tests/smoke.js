const assert = require('assert');
const path = require('path');
const fs = require('fs-extra');

const root = path.resolve(__dirname, '..');

async function main() {
  const config = await fs.readJson(path.join(root, 'config/config.json'));
  assert.strictEqual(config.developer, 'Rin Il');
  assert.strictEqual(config.prefix, '.');

  const { loadCommands } = require('../core/commandLoader');
  const commands = loadCommands(root);
  const expected = ['مساعدة','معلومات','بينغ','صورة','بن','اغنية','كانفس','حب','رتبتي','المتصدرين','حجر','خمن','اكس','تفعيل','تعطيل'];
  for (const name of expected) assert.ok(commands.has(name), `missing command ${name}`);
  assert.strictEqual(commands.size, 15);
  assert.ok(!commands.has('كانفس_رمادي'));


  const { registerDefaults, effects } = require('../canvas/engine');
  registerDefaults();
  for (const name of ['قلب','رمادي','ضباب','بكسل','مراة','دوران','خلل','الوان','موجة','عين','كرتون','شبح','ملعون']) {
    assert.ok(effects.has(name), `missing effect ${name}`);
  }

  const { normalizeEvent } = require('../core/dispatcher');
  const event = normalizeEvent({ type: 'message', threadID: 'thread', senderID: 'user', messageID: 'msg', body: '.رتبتي' });
  assert.deepStrictEqual({ type: event.type, threadID: event.threadID, senderID: event.senderID, body: event.body }, {
    type: 'message', threadID: 'thread', senderID: 'user', body: '.رتبتي'
  });


  const CommandRouter = require('../core/commandRouter');
  let routedName = null;
  const routerBot = {
    config: { prefix: '.', cooldowns: { defaultMs: 0 } },
    groupAccess: { isAllowed: () => true },
    permissions: { isBotAdmin: () => true },
    cooldowns: { check: () => 0 },
    messenger: { sendMessage: async () => {} },
    logger: { error: () => {} }
  };
  const router = new CommandRouter(routerBot, new Map([['كانفس', {
    name: 'كانفس',
    async execute(ctx) { routedName = ctx.commandName; }
  }]]));
  await router.handle({ type: 'message', threadID: 't', senderID: 'u', messageID: 'm', body: '.كانفس_رمادي', attachments: [] });
  assert.strictEqual(routedName, 'كانفس_رمادي');

  const { createPermissions } = require('../core/permissions');
  const permissions = createPermissions(['123']);
  assert.strictEqual(permissions.isBotAdmin('123'), true);
  assert.strictEqual(permissions.isBotAdmin('456'), false);

  console.log('Sunna Bot smoke tests passed.');
}

main().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
