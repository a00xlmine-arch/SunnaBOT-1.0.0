const fs = require('fs-extra');
const path = require('path');

const root = path.resolve(__dirname, '..');
const requiredFiles = [
  'index.js', 'package.json',
  'config/config.json', 'config/appstate.json', 'config/secrets.json', 'config/admins.json', 'config/groups.json',
  'data/users.json'
];

function fail(message) {
  console.error(`[FAIL] ${message}`);
  process.exitCode = 1;
}

function main() {
  console.log('Sunna Bot doctor');
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 24) fail(`Node.js ${process.versions.node} detected. Sunna Bot requires Node.js 24+.`);

  for (const file of requiredFiles) {
    const full = path.join(root, file);
    if (!fs.existsSync(full)) fail(`Missing file: ${file}`);
    else if (!fs.statSync(full).isFile() || fs.statSync(full).size === 0) fail(`Empty or invalid file: ${file}`);
  }

  const config = fs.readJsonSync(path.join(root, 'config/config.json'));
  const appState = fs.readJsonSync(path.join(root, 'config/appstate.json'));
  const secrets = fs.readJsonSync(path.join(root, 'config/secrets.json'));
  const admins = fs.readJsonSync(path.join(root, 'config/admins.json'));
  const groups = fs.readJsonSync(path.join(root, 'config/groups.json'));

  if (config.developer !== 'Rin Il') fail('Developer metadata is not Rin Il.');
  if (config.prefix !== '.') fail('Prefix is not configured as .');
  if (!Array.isArray(appState) || appState.length === 0) fail('config/appstate.json does not contain a valid non-empty AppState array.');
  if (!secrets || typeof secrets !== 'object') fail('config/secrets.json is invalid.');
  if (!Array.isArray(admins.adminIds) || admins.adminIds.length === 0) fail('config/admins.json has no adminIds.');
  if (groups.mode !== 'allowlist' || !Array.isArray(groups.allowedThreadIds)) fail('config/groups.json must use allowlist mode.');

  const commandFiles = fs.readdirSync(path.join(root, 'commands')).filter(file => file.endsWith('.js'));
  const commandNames = new Set();
  for (const file of commandFiles) {
    const mod = require(path.join(root, 'commands', file));
    if (!mod.name || typeof mod.execute !== 'function') fail(`Invalid command: ${file}`);
    for (const name of [mod.name, ...(mod.aliases || [])]) {
      if (commandNames.has(name)) fail(`Duplicate command: ${name}`);
      commandNames.add(name);
    }
  }

  const effectFiles = fs.readdirSync(path.join(root, 'canvas/effects')).filter(file => file.endsWith('.js'));
  for (const file of effectFiles) {
    const mod = require(path.join(root, 'canvas/effects', file));
    if (!mod.name || typeof mod.apply !== 'function') fail(`Invalid Canvas effect: ${file}`);
  }

  console.log(`[OK] Node ${process.versions.node}`);
  console.log(`[OK] Commands: ${commandNames.size}`);
  console.log(`[OK] Canvas effects: ${effectFiles.length}`);
  console.log(`[OK] Events: ${fs.readdirSync(path.join(root, 'events')).filter(f => f.endsWith('.js')).length}`);
  if (process.exitCode) process.exit(1);
  console.log('[OK] Structure and configuration checks passed.');
}

main();
