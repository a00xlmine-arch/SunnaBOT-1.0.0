# اعداد Sunna Bot

1. ضع AppState الكامل للحساب داخل `config/appstate.json`.
2. ضع UID حسابك في `config/admins.json` داخل `adminIds`.
3. ضع المجموعات المسموحة في `config/groups.json` او استخدم `.تفعيل` من حساب الادمن داخل المجموعة.
4. ضع Puter auth token في `config/secrets.json` اذا كنت ستستخدم `.صورة`.

هذه الملفات موجودة داخل المشروع لتسهيل الاعداد. لا ترفعها الى GitHub، وهي مدرجة في `.gitignore`.
