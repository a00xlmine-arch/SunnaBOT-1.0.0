const { box } = require('../utils/messages');

module.exports = {
  name: 'rank',
  description: 'عرض XP والمستوى والرتبة',
  async execute(ctx) {
    const user = await ctx.bot.xp.getUser(ctx.threadID, ctx.senderID);
    const nextRequired = ctx.bot.xp.requiredForNextLevel(user.level);
    const currentFloor = ctx.bot.xp.totalXpBeforeLevel(user.level);
    const progress = Math.max(0, user.xp - currentFloor);
    await ctx.reply(box('⭐ رتبتك', [
      `الاسم: ${user.name || user.uid}`,
      `المستوى: ${user.level}`,
      `الرتبة: ${user.rank}`,
      `XP: ${user.xp}`,
      `التقدم: ${progress} / ${nextRequired}`,
      `الرسائل: ${user.messageCount}`
    ]));
  }
};
