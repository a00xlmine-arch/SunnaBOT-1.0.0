const { box } = require('../utils/messages');
const { normalizeMessageId } = require('../core/gameSessions');

const CHOICES = {
  حجر: 'rock', '✊': 'rock', rock: 'rock',
  ورق: 'paper', '✋': 'paper', paper: 'paper',
  مقص: 'scissors', '✌️': 'scissors', '✌': 'scissors', scissors: 'scissors'
};
const LABELS = { rock: '✊ حجر', paper: '✋ ورق', scissors: '✌️ مقص' };
const BEATS = { rock: 'scissors', paper: 'rock', scissors: 'paper' };

module.exports = {
  name: 'rps',
  description: 'لعبة حجر ورق مقص بالرد',
  async execute(ctx) {
    if (ctx.bot.gameSessions.hasActive(ctx.threadID, ctx.senderID, 'rps')) {
      await ctx.reply(box('🎮 حجر ورق مقص', ['لديك لعبة نشطة بالفعل.', 'رد على رسالة اللعبة الحالية.']));
      return;
    }

    const sent = await ctx.reply(box('🎮 حجر ورق مقص', [
      'اختر واحدا:',
      '✊ حجر',
      '✋ ورق',
      '✌️ مقص',
      '',
      '↩️ رد على هذه الرسالة باختيارك.'
    ]));
    const messageID = normalizeMessageId(sent);
    if (!messageID) throw new Error('تعذر تتبع رسالة اللعبة.');

    const session = ctx.bot.gameSessions.create({
      id: messageID,
      type: 'rps',
      threadID: ctx.threadID,
      playerID: ctx.senderID,
      expiresMs: 180000,
      data: {}
    });

    session.onExpire = async () => ctx.bot.messenger.sendMessage(box('🎮 حجر ورق مقص', ['انتهت اللعبة لعدم وجود رد.']), ctx.threadID);

    session.handle = async event => {
      const choice = CHOICES[String(event.body || '').trim().toLowerCase()];
      if (!choice) {
        const invalid = await ctx.bot.messenger.sendMessage(box('🎮 حجر ورق مقص', ['الاختيار غير صالح.', 'اكتب حجر او ورق او مقص.', '↩️ رد على هذه الرسالة باختيارك.']), ctx.threadID);
        ctx.bot.gameSessions.updateMessage(session.id, normalizeMessageId(invalid));
        return;
      }
      const botChoice = ['rock', 'paper', 'scissors'][Math.floor(Math.random() * 3)];
      const result = choice === botChoice ? 'تعادل.' : BEATS[choice] === botChoice ? 'فزت.' : 'خسرت.';
      if (result === 'فزت.') await ctx.bot.xp.addGameXP(ctx.threadID, ctx.senderID);
      ctx.bot.gameSessions.finish(session.id);
      await ctx.bot.messenger.sendMessage(box('🎮 النتيجة', [
        `اختيارك: ${LABELS[choice]}`,
        `اختيار Sunna: ${LABELS[botChoice]}`,
        `النتيجة: ${result}`,
        result === 'فزت.' ? '+15 XP' : ''
      ]), ctx.threadID);
    };
  }
};
