const path = require('path');
const fs = require('fs-extra');
const { box, menu } = require('../utils/messages');
const { processImage, registerDefaults, getEffectNames } = require('../canvas/engine');
const { sourceFor, downloadImage } = require('../canvas/imageSource');

const effects = [
  ['heart', 'قلب الالوان'],
  ['gray', 'تحويل الصورة الى رمادي'],
  ['blur', 'تاثير ضبابي'],
  ['pixel', 'تاثير بكسلات'],
  ['mirror', 'عكس الصورة'],
  ['rotate', 'تدوير الصورة'],
  ['glitch', 'تاثير Glitch'],
  ['colors', 'تشويه قنوات الالوان'],
  ['wave', 'تاثير الموجات'],
  ['fisheye', 'تاثير العدسة المشوهة'],
  ['cartoon', 'مظهر كرتوني'],
  ['ghost', 'تاثير شبحي'],
  ['cursed', 'تاثير مشوه ومرعب']
];

module.exports = {
  name: 'canvas',
  description: 'معالجة الصور بالمؤثرات',
  cooldownMs: 5000,
  async execute(ctx) {
    registerDefaults();
    const requested = String(ctx.args[0] || '').toLowerCase();

    if (!requested) {
      const available = getEffectNames();
      const items = effects
        .filter(([name]) => available.includes(name))
        .map(([name, description]) => `• .canvas ${name} — ${description}`);
      await ctx.reply(menu('🎨 Canvas', [
        { title: 'المؤثرات المتاحة', items },
        { title: 'طريقة الاستخدام', items: ['رد على صورة ثم اكتب الامر.', 'بدون رد سيستخدم البوت صورة حسابك.'] }
      ]));
      return;
    }

    const available = getEffectNames();
    if (!available.includes(requested)) {
      await ctx.reply(box('🎨 Canvas', ['هذا المؤثر غير موجود.', 'اكتب .canvas لرؤية القائمة.']));
      return;
    }

    const inputUrl = await sourceFor(ctx);
    const input = await downloadImage(inputUrl, ctx.bot.root);
    const output = path.join(ctx.bot.root, 'tmp', `canvas-${Date.now()}-${process.pid}.png`);
    try {
      await ctx.bot.queues.canvas.add(() => processImage(input, requested, output));
      await ctx.sendImage(output);
    } finally {
      await fs.remove(input).catch(() => {});
      await fs.remove(output).catch(() => {});
    }
  }
};
