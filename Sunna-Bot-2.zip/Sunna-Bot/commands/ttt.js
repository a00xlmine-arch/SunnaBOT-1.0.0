const { box } = require('../utils/messages');
const { normalizeMessageId } = require('../core/gameSessions');

const EMPTY = n => `${n}\u20e3`;
const WIN_LINES = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

function render(board) {
  const cells = board.map((cell, index) => cell || EMPTY(index + 1));
  return [
    `${cells[0]} ${cells[1]} ${cells[2]}`,
    `${cells[3]} ${cells[4]} ${cells[5]}`,
    `${cells[6]} ${cells[7]} ${cells[8]}`
  ];
}

function winner(board) {
  for (const [a, b, c] of WIN_LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(Boolean) ? 'draw' : null;
}

function botMove(board) {
  const empty = board.map((cell, index) => cell ? -1 : index).filter(index => index >= 0);
  if (!empty.length) return null;
  return empty[Math.floor(Math.random() * empty.length)];
}

module.exports = {
  name: 'ttt',
  description: 'لعبة XO بالرد',
  async execute(ctx) {
    if (ctx.bot.gameSessions.hasActive(ctx.threadID, ctx.senderID, 'ttt')) {
      await ctx.reply(box('🎮 XO', ['لديك لعبة نشطة بالفعل.', 'رد على اخر رسالة في اللعبة.']));
      return;
    }

    const sent = await ctx.reply(box('🎮 XO', [
      'انت ❌ وSunna ✅',
      ...render(Array(9).fill('')),
      '',
      '↩️ رد على هذه الرسالة برقم الخانة من 1 الى 9.'
    ]));
    const messageID = normalizeMessageId(sent);
    if (!messageID) throw new Error('تعذر تتبع رسالة اللعبة.');

    const session = ctx.bot.gameSessions.create({
      id: messageID,
      type: 'ttt',
      threadID: ctx.threadID,
      playerID: ctx.senderID,
      expiresMs: 180000,
      data: { board: Array(9).fill('') }
    });
    session.onExpire = async () => ctx.bot.messenger.sendMessage(box('🎮 XO', ['انتهت اللعبة لعدم وجود رد.']), ctx.threadID);

    session.handle = async event => {
      const pos = Number(String(event.body || '').trim()) - 1;
      if (!Number.isInteger(pos) || pos < 0 || pos > 8 || session.data.board[pos]) {
        const invalid = await ctx.bot.messenger.sendMessage(box('🎮 XO', [
          'الخانة غير صالحة.',
          'اكتب رقما من 1 الى 9 لخانة فارغة.',
          ...render(session.data.board),
          '',
          '↩️ رد على هذه الرسالة برقم.'
        ]), ctx.threadID);
        ctx.bot.gameSessions.updateMessage(session.id, normalizeMessageId(invalid));
        return;
      }

      session.data.board[pos] = '❌';
      let result = winner(session.data.board);
      if (result === '❌') {
        ctx.bot.gameSessions.finish(session.id);
        await ctx.bot.xp.addGameXP(ctx.threadID, ctx.senderID);
        await ctx.bot.messenger.sendMessage(box('🎮 XO', ['فزت.', ...render(session.data.board), '+15 XP']), ctx.threadID);
        return;
      }
      if (result === 'draw') {
        ctx.bot.gameSessions.finish(session.id);
        await ctx.bot.messenger.sendMessage(box('🎮 XO', ['تعادل.', ...render(session.data.board)]), ctx.threadID);
        return;
      }

      const move = botMove(session.data.board);
      if (move !== null) session.data.board[move] = '✅';
      result = winner(session.data.board);
      if (result === '✅') {
        ctx.bot.gameSessions.finish(session.id);
        await ctx.bot.messenger.sendMessage(box('🎮 XO', ['فازت Sunna.', ...render(session.data.board)]), ctx.threadID);
        return;
      }
      if (result === 'draw') {
        ctx.bot.gameSessions.finish(session.id);
        await ctx.bot.messenger.sendMessage(box('🎮 XO', ['تعادل.', ...render(session.data.board)]), ctx.threadID);
        return;
      }

      const next = await ctx.bot.messenger.sendMessage(box('🎮 XO', [
        'دورك.',
        ...render(session.data.board),
        '',
        '↩️ رد على هذه الرسالة برقم الخانة.'
      ]), ctx.threadID);
      ctx.bot.gameSessions.updateMessage(session.id, normalizeMessageId(next));
    };
  }
};
