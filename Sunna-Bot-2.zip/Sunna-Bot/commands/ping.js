const { box } = require('../utils/messages');

module.exports = {
  name: 'ping',
  description: 'فحص الاستجابة',
  cooldownMs: 1000,
  async execute(ctx) {
    const start = Date.now();
    await ctx.reply(box('🏓 Ping', [`الاستجابة: ${Date.now() - start}ms`, 'Sunna Bot يعمل بشكل طبيعي.']));
  }
};
