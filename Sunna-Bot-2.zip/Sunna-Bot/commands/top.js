const { box } = require('../utils/messages');

module.exports = {
  name: 'top',
  description: 'عرض المتصدرين في XP داخل المجموعة',
  async execute(ctx) {
    const rows = await ctx.bot.xp.leaderboard(ctx.threadID, 10);
    const lines = rows.length ? rows.map((u, i) => `${i + 1}. ${u.name || u.uid} — Lv.${u.level} — ${u.xp} XP`) : ['لا توجد بيانات XP بعد.'];
    await ctx.reply(box('🏆 المتصدرين', lines));
  }
};
