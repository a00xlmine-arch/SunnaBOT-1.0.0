const path = require('path');
const fs = require('fs-extra');
const { box } = require('../utils/messages');
const love = require('../services/love');

function getReplyTarget(ctx) {
  const target = ctx.replyTarget || {};
  const uid = target.senderID || target.senderFbId || target.userID || target.author || target.senderId;
  return uid ? String(uid) : null;
}

async function randomPartner(bot, threadID, selfID) {
  const info = await bot.messenger.getThreadInfo(threadID);
  const ids = Array.isArray(info?.participantIDs)
    ? info.participantIDs.map(String)
    : Array.isArray(info?.participantIds)
      ? info.participantIds.map(String)
      : [];
  const candidates = ids.filter(id => id && id !== String(selfID) && id !== String(bot.botUserId));
  if (!candidates.length) throw new Error('لا يوجد عضو اخر صالح للاختيار.');
  return candidates[Math.floor(Math.random() * candidates.length)];
}

module.exports = {
  name: 'love',
  description: 'حساب نسبة الحب والترابط بين عضوين',
  cooldownMs: 6000,
  async execute(ctx) {
    const secondId = getReplyTarget(ctx) || await randomPartner(ctx.bot, ctx.threadID, ctx.senderID);
    if (String(secondId) === String(ctx.senderID)) throw new Error('لا يمكن اختيار نفسك في اختبار الحب.');

    const [one, two] = await Promise.all([
      ctx.bot.profile.getUser(ctx.senderID),
      ctx.bot.profile.getUser(secondId)
    ]);

    if (!one.avatarUrl || !two.avatarUrl) {
      throw new Error('تعذر الحصول على صور الحسابات من Messenger.');
    }

    const [a, b] = await Promise.all([
      love.downloadAvatar(one.avatarUrl, ctx.bot.root, 'a'),
      love.downloadAvatar(two.avatarUrl, ctx.bot.root, 'b')
    ]);

    const out = path.join(ctx.bot.root, 'tmp', `love-${Date.now()}-${process.pid}.png`);
    const score = love.percentages(ctx.senderID, secondId);
    try {
      await ctx.bot.queues.canvas.add(() => love.compose(a, b, out));
      await ctx.sendImage(out, box('💗 اختبار الحب', [
        `${one.name} × ${two.name}`,
        '',
        `الحب: ${score.love}%`,
        `التوافق: ${score.compatibility}%`,
        `الترابط: ${score.bond}%`,
        `التقييم: ${love.verdict(score.bond)}`
      ]));
    } finally {
      await Promise.all([a, b, out].map(file => fs.remove(file).catch(() => {})));
    }
  }
};
