const { box } = require('../utils/messages');
const { normalizeMessageId } = require('../core/gameSessions');

module.exports = {
  name: 'guess',
  description: 'لعبة تخمين الرقم بالرد',
  async execute(ctx) {
    if (ctx.bot.gameSessions.hasActive(ctx.threadID, ctx.senderID, 'guess')) {
      await ctx.reply(box('🎯 خمن الرقم', ['لديك لعبة نشطة بالفعل.', 'رد على رسالة اللعبة الحالية برقم.']));
      return;
    }

    const sent = await ctx.reply(box('🎯 خمن الرقم', [
      'اخترت رقما بين 1 و100.',
      'كل رد برقم هو محاولة واحدة.',
      '',
      '↩️ رد على هذه الرسالة برقمك.'
    ]));
    const messageID = normalizeMessageId(sent);
    if (!messageID) throw new Error('تعذر تتبع رسالة اللعبة.');

    const session = ctx.bot.gameSessions.create({
      id: messageID,
      type: 'guess',
      threadID: ctx.threadID,
      playerID: ctx.senderID,
      expiresMs: 180000,
      data: { target: Math.floor(Math.random() * 100) + 1, attempts: 0 }
    });

    session.onExpire = async () => ctx.bot.messenger.sendMessage(box('🎯 خمن الرقم', ['انتهت اللعبة لعدم وجود رد.']), ctx.threadID);

    session.handle = async event => {
      const guess = Number(String(event.body || '').trim());
      if (!Number.isInteger(guess) || guess < 1 || guess > 100) {
        const invalid = await ctx.bot.messenger.sendMessage(box('🎯 خمن الرقم', ['الرد يجب ان يكون رقما بين 1 و100.', '↩️ رد على هذه الرسالة برقم.']), ctx.threadID);
        ctx.bot.gameSessions.updateMessage(session.id, normalizeMessageId(invalid));
        return;
      }
      session.data.attempts += 1;
      if (guess === session.data.target) {
        ctx.bot.gameSessions.finish(session.id);
        await ctx.bot.xp.addGameXP(ctx.threadID, ctx.senderID);
        await ctx.bot.messenger.sendMessage(box('🎯 خمن الرقم', [
          `اصبت الرقم بعد ${session.data.attempts} محاولات.`,
          '+15 XP'
        ]), ctx.threadID);
        return;
      }
      const hint = await ctx.bot.messenger.sendMessage(
        box('🎯 خمن الرقم', [guess < session.data.target ? 'الرقم اكبر.' : 'الرقم اصغر.', '↩️ رد على هذه الرسالة برقم اخر.']),
        ctx.threadID
      );
      ctx.bot.gameSessions.updateMessage(session.id, normalizeMessageId(hint));
    };
  }
};
