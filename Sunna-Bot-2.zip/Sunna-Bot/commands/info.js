const os = require('os');
const { box } = require('../utils/messages');

module.exports = {
  name: 'info',
  description: 'عرض معلومات البوت',
  cooldownMs: 1000,
  async execute(ctx) {
    const uptime = formatUptime(process.uptime());
    await ctx.reply(box('🤖 Sunna Bot', [
      `الاصدار: ${ctx.bot.config.version || '1.0.2'}`,
      `المطور: ${ctx.bot.config.developer}`,
      'النظام: Messenger Bot',
      `Node.js: ${process.versions.node}`,
      `وقت التشغيل: ${uptime}`,
      `الاوامر: ${ctx.bot.commands.size}`,
      `الحالة: 🟢 يعمل`,
      `الجهاز: ${os.platform()} ${os.arch()}`
    ]));
  }
};

function formatUptime(seconds) {
  const total = Math.floor(Number(seconds) || 0);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  return [days ? `${days}ي` : '', hours ? `${hours}س` : '', minutes ? `${minutes}د` : '', `${secs}ث`]
    .filter(Boolean)
    .join(' ');
}
