const { menu } = require('../utils/messages');

module.exports = {
  name: 'help',
  description: 'عرض قائمة الاوامر',
  cooldownMs: 1000,
  async execute(ctx) {
    const text = menu('☀️ Sunna Bot', [
      { title: '🖼️ الصور', items: [
        '.image — توليد صورة بالذكاء الاصطناعي',
        '.pin — البحث عن صور في Pinterest',
        '.canvas — مؤثرات الصور',
        '.love — حساب نسبة الحب والترابط'
      ] },
      { title: '🎵 الموسيقى', items: [
        '.song — البحث عن اغنية واستخراج MP3'
      ] },
      { title: '🎮 الالعاب', items: [
        '.rps — حجر ورق مقص',
        '.guess — تخمين رقم من 1 الى 100',
        '.ttt — لعبة XO'
      ] },
      { title: '⭐ المستوى', items: [
        '.rank — معلومات مستواك وXP',
        '.top — المتصدرين في المجموعة'
      ] },
      { title: 'ℹ️ البوت', items: [
        '.info — معلومات Sunna Bot',
        '.ping — فحص الاستجابة'
      ] },
      { title: '⚙️ الادارة', items: [
        '.enable — تفعيل البوت للمجموعة',
        '.disable — تعطيل البوت للمجموعة'
      ] }
    ]);
    await ctx.reply(`${text}\n\n🎨 مؤثرات Canvas: .canvas\n↩️ الالعاب تتابع بالرد على رسالة اللعبة.`);
  }
};
