const path = require('path');
const fs = require('fs-extra');
const { box } = require('../utils/messages');
const { search } = require('../services/pinterest');
const { downloadMedia } = require('../utils/downloader');
const { normalizeToPng } = require('../services/imageMedia');

module.exports = {
  name: 'pin',
  description: 'البحث عن صور في Pinterest',
  cooldownMs: 6000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply(box('📌 Pinterest', ['اكتب عبارة البحث بعد الامر.', '', '.pin فتاة انمي']));
      return;
    }

    const urls = await search(query, 4);
    if (!urls.length) {
      await ctx.reply(box('📌 Pinterest', ['لم يتم العثور على صور مناسبة.']));
      return;
    }

    let sent = 0;
    for (let i = 0; i < urls.length; i += 1) {
      let media = null;
      let normalizedPath = null;
      try {
        media = await downloadMedia(urls[i], 'image', {
          tempDir: path.join(ctx.bot.root, 'tmp'),
          maxBytes: Number(ctx.bot.config.limits?.maxDownloadedImageBytes || 20 * 1024 * 1024),
          headers: {
            Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            Referer: 'https://www.pinterest.com/'
          }
        });
        normalizedPath = path.join(ctx.bot.root, 'tmp', `pin-${Date.now()}-${process.pid}-${i}.png`);
        await normalizeToPng(media.path, normalizedPath);
        const caption = sent === 0
          ? box('📌 Pinterest', [`البحث: ${query}`, `تم ارسال ${urls.length} نتائج.`])
          : '';
        await ctx.sendImage(normalizedPath, caption);
        sent += 1;
      } catch (error) {
        ctx.bot.logger.warn({ err: error }, 'Pinterest image failed');
      } finally {
        await media?.cleanup?.().catch(() => {});
        await fs.remove(normalizedPath).catch(() => {});
      }
    }

    if (!sent) throw new Error('تعذر ارسال نتائج Pinterest كصور.');
  }
};
