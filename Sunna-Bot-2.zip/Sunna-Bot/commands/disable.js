const { box } = require('../utils/messages');
module.exports = {
  name: 'disable',
  description: 'تعطيل البوت في المجموعة الحالية',
  adminOnly: true,
  cooldownMs: 1000,
  async execute(ctx) {
    await ctx.bot.groupAccess.disable(ctx.threadID);
    await ctx.reply(box('⚙️ المجموعة', ['تم تعطيل Sunna Bot في هذه المجموعة.']));
  }
};
