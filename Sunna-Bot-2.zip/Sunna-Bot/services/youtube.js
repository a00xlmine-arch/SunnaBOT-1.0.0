const fs = require('fs-extra');
const path = require('path');

let clientPromise = null;

function isYouTubeUrl(value) {
  try {
    const url = new URL(String(value));
    return /(^|\.)youtube\.com$|(^|\.)youtu\.be$/.test(url.hostname);
  } catch (_) {
    return false;
  }
}

function isRemoteUrl(value) { return /^https?:\/\//i.test(String(value || '').trim()); }

async function getClient() {
  if (!clientPromise) {
    clientPromise = (async () => {
      const mod = await import('youtubei.js');
      const Innertube = mod.Innertube || mod.default;
      if (!Innertube) throw new Error('تعذر تحميل YouTube.js.');
      return Innertube.create({ lang: 'ar', location: 'MA', retrieve_player: false });
    })();
  }
  return clientPromise;
}

async function search(query) {
  const value = String(query || '').trim();
  if (!value) return null;
  if (isYouTubeUrl(value)) return { url: value, title: 'YouTube video' };

  const youtube = await getClient();
  const result = await youtube.search(value, { type: 'video' });
  const videos = Array.isArray(result?.videos) ? result.videos : [];
  const first = videos.find(video => video?.id);
  if (!first) return null;

  const title = typeof first.title === 'string' ? first.title : String(first.title?.text || 'YouTube video');
  return { id: String(first.id), url: first.url || `https://www.youtube.com/watch?v=${first.id}`, title };
}

async function normalizeDownloadResult(result, maxBytes, root) {
  if (!result?.success || !result.filePath) throw new Error(result?.error || 'مزود التحميل لم يرجع صوتا.');
  let filePath = String(result.filePath);
  let cleanup = null;

  if (isRemoteUrl(filePath)) {
    const media = await require('@hiudyy/ytdl').downloadToTemp({
      url: filePath,
      kind: 'audio',
      tempDir: path.join(root, 'tmp')
    });
    if (!media?.path) throw new Error('تعذر تنزيل رابط الصوت.');
    filePath = media.path;
    cleanup = media.cleanup;
  }

  if (isRemoteUrl(filePath)) throw new Error('رابط الصوت لم يتحول الى ملف محلي.');
  const stat = await fs.stat(filePath);
  if (!stat.isFile() || stat.size <= 0) throw new Error('ملف الصوت غير صالح.');
  if (stat.size > maxBytes) {
    await fs.remove(filePath).catch(() => {});
    await cleanup?.().catch(() => {});
    throw new Error('الصوت اكبر من الحد المسموح.');
  }
  return { ...result, filePath, size: stat.size, cleanup };
}

async function downloadMp3(url, maxBytes = 40 * 1024 * 1024, root = process.cwd()) {
  const { downloadYouTube } = require('@hiudyy/ytdl');
  let lastError = null;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      const result = await downloadYouTube(String(url), 'mp3');
      return await normalizeDownloadResult(result, maxBytes, root);
    } catch (error) {
      lastError = error;
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1500));
    }
  }
  return { success: false, error: lastError?.message || 'تعذر استخراج الصوت.' };
}

module.exports = { search, downloadMp3 };
