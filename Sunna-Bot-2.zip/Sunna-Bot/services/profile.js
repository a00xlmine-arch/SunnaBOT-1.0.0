class ProfileService {
  constructor(messenger) {
    this.messenger = messenger;
    this.cache = new Map();
    this.ttl = 10 * 60 * 1000;
  }

  async getUser(uid) {
    const key = String(uid);
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now()) return cached.value;

    const raw = await this.messenger.getUserInfo(key);
    const value = raw?.[key] || raw?.[String(key)] || raw || {};
    const avatarCandidates = [
      value.profilePicUrl,
      value.thumbSrc,
      value.profilePictureUrl,
      value.profilePic,
      value.avatarUrl,
      value.avatar
    ];
    const avatarUrl = avatarCandidates.find(isUsableImageUrl) || null;
    const normalized = {
      uid: key,
      name: value.name || value.fullName || value.firstName || key,
      avatarUrl
    };
    this.cache.set(key, { value: normalized, expiresAt: Date.now() + this.ttl });
    return normalized;
  }

  invalidate(uid) { this.cache.delete(String(uid)); }
}

function isUsableImageUrl(value) {
  if (!value || typeof value !== 'string') return false;
  if (/^data:image\//i.test(value)) return true;
  if (!/^https?:\/\//i.test(value)) return false;
  try {
    const url = new URL(value);
    return !/\/profile\.php(?:$|\?)/i.test(url.pathname);
  } catch (_) {
    return false;
  }
}

module.exports = ProfileService;
