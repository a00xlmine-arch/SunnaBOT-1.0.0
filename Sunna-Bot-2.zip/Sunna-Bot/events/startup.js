const { box } = require('../utils/messages');
module.exports = {
  type: 'startup',
  async handle(bot) {
    const message = box('☀️ Sunna Bot', ['🟢 تم تشغيل البوت بنجاح.', `البادئة: ${bot.config.prefix}`, `الاصدار: ${bot.config.version}`]);
    for (const threadID of bot.groupAccess.data.allowedThreadIds.map(String)) {
      try { await bot.messenger.sendMessage(message, threadID); }
      catch (error) { bot.logger.warn({ err: error, threadID }, 'startup announcement failed'); }
    }
  }
};
