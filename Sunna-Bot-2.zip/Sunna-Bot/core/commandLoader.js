const fs = require('fs-extra');
const path = require('path');

function loadCommands(root) {
  const dir = path.join(root, 'commands');
  const registry = new Map();
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort()) {
    const full = path.join(dir, file);
    delete require.cache[require.resolve(full)];
    const command = require(full);
    validateCommand(command, file);
    const names = [command.name, ...(command.aliases || [])].map(value => String(value).toLowerCase());
    for (const name of names) {
      if (registry.has(name)) throw new Error(`تعارض في الامر: ${name}`);
      registry.set(name, command);
    }
  }
  return registry;
}

function validateCommand(command, file) {
  if (!command || typeof command !== 'object') throw new Error(`امر غير صالح: ${file}`);
  if (!command.name || typeof command.execute !== 'function') throw new Error(`بنية الامر غير صالحة: ${file}`);
  if (!/^[a-z][a-z0-9_-]*$/i.test(String(command.name))) throw new Error(`اسم الامر يجب ان يكون انجليزيا: ${file}`);
}
module.exports = { loadCommands, validateCommand };
