function normalizeMessageId(result) {
  if (!result) return null;
  if (typeof result === 'string' || typeof result === 'number') return String(result);
  const value = result.messageID || result.messageId || result.id || result.mid || result?.payload?.messageID;
  return value === undefined || value === null ? null : String(value);
}

function replyMessageId(replyTarget) {
  return normalizeMessageId(replyTarget);
}

class GameSessions {
  constructor() {
    this.sessions = new Map();
  }

  create({ id, type, threadID, playerID, expiresMs, data = {} }) {
    const messageID = String(id);
    this.cancelForPlayer(threadID, playerID, type);
    const session = {
      id: messageID,
      messageID,
      type,
      threadID: String(threadID),
      playerID: String(playerID),
      data,
      handle: null,
      expiresAt: Date.now() + Number(expiresMs || 180000),
      timer: null,
      onExpire: null
    };
    session.timer = setTimeout(() => {
      const active = this.sessions.get(session.id);
      if (!active) return;
      this.finish(session.id);
      Promise.resolve(active.onExpire?.()).catch(() => {});
    }, Number(expiresMs || 180000));
    session.timer.unref?.();
    this.sessions.set(session.id, session);
    return session;
  }

  updateMessage(id, newMessageID) {
    if (!newMessageID) return false;
    const session = this.sessions.get(String(id));
    if (!session) return false;
    session.messageID = String(newMessageID);
    this.sessions.delete(session.id);
    session.id = String(newMessageID);
    this.sessions.set(session.id, session);
    return true;
  }

  hasActive(threadID, playerID, type) {
    for (const session of this.sessions.values()) {
      if (session.threadID === String(threadID) && session.playerID === String(playerID) && session.type === type) return true;
    }
    return false;
  }

  cancelForPlayer(threadID, playerID, type) {
    for (const session of [...this.sessions.values()]) {
      if (session.threadID === String(threadID) && session.playerID === String(playerID) && session.type === type) this.finish(session.id);
    }
  }

  findByReply(event) {
    const replyID = replyMessageId(event?.replyTarget);
    if (!replyID) return null;
    const session = this.sessions.get(replyID);
    if (!session) return null;
    if (session.expiresAt <= Date.now()) {
      this.finish(session.id);
      return null;
    }
    if (session.threadID !== String(event.threadID) || session.playerID !== String(event.senderID)) return null;
    return session;
  }

  async handle(event, bot) {
    const session = this.findByReply(event);
    if (!session || typeof session.handle !== 'function') return false;
    await session.handle(event, bot);
    return true;
  }

  finish(id) {
    const session = this.sessions.get(String(id));
    if (!session) return false;
    clearTimeout(session.timer);
    this.sessions.delete(session.id);
    return true;
  }

  stop() {
    for (const session of this.sessions.values()) clearTimeout(session.timer);
    this.sessions.clear();
  }
}

module.exports = { GameSessions, normalizeMessageId, replyMessageId };
