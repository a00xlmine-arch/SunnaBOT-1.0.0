const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const requiredFiles = [
  'index.js','package.json','.gitignore',
  'config/config.json','config/appstate.json','config/secrets.json','config/admins.json','config/groups.json',
  'data/users.json','tests/profile-smoke.js','core/messenger.js','core/dispatcher.js','core/commandRouter.js','core/commandLoader.js','core/eventLoader.js','core/permissions.js','core/groupAccess.js','core/cooldowns.js','core/queue.js','core/deduplication.js','core/gameSessions.js',
  'services/profile.js','services/love.js','services/imageAI.js','services/imageMedia.js','services/pinterest.js','services/youtube.js',
  'canvas/engine.js','canvas/imageSource.js','games/guess.js','games/xo.js','database/xp.js','utils/messages.js','utils/files.js','utils/downloader.js','utils/logger.js'
];
const expectedCommands = ['help','info','ping','image','pin','song','canvas','love','rank','top','rps','guess','ttt','enable','disable'];
const expectedEffects = ['heart','gray','blur','pixel','mirror','rotate','glitch','colors','wave','fisheye','cartoon','ghost','cursed'];
const expectedEvents = ['startup','join','leave'];
function read(file){return fs.readFileSync(path.join(root,file),'utf8');}
function json(file){return JSON.parse(read(file));}
function jsFiles(dir){return fs.readdirSync(path.join(root,dir)).filter(f=>f.endsWith('.js')).sort();}
function extractProperty(file,property){const m=read(file).match(new RegExp(`\\b${property}\\s*:\\s*['\"]([^'\"]+)['\"]`)); return m?.[1]||null;}
for(const file of requiredFiles){const full=path.join(root,file);assert.ok(fs.existsSync(full),`Missing required file: ${file}`);assert.ok(fs.statSync(full).isFile(),`Not a file: ${file}`);assert.ok(fs.statSync(full).size>0,`Empty required file: ${file}`);}
for(const dir of ['core','commands','events','services','canvas','canvas/effects','games','database','utils','scripts','tests','docs','config','data']){assert.ok(fs.existsSync(path.join(root,dir)),`Missing directory: ${dir}`);assert.ok(fs.readdirSync(path.join(root,dir)).length>0,`Empty directory: ${dir}`);}
const pkg=json('package.json'); assert.strictEqual(pkg.name,'sunna-bot'); assert.strictEqual(pkg.type,'commonjs'); assert.ok(pkg.engines?.node?.startsWith('>=24'),'Node engine must be >=24.');
for(const dep of ['@lazyneoaz/metachat','@heyputer/puter.js','@hiudyy/ytdl','axios','dotenv','fs-extra','jimp','@jimp/wasm-webp','pino','youtubei.js'])assert.ok(pkg.dependencies?.[dep],`Missing dependency: ${dep}`);
const config=json('config/config.json');assert.strictEqual(config.developer,'Rin Il');assert.strictEqual(config.prefix,'.');assert.strictEqual(config.version,'1.0.2');
assert.ok(Array.isArray(json('config/appstate.json')));assert.ok(Array.isArray(json('config/admins.json').adminIds));assert.strictEqual(json('config/groups.json').mode,'allowlist');assert.ok(Array.isArray(json('config/groups.json').allowedThreadIds));assert.ok(typeof json('config/secrets.json').puterAuthToken==='string');assert.ok(json('data/users.json').threads&&typeof json('data/users.json').threads==='object');
const commandSources=new Map();
for(const file of jsFiles('commands')){const rel=`commands/${file}`;const name=extractProperty(rel,'name');assert.ok(name,`Command has no static name: ${file}`);assert.ok(/^[a-z][a-z0-9_-]*$/i.test(name),`Non-English command name: ${name}`);assert.ok(!commandSources.has(name),`Duplicate command name: ${name}`);commandSources.set(name,file);}
for(const name of expectedCommands)assert.ok(commandSources.has(name),`Missing command source: ${name}`);assert.strictEqual(commandSources.size,15);
const effectSources=new Map();for(const file of jsFiles('canvas/effects')){const rel=`canvas/effects/${file}`;const name=extractProperty(rel,'name');assert.ok(name);assert.ok(!effectSources.has(name),`Duplicate effect: ${name}`);assert.ok(read(rel).includes('apply'));effectSources.set(name,file);}for(const name of expectedEffects)assert.ok(effectSources.has(name),`Missing effect: ${name}`);assert.strictEqual(effectSources.size,13);
for(const file of jsFiles('events')){const rel=`events/${file}`;const type=extractProperty(rel,'type');assert.ok(type);assert.ok(read(rel).includes('handle'));}for(const type of expectedEvents)assert.ok(jsFiles('events').some(file=>file.startsWith(type+'.')),`Missing event: ${type}`);
const sourceDirs=['core','commands','events','services','canvas','canvas/effects','games','database','utils','scripts','tests'];const importRegex=/require\((['"])(\.{1,2}\/[^'"]+)\1\)/g;for(const dir of sourceDirs){for(const file of jsFiles(dir)){const rel=`${dir}/${file}`;const src=read(rel);let m;while((m=importRegex.exec(src))!==null){const target=path.resolve(root,path.dirname(rel),m[2]);assert.ok([target,`${target}.js`,path.join(target,'index.js')].some(fs.existsSync),`Broken local require in ${rel}: ${m[2]}`);}}}
console.log(`Structure verified: ${requiredFiles.length} required files, ${commandSources.size} command modules, ${effectSources.size} Canvas effects.`);
