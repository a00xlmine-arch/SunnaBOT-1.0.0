const assert = require('assert');
const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

const root = path.resolve(__dirname, '..');

function jsFiles(dir) {
  const full = path.join(root, dir);
  return fs.readdirSync(full)
    .filter(file => file.endsWith('.js'))
    .map(file => path.join(full, file));
}

function verifySyntax() {
  const dirs = ['core', 'commands', 'events', 'services', 'canvas', 'canvas/effects', 'games', 'database', 'utils', 'scripts', 'tests'];
  const files = dirs.flatMap(jsFiles);
  for (const file of files) {
    childProcess.execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });
  }
  return files.length;
}

function verifySafeFiles() {
  const sensitive = [
    'config/appstate.json',
    'config/secrets.json',
    'config/admins.json',
    'config/groups.json'
  ];
  const current = {
    appstate: JSON.parse(fs.readFileSync(path.join(root, sensitive[0]), 'utf8')),
    secrets: JSON.parse(fs.readFileSync(path.join(root, sensitive[1]), 'utf8')),
    admins: JSON.parse(fs.readFileSync(path.join(root, sensitive[2]), 'utf8')),
    groups: JSON.parse(fs.readFileSync(path.join(root, sensitive[3]), 'utf8'))
  };

  assert.ok(Array.isArray(current.appstate), 'appstate.json must remain a JSON array.');
  assert.strictEqual(Array.isArray(current.admins.adminIds), true, 'admins.json must expose adminIds.');
  assert.strictEqual(Array.isArray(current.groups.allowedThreadIds), true, 'groups.json must expose allowedThreadIds.');
  assert.strictEqual(typeof current.secrets.puterAuthToken, 'string', 'secrets.json must expose puterAuthToken.');
}

const syntaxCount = verifySyntax();
verifySafeFiles();
require('./structure');
console.log(`Verification passed: ${syntaxCount} JavaScript files parsed and configuration shapes verified.`);
