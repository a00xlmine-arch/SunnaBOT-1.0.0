const assert = require('assert');
const Module = require('module');
const fs = require('fs');
const path = require('path');

const realLoad = Module._load;
const fsExtra = {
  ...fs,
  promises: fs.promises,
  ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
  remove: async target => fs.promises.rm(target, { recursive: true, force: true }),
  readJson: async file => JSON.parse(await fs.promises.readFile(file, 'utf8')),
  readJsonSync: file => JSON.parse(fs.readFileSync(file, 'utf8')),
  writeJson: async (file, value, options = {}) => fs.promises.writeFile(file, JSON.stringify(value, null, options.spaces || 2)),
  stat: async file => fs.promises.stat(file),
  outputFile: async (file, data) => { await fs.promises.mkdir(path.dirname(file), { recursive: true }); await fs.promises.writeFile(file, data); }
};
const mocks = {
  'fs-extra': fsExtra,
  axios: { get: async () => ({ data: Buffer.alloc(0), headers: { 'content-type': 'image/png' }, status: 200 }) },
  pino: Object.assign(() => ({ info(){}, warn(){}, error(){}, debug(){} }), { stdTimeFunctions: { isoTime: () => '' } }),
  '@hiudyy/ytdl': {
    searchPinterest: async () => [],
    downloadYouTube: async () => ({ success: false, error: 'mock' }),
    downloadToTemp: async () => ({ path: '', size: 0, contentType: 'image/png', cleanup: async () => {} })
  }
};
Module._load = function(request, parent, isMain) {
  if (Object.prototype.hasOwnProperty.call(mocks, request)) return mocks[request];
  return realLoad.call(this, request, parent, isMain);
};

(async () => {
  const root = path.resolve(__dirname, '..');
  const { loadCommands } = require('../core/commandLoader');
  const commands = loadCommands(root);
  assert.strictEqual(commands.size, 15);
  for (const name of ['help','info','ping','image','pin','song','canvas','love','rank','top','rps','guess','ttt','enable','disable']) assert.ok(commands.has(name));

  const { GameSessions } = require('../core/gameSessions');
  const sessions = new GameSessions();
  const session = sessions.create({ id: 'm1', type: 'guess', threadID: 't1', playerID: 'u1', expiresMs: 10000, data: {} });
  let handled = false;
  session.handle = async () => { handled = true; };
  assert.strictEqual(await sessions.handle({ threadID: 't1', senderID: 'u1', replyTarget: { messageID: 'm1' }, body: '25' }, {}), true);
  assert.strictEqual(handled, true);
  assert.strictEqual(await sessions.handle({ threadID: 't1', senderID: 'u2', replyTarget: { messageID: 'm1' }, body: '25' }, {}), false);
  sessions.stop();

  const CommandRouter = require('../core/commandRouter');
  let response = '';
  const routerBot = {
    config: { prefix: '.', cooldowns: { defaultMs: 0 } },
    groupAccess: { isAllowed: () => true },
    permissions: { isBotAdmin: () => true },
    cooldowns: { check: () => 0 },
    messenger: { sendMessage: async message => { response = String(message); return { messageID: 'x' }; } },
    logger: { error(){} }
  };
  const router = new CommandRouter(routerBot, new Map([['info', commands.get('info')]]));
  routerBot.commands = commands;
  await router.handle({ type: 'message', threadID: 't', senderID: 'u', messageID: 'm', body: '.INFO' });
  assert.ok(response.includes('Sunna Bot'));

  Module._load = realLoad;
  console.log('Runtime import and game-session smoke tests passed.');
})().catch(error => {
  Module._load = realLoad;
  console.error(error.stack || error);
  process.exit(1);
});
