const assert = require('assert');
const Module = require('module');
const fs = require('fs-extra');
const path = require('path');

const TEST_DIR = path.join(__dirname, 'tmp');
const TEST_FILE = path.join(TEST_DIR, 'sunna-test.mp3');
const REMOTE_FILE = path.join(TEST_DIR, 'remote.mp3');

async function withMocks(mocks, fn) {
  const original = Module._load;
  Module._load = function(request, parent, isMain) {
    if (Object.prototype.hasOwnProperty.call(mocks, request)) return mocks[request];
    return original.call(this, request, parent, isMain);
  };
  try {
    return await fn();
  } finally {
    Module._load = original;
  }
}

(async () => {
  await fs.ensureDir(TEST_DIR);
  await fs.writeFile(TEST_FILE, Buffer.from('test-audio'));
  await fs.writeFile(REMOTE_FILE, Buffer.from('remote-audio'));

  const localDownloader = {
    async downloadYouTube(url, format) {
      assert.strictEqual(url, 'https://www.youtube.com/watch?v=abc123');
      assert.strictEqual(format, 'mp3');
      return { success: true, filePath: TEST_FILE, size: 1000, title: 'Test' };
    }
  };

  await withMocks({ '@hiudyy/ytdl': localDownloader }, async () => {
    delete require.cache[require.resolve('../services/youtube')];
    const youtube = require('../services/youtube');
    const result = await youtube.downloadMp3(
      'https://www.youtube.com/watch?v=abc123',
      40 * 1024 * 1024,
      __dirname
    );
    assert.strictEqual(result.success, true);
    assert.strictEqual(result.filePath, TEST_FILE);
    assert.strictEqual(result.size, fs.statSync(TEST_FILE).size);
  });

  const remoteDownloader = {
    async downloadYouTube() {
      return {
        success: true,
        filePath: 'https://example.com/audio.mp3',
        title: 'Remote'
      };
    },
    async downloadToTemp(options) {
      assert.strictEqual(options.url, 'https://example.com/audio.mp3');
      assert.strictEqual(options.kind, 'audio');
      return {
        path: REMOTE_FILE,
        size: fs.statSync(REMOTE_FILE).size,
        contentType: 'audio/mpeg',
        cleanup: async () => {}
      };
    }
  };

  await withMocks({ '@hiudyy/ytdl': remoteDownloader }, async () => {
    delete require.cache[require.resolve('../services/youtube')];
    const youtube = require('../services/youtube');
    const result = await youtube.downloadMp3(
      'https://www.youtube.com/watch?v=abc123',
      40 * 1024 * 1024,
      __dirname
    );
    assert.strictEqual(result.success, true);
    assert.strictEqual(result.filePath, REMOTE_FILE);
  });

  await fs.remove(TEST_DIR);
  console.log('Service smoke tests passed.');
})().catch(error => {
  fs.remove(TEST_DIR).catch(() => {});
  console.error(error.stack || error);
  process.exit(1);
});
