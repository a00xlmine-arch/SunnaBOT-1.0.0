const assert = require('assert');
const path = require('path');
const fs = require('fs-extra');
const root = path.resolve(__dirname, '..');
(async()=>{
  const config=await fs.readJson(path.join(root,'config/config.json'));
  assert.strictEqual(config.developer,'Rin Il'); assert.strictEqual(config.prefix,'.');
  const {loadCommands}=require('../core/commandLoader'); const commands=loadCommands(root);
  const expected=['help','info','ping','image','pin','song','canvas','love','rank','top','rps','guess','ttt','enable','disable'];
  for(const name of expected) assert.ok(commands.has(name),`missing command ${name}`); assert.strictEqual(commands.size,15);
  const {menu}=require('../utils/messages'); assert.ok(menu('Sunna Bot',[{title:'🖼️ الصور',items:['.image','.love']}]).includes('.love'));
  const {registerDefaults,effects,getEffectNames}=require('../canvas/engine');registerDefaults();assert.deepStrictEqual([...getEffectNames()].sort(),['blur','cartoon','colors','cursed','fisheye','ghost','glitch','gray','heart','mirror','pixel','rotate','wave']);for(const n of getEffectNames())assert.ok(effects.has(n));
  const {normalizeEvent}=require('../core/dispatcher'); const evt=normalizeEvent({type:'message',threadID:'t',senderID:'u',messageID:'m',body:'.rank'});assert.strictEqual(evt.body,'.rank');
  const rep=normalizeEvent({type:'message_reply',threadID:'t',senderID:'u',messageID:'m2',body:'5',messageReply:{messageID:'game1',senderID:'bot',attachments:[]}});assert.strictEqual(rep.isReply,true);assert.strictEqual(rep.replyTarget.messageID,'game1');
  const {GameSessions}=require('../core/gameSessions');const gs=new GameSessions();const s=gs.create({id:'game1',type:'ttt',threadID:'t',playerID:'u',expiresMs:10000});s.handle=async()=>{};assert.ok(await gs.handle(rep,{}));gs.stop();
  const CommandRouter=require('../core/commandRouter');let routed=null;const bot={config:{prefix:'.',cooldowns:{defaultMs:0}},groupAccess:{isAllowed:()=>true},permissions:{isBotAdmin:()=>true},cooldowns:{check:()=>0},messenger:{sendMessage:async()=>{}},logger:{error:()=>{}}};const router=new CommandRouter(bot,new Map([['canvas',{name:'canvas',async execute(c){routed=c.commandName;}}]]));await router.handle({type:'message',threadID:'t',senderID:'u',messageID:'m',body:'.canvas gray'});assert.strictEqual(routed,'canvas');
  console.log('Sunna Bot smoke tests passed.');
})().catch(e=>{console.error(e.stack||e);process.exit(1);});
