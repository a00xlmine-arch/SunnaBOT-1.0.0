# Sunna Bot Architecture

```text
Messenger
  -> Messenger Adapter
  -> Dispatcher
  -> Events / Command Router
  -> Permissions / Cooldowns / Queue
  -> Commands
  -> Services / Canvas / Games / XP
  -> Messenger Adapter
```

The Core does not depend on individual external services. Commands call services; services call APIs or libraries.

## Group allowlist
`config/groups.json` is the source of truth. `.enable` and `.disable` are bootstrap admin commands and are the only commands allowed to operate while a group is not yet on the allowlist.

## User identity
UID is the stable internal identity. The current Messenger display name is resolved through `services/profile.js` and is displayed as plain text, never as an `@` mention.

## Canvas
`.canvas` is the single public Canvas command. Effect selectors use English names such as `.canvas gray` and are backed by files under `canvas/effects/`.

## Games
`.rps`, `.guess`, and `.ttt` start a game. Follow-up answers are accepted only as replies to the active game message from the active player. Sessions expire automatically and do not consume ordinary command syntax.

## Data safety
XP writes are serialized and atomic. Temporary media is removed after delivery. Session credentials and service secrets stay in ignored config files.
