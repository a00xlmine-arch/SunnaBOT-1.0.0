const assert = require('assert');
const path = require('path');
const fs = require('fs');
const Module = require('module');
const root = path.resolve(__dirname, '..');
const realLoad = Module._load;

const fsExtra = Object.assign({}, fs, {
  ensureDirSync: dir => fs.mkdirSync(dir, { recursive: true }),
  ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
  readJson: async file => JSON.parse(await fs.promises.readFile(file, 'utf8')),
  writeJson: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
  writeJsonAtomic: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
  remove: async file => fs.promises.rm(file, { recursive: true, force: true })
});

const mocks = {
  'fs-extra': fsExtra,
  axios: { get: async () => ({ data: Buffer.alloc(0), headers: {}, status: 200 }) },
  pino: Object.assign(() => ({ info() {}, warn() {}, error() {}, debug() {} }), { stdTimeFunctions: { isoTime: () => '' } }),
  '@hiudyy/ytdl': {
    searchPinterest: async () => [],
    downloadYouTube: async () => ({ success: false, error: 'mock' }),
    downloadToTemp: async () => ({ path: '', size: 0, contentType: 'image/png', cleanup: async () => {} })
  }
};

Module._load = function(request, parent, isMain) {
  return Object.prototype.hasOwnProperty.call(mocks, request) ? mocks[request] : realLoad.call(this, request, parent, isMain);
};

(async () => {
  try {
    const { normalizeEvent } = require('../core/dispatcher');
    const reply = normalizeEvent({ type: 'message_reply', threadID: 't', senderID: 'u', messageID: 'm2', body: '5', messageReply: { messageID: 'game1', senderID: 'bot' } });
    assert.strictEqual(reply.isReply, true);
    assert.strictEqual(reply.replyTarget.messageID, 'game1');

    const image = normalizeEvent({ type: 'event', logMessageType: 'log:thread-image', threadID: 't', messageID: 'img1' });
    assert.strictEqual(image.type, 'group_image_changed');

    const { loadCommands } = require('../core/commandLoader');
    const cmds = loadCommands(root);
    const canonical = new Set([...cmds.values()].map(c => c.name));
    assert.strictEqual(canonical.size, 17);
    assert.ok(cmds.has('حب'));
    assert.ok(cmds.has('اغنيه'));
    assert.ok(cmds.has('مواقيت'));
    assert.ok(cmds.has('ذكاء'));
    assert.ok(!cmds.has('canvas'));

    const { GameSessions } = require('../core/gameSessions');
    const gs = new GameSessions();
    const session = gs.create({ id: 'song1', type: 'song', threadID: 't', playerID: 'u', expiresMs: 10000 });
    let handled = false;
    session.handle = async () => { handled = true; };
    assert.strictEqual(await gs.handle({ threadID: 't', senderID: 'u', replyTarget: { messageID: 'song1' }, body: '3' }, {}), true);
    assert.strictEqual(handled, true);
    assert.strictEqual(await gs.handle({ threadID: 't', senderID: 'other', replyTarget: { messageID: 'song1' }, body: '3' }, {}), false);
    gs.stop();

    const Queue = require('../core/queue');
    const q = new Queue(1);
    let release;
    const gate = new Promise(resolve => { release = resolve; });
    const running = q.add(async () => gate);
    await new Promise(resolve => setImmediate(resolve));
    await assert.rejects(q.add(async () => true, { rejectIfBusy: true }), error => error.code === 'QUEUE_BUSY');
    release();
    await running;

    console.log('Runtime import, aliases, event normalization, reply sessions, and queue safety smoke tests passed.');
  } finally {
    Module._load = realLoad;
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
