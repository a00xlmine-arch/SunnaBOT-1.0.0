const assert = require('assert');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const Module = require('module');

const tempRoot = path.join(os.tmpdir(), `sunna-pin-smoke-${Date.now()}`);
const tempDir = path.join(tempRoot, 'tmp');
fs.mkdirSync(tempDir, { recursive: true });
const realLoad = Module._load;
const sent = [];

Module._load = function(request, parent, isMain) {
  if (request === 'fs-extra') {
    return {
      ...fs,
      existsSync: fs.existsSync,
      ensureDir: async dir => fsp.mkdir(dir, { recursive: true }),
      remove: async file => fsp.rm(file, { recursive: true, force: true }),
      stat: async file => fsp.stat(file),
      readFile: async file => fsp.readFile(file),
      writeFile: async (file, data) => fsp.writeFile(file, data),
      move: async (src, dest) => fsp.rename(src, dest),
      createReadStream: fs.createReadStream
    };
  }
  if (request === '../services/pinterest') {
    return {
      search: async () => [
        { url: 'https://i.pinimg.com/one.jpg', title: 'Mikasa Ackerman character portrait', relevance: 130 },
        { url: 'https://i.pinimg.com/two.jpg', title: 'random gradient wallpaper', relevance: 0 }
      ],
      imageQuality: async file => file.includes('one') ? 90 : -1
    };
  }
  if (request === '../utils/downloader') {
    return {
      downloadUrl: async url => {
        const name = url.includes('/one') ? 'one.jpg' : 'two.jpg';
        const file = path.join(tempDir, name);
        await fsp.writeFile(file, Buffer.from(name));
        return file;
      }
    };
  }
  if (request === '../services/imageMedia') {
    return {
      normalizeToPng: async (input, output) => {
        await fsp.copyFile(input, output);
        return output;
      }
    };
  }
  return realLoad.call(this, request, parent, isMain);
};

(async () => {
  try {
    delete require.cache[require.resolve('../commands/pin')];
    const command = require('../commands/pin');
    const ctx = {
      bot: {
        root: tempRoot,
        config: { limits: { maxDownloadedImageBytes: 1024 * 1024 } },
        logger: { warn() {} }
      },
      args: ['Mikasa', 'Ackerman'],
      threadID: 'g1',
      async reply(text) { sent.push({ type: 'reply', text }); },
      async sendImage(filePath, caption) {
        assert.ok(fs.existsSync(filePath));
        sent.push({ type: 'image', filePath, caption });
      }
    };

    await command.execute(ctx);
    assert.strictEqual(sent.length, 1);
    assert.strictEqual(sent[0].type, 'image');
    assert.ok(sent[0].caption.includes('Mikasa Ackerman'));
    assert.ok(!fs.existsSync(sent[0].filePath));
    assert.deepStrictEqual(fs.readdirSync(tempDir), []);

    console.log('Pinterest candidate ranking, validation, send, and cleanup smoke test passed.');
  } finally {
    Module._load = realLoad;
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
