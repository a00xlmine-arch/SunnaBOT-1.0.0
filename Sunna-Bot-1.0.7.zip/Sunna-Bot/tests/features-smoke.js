const assert = require('assert');
const path = require('path');
const fs = require('fs');
const Module = require('module');
const root = path.resolve(__dirname, '..');
const realLoad = Module._load;
const calls = [];
const tmpDir = path.join(root, 'tmp-feature-test');
fs.mkdirSync(tmpDir, { recursive: true });

const messenger = {
  async sendMessage(message, threadID) {
    calls.push({ type: 'message', body: String(message?.body || message), threadID: String(threadID), payload: message });
    return { messageID: `m${calls.length}` };
  },
  async deleteMessage(messageID) { calls.push({ type: 'delete', messageID: String(messageID) }); return true; },
  async reactToMessage(messageID, reaction) { calls.push({ type: 'reaction', messageID: String(messageID), reaction }); return true; },
  async getUserInfo(uid) { return { [String(uid)]: { name: `User ${uid}`, thumbSrc: `https://scontent.example/${uid}.jpg` } }; },
  async getAvatarUrl() { return null; },
  async getThreadInfo() { return { participantIDs: ['u', 'v', 'w'] }; }
};

const fsExtra = {
  ...fs,
  ensureDirSync: dir => fs.mkdirSync(dir, { recursive: true }),
  ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
  remove: async file => fs.promises.rm(file, { recursive: true, force: true }),
  stat: async file => fs.promises.stat(file),
  readFile: (...args) => fs.promises.readFile(...args),
  writeFile: (...args) => fs.promises.writeFile(...args),
  rename: (...args) => fs.promises.rename(...args),
  move: async (src, dest) => fs.promises.rename(src, dest),
  readJson: async file => JSON.parse(await fs.promises.readFile(file, 'utf8')),
  writeJson: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
  writeJsonAtomic: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2))
};

const downloader = {
  async downloadYouTube() {
    const file = path.join(tmpDir, 'song.mp3');
    fs.writeFileSync(file, Buffer.concat([Buffer.from('ID3'), Buffer.alloc(5000)]));
    return { success: true, filePath: file, size: 5003, title: 'Test' };
  },
  async searchPinterest() { return []; },
  async downloadToTemp() { return { path: '', size: 0, contentType: 'image/png', cleanup: async () => {} }; }
};

Module._load = function(request, parent, isMain) {
  if (request === 'fs-extra') return fsExtra;
  if (request === '@hiudyy/ytdl') return downloader;
  if (request === 'axios') return { get: async () => ({ data: Buffer.alloc(0), headers: {}, status: 200 }) };
  if (request === 'pino') return Object.assign(() => ({ info(){}, warn(){}, error(){}, debug(){} }), { stdTimeFunctions: { isoTime(){ return ''; } } });
  return realLoad.call(this, request, parent, isMain);
};

(async () => {
  try {
    const InteractionService = require('../services/interaction');
    const bot = { messenger, config: { prefix: '.' } };
    const interaction = new InteractionService(bot);
    await interaction.handle({ body: '.', threadID: 't', senderID: 'u', messageID: 'dot1' });
    assert.strictEqual(calls[0].body, 'لرؤية قائمة اوامر سونا ارسل help');
    await interaction.handle({ body: 'help', threadID: 't', senderID: 'u', replyTarget: { messageID: 'm1' } });
    assert.ok(calls[1].body.includes('⟡ سونا ⟡'));
    await interaction.handle({ body: 'مرحبا SUNNA', threadID: 't', senderID: 'u', messageID: 'sunna-message' });
    assert.strictEqual(calls[2].type, 'reaction');
    assert.strictEqual(calls[2].reaction, '✨️');
    await interaction.handle({ body: '.ping', threadID: 't', senderID: 'u', messageID: 'command-message' });
    assert.strictEqual(calls.length, 3);

    const { mainMenu } = require('../utils/messages');
    const menu = mainMenu();
    assert.ok(menu.includes('◇ قفل الصورة'));
    assert.ok(menu.includes('◇ مواقيت الصلاة'));
    assert.ok(!menu.includes('كانفس'));
    assert.ok(!menu.includes('image'));
    assert.strictEqual(require('../core/commandLoader').loadCommands(root).get('قفل').name, 'lockphoto');

    const { textRelevance } = require('../services/pinterest');
    assert.ok(textRelevance('Mikasa Ackerman', { title: 'Mikasa Ackerman character portrait' }) > textRelevance('Mikasa Ackerman', { title: 'random gradient wallpaper' }));

    const ProfileService = require('../services/profile');
    const profile = await new ProfileService(messenger).getUser('u');
    assert.strictEqual(profile.avatarUrl, 'https://scontent.example/u.jpg');

    delete require.cache[require.resolve('../services/youtube')];
    const youtube = require('../services/youtube');
    const audio = await youtube.downloadMp3('https://www.youtube.com/watch?v=test', 20 * 1024 * 1024, tmpDir);
    assert.strictEqual(audio.ext, 'mp3');
    assert.strictEqual(audio.mimeType, 'audio/mpeg');
    assert.ok(audio.filePath.endsWith('.mp3'));
    await audio.cleanup();

    console.log('Feature smoke tests passed.');
  } finally {
    Module._load = realLoad;
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
