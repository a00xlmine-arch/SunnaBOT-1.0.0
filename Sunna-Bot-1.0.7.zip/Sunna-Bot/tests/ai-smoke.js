const assert = require('assert');
const path = require('path');
const fs = require('fs');
const Module = require('module');

const root = path.resolve(__dirname, '..');
const tempData = path.join(root, 'tmp-ai-test');
fs.rmSync(tempData, { recursive: true, force: true });
fs.mkdirSync(path.join(tempData, 'config'), { recursive: true });
const realLoad = Module._load;
const calls = [];
let geminiFail = false;

const fakeGoogle = {
  GoogleGenAI: class {
    constructor(options) { assert.strictEqual(options.apiKey, 'gemini-key'); }
    interactions = {
      create: async options => {
        assert.strictEqual(options.model, 'gemini-test');
        assert.ok(options.system_instruction.includes('اسمك سونا'));
        assert.strictEqual(typeof options.input, 'string');
        assert.ok(options.input.includes('مرحبا سونا'));
        assert.ok(options.generation_config.max_output_tokens <= 180);
        calls.push({ provider: 'gemini', input: options.input, options });
        if (geminiFail) throw new Error('Gemini unavailable');
        return { output_text: 'رد Gemini طبيعي.' };
      }
    };
  }
};

class FakeGroq {
  constructor(options) { assert.strictEqual(options.apiKey, 'groq-key'); }
  chat = { completions: { create: async options => {
    calls.push({ provider: 'groq', model: options.model, messages: options.messages });
    return { choices: [{ message: { content: 'رد Groq طبيعي.' } }], model: options.model };
  } } };
}

Module._load = function(request, parent, isMain) {
  if (request === 'fs-extra') {
    return {
      readFile: (...args) => fs.promises.readFile(...args),
      writeFile: (...args) => fs.promises.writeFile(...args),
      ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
      remove: async file => fs.promises.rm(file, { recursive: true, force: true }),
      readJson: async file => JSON.parse(await fs.promises.readFile(file, 'utf8')),
      writeJson: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
      rename: async (src, dest) => fs.promises.rename(src, dest)
    };
  }
  if (request === '@google/genai') return fakeGoogle;
  if (request === 'groq-sdk') return FakeGroq;
  return realLoad.call(this, request, parent, isMain);
};

(async () => {
  try {
    const AIService = require('../services/ai');
    const service = new AIService({
      root: tempData,
      botUserId: 'bot1',
      config: {
        prefix: '.',
        message: { maxLength: 1800 },
        ai: {
          enabled: true,
          provider: 'gemini',
          chatGroupIds: ['g1'],
          geminiModel: 'gemini-test',
          groqModel: 'groq-test',
          maxHistory: 12,
          maxOutputTokens: 100,
          maxReplyLength: 360,
          requestTimeoutMs: 5000,
          cooldownMs: 0
        }
      },
      credentials: { geminiApiKey: 'gemini-key', groqApiKey: 'groq-key' },
      profile: { getUser: async uid => ({ name: `User ${uid}` }) },
      messenger: { sendMessage: async (text, threadID) => { calls.push({ provider: 'messenger', text, threadID }); return { messageID: `m${calls.length}` }; } },
      logger: { warn() {} }
    });

    await service.load();
    assert.strictEqual(service.isRoom('g1'), true);

    // Normal message in AI room must NOT trigger the model.
    const ignored = await service.handle({ threadID: 'g1', senderID: 'u0', body: 'رسالة عادية' });
    assert.strictEqual(ignored, false);
    assert.strictEqual(calls.length, 0);

    // Only a direct reply to the bot triggers the model.
    const handled = await service.handle({
      threadID: 'g1', senderID: 'u1', body: 'مرحبا سونا',
      replyTarget: { messageID: 'old', senderID: 'bot1' }
    });
    assert.strictEqual(handled, true);
    assert.ok(calls.some(call => call.provider === 'gemini'));
    assert.ok(calls.some(call => call.provider === 'messenger' && call.text === 'رد Gemini طبيعي.'));

    // Reply to another member must be ignored.
    const countBeforeOtherReply = calls.length;
    const ignoredOtherReply = await service.handle({
      threadID: 'g1', senderID: 'u2', body: 'انا اقصدك',
      replyTarget: { messageID: 'someone', senderID: 'u9' }
    });
    assert.strictEqual(ignoredOtherReply, false);
    assert.strictEqual(calls.length, countBeforeOtherReply);

    // Admin room persistence.
    service.bot.config.ai.chatGroupIds = [];
    const added = await service.setRoom('g2', true);
    assert.strictEqual(added, true);
    const persisted = JSON.parse(fs.readFileSync(path.join(tempData, 'config/config.json'), 'utf8'));
    assert.ok(persisted.ai.chatGroupIds.includes('g2'));
    const removed = await service.setRoom('g2', false);
    assert.strictEqual(removed, true);

    service.bot.config.ai.chatGroupIds = ['g1'];
    service.bot.config.ai.provider = 'groq';
    service.bot.credentials.geminiApiKey = '';
    await service.handle({ threadID: 'g1', senderID: 'u2', body: 'اهلا', replyTarget: { senderID: 'bot1' } });
    assert.ok(calls.some(call => call.provider === 'messenger' && call.text === 'رد Groq طبيعي.'));

    geminiFail = true;
    service.bot.config.ai.provider = 'auto';
    service.bot.credentials.geminiApiKey = 'gemini-key';
    await service.handle({ threadID: 'g1', senderID: 'u3', body: 'هل انت هنا؟', replyTarget: { senderID: 'bot1' } });
    assert.ok(calls.some(call => call.provider === 'gemini'));
    assert.ok(calls.some(call => call.provider === 'groq'));
    assert.ok(calls.some(call => call.provider === 'messenger' && call.text === 'رد Groq طبيعي.'));

    console.log('AI trigger gating, shared personality, persistence, Gemini path, Groq path, and fallback smoke tests passed.');
  } finally {
    Module._load = realLoad;
    fs.rmSync(tempData, { recursive: true, force: true });
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
