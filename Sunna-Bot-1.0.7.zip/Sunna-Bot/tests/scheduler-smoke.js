const assert = require('assert');
const Module = require('module');
const realLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === 'axios') return { get: async () => ({ data: { data: { timings: {} } }, status: 200 }) };
  if (request === 'fs-extra') {
    const fs = require('fs');
    return {
      readJson: async (file, fallback) => { try { return JSON.parse(await fs.promises.readFile(file, 'utf8')); } catch (error) { if (error.code === 'ENOENT') return fallback; throw error; } },
      ensureDir: async dir => fs.promises.mkdir(dir, { recursive: true }),
      writeJson: async (file, value) => fs.promises.writeFile(file, JSON.stringify(value, null, 2)),
      rename: async (src, dest) => fs.promises.rename(src, dest)
    };
  }
  return realLoad.call(this, request, parent, isMain);
};
const Scheduler = require('../services/scheduler');

(async () => {
  const sent = [];
  const bot = {
    root: process.cwd(),
    config: { timezone: 'Asia/Riyadh', schedules: { morning: '08:00', night: '23:00', hourly: true, hourlyMinute: '30', prayerReminders: false } },
    groupAccess: { data: { allowedThreadIds: ['g1'] } },
    messenger: { sendMessage: async (message, threadID) => { sent.push({ message, threadID }); } },
    logger: { warn() {}, error() {} }
  };
  const scheduler = new Scheduler(bot);
  scheduler.state = {};
  const original = global.Date;
  try {
    scheduler.pickHourlyMessage('g1');
    assert.strictEqual(typeof scheduler.pickHourlyMessage('g1'), 'string');
    await scheduler.simpleSchedule('2030-01-01', '08:00', 'morning', 'صباح الخير');
    assert.strictEqual(sent.length, 1);
    sent.length = 0;
    await scheduler.hourlySchedule('2030-01-01', '10:30');
    assert.strictEqual(sent.length, 1);
    await scheduler.hourlySchedule('2030-01-01', '10:30');
    assert.strictEqual(sent.length, 1);
  } finally {
    global.Date = original;
  }
  console.log('Scheduler hourly message smoke test passed.');
  Module._load = realLoad;
})().catch(error => { Module._load = realLoad; console.error(error.stack || error); process.exit(1); });
