const os = require('os');
const { box } = require('../utils/messages');
module.exports = {
  name: 'info',
  aliases: ['معلومات', 'معلومه', 'معلومة'],
  description: 'عرض معلومات البوت',
  cooldownMs: 1000,
  async execute(ctx) {
    const total = Math.floor(process.uptime());
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const uptime = [days ? `${days}ي` : '', hours ? `${hours}س` : '', minutes ? `${minutes}د` : '', `${total % 60}ث`].filter(Boolean).join(' ');
    await ctx.reply(box('معلومات Sunna Bot', [
      `الاصدار: ${ctx.bot.config.version}`,
      `المطور: ${ctx.bot.config.developer}`,
      `النظام: Messenger Bot`,
      `Node.js: ${process.versions.node}`,
      `وقت التشغيل: ${uptime}`,
      `الاوامر: ${ctx.bot.canonicalCommandCount || 16}`,
      'الحالة: يعمل',
      `الجهاز: ${os.platform()} ${os.arch()}`
    ]));
  }
};
