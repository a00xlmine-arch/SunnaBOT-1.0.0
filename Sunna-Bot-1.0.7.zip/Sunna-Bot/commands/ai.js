function normalizeAction(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (['on', 'تشغيل', 'تفعيل'].includes(raw)) return 'on';
  if (['off', 'ايقاف', 'إيقاف', 'تعطيل'].includes(raw)) return 'off';
  if (['status', 'حالة'].includes(raw)) return 'status';
  return null;
}

module.exports = {
  name: 'ai',
  aliases: ['ذكاء', 'الذكاء'],
  description: 'تشغيل او ايقاف دردشة سونا',
  adminOnly: true,
  cooldownMs: 1000,
  async execute(ctx) {
    const action = normalizeAction(ctx.args[0]);
    const ai = ctx.bot.ai;

    if (!action) {
      await ctx.reply('الاستخدام: .ai on | .ai off | .ai status');
      return;
    }

    if (action === 'status') {
      await ctx.reply(ai.isRoom(ctx.threadID)
        ? 'دردشة سونا مفعلة في هذه المجموعة.'
        : 'دردشة سونا متوقفة في هذه المجموعة.');
      return;
    }

    const enabled = action === 'on';
    const changed = await ai.setRoom(ctx.threadID, enabled);
    await ctx.reply(changed
      ? (enabled ? 'تم تشغيل دردشة سونا في هذه المجموعة.' : 'تم ايقاف دردشة سونا في هذه المجموعة.')
      : (enabled ? 'دردشة سونا مفعلة بالفعل.' : 'دردشة سونا متوقفة بالفعل.'));
  }
};
