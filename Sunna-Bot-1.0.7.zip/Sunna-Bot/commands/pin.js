const path = require('path');
const fs = require('fs-extra');
const { search, imageQuality } = require('../services/pinterest');
const { downloadUrl } = require('../utils/downloader');
const { normalizeToPng } = require('../services/imageMedia');

module.exports = {
  name: 'pin',
  aliases: ['بنترست', 'بن'],
  description: 'البحث عن صورة في Pinterest',
  cooldownMs: 6000,
  async execute(ctx) {
    const query = ctx.args.join(' ').trim();
    if (!query) {
      await ctx.reply('اكتب اسم الشخصية او الصورة التي تريد البحث عنها بعد الامر.');
      return;
    }

    const candidates = await search(query, 12);
    if (!candidates.length) {
      await ctx.reply('لم يتم العثور على صورة مرتبطة بالبحث بشكل موثوق.');
      return;
    }

    const prepared = [];
    for (const candidate of candidates) {
      let inputPath = null;
      let outputPath = null;
      try {
        inputPath = await downloadUrl(candidate.url, {
          kind: 'image',
          prefix: 'pin-download',
          tempDir: path.join(ctx.bot.root, 'tmp'),
          maxBytes: Number(ctx.bot.config.limits?.maxDownloadedImageBytes || 20 * 1024 * 1024),
          timeoutMs: 30_000,
          headers: {
            Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
            Referer: 'https://www.pinterest.com/'
          }
        });

        const quality = await imageQuality(inputPath);
        const relevance = Number(candidate.relevance || 0);
        if (quality < 0 || relevance <= 0) continue;

        outputPath = path.join(
          ctx.bot.root,
          'tmp',
          `pin-${Date.now()}-${Math.random().toString(16).slice(2)}.png`
        );
        await normalizeToPng(inputPath, outputPath);

        const capturedInput = inputPath;
        const capturedOutput = outputPath;
        prepared.push({
          path: capturedOutput,
          score: (relevance * 5) + quality,
          cleanup: async () => {
            await fs.remove(capturedInput).catch(() => {});
            await fs.remove(capturedOutput).catch(() => {});
          }
        });

        inputPath = null;
        outputPath = null;
      } catch (error) {
        ctx.bot.logger.warn({ err: error, url: candidate.url }, 'Pinterest candidate failed');
      } finally {
        if (inputPath) await fs.remove(inputPath).catch(() => {});
        if (outputPath) await fs.remove(outputPath).catch(() => {});
      }
    }

    if (!prepared.length) {
      throw new Error('تعذر تجهيز صورة Pinterest مرتبطة بالبحث.');
    }

    prepared.sort((a, b) => b.score - a.score);
    const best = prepared[0];

    try {
      await ctx.sendImage(best.path, `بنترست\nالبحث: ${query}`);
    } finally {
      await Promise.all(prepared.map(item => item.cleanup()));
    }
  }
};
