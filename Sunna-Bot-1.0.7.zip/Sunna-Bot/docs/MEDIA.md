# Media pipeline

## Pinterest
بحث متعدد الصيغ -> ترتيب metadata -> تنزيل الصورة -> فحص الجودة -> PNG -> Messenger.

## Song
بحث 5 نتائج -> اختيار بالرد -> طابور صوت ذو عملية فعالة واحدة -> تنزيل -> فحص MP3 -> FFmpeg عند الحاجة -> Messenger -> تنظيف الملف.
