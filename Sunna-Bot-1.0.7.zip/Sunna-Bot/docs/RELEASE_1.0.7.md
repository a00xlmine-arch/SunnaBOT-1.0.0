# Release 1.0.7

## AI chat
- Sunna replies only when a member replies directly to a message sent by the bot.
- Normal group messages do not trigger AI.
- `.ai on`, `.ai off`, and `.ai status` are restricted to Bot Admins and persist the current room ID in `config/config.json`.
- Gemini and Groq share the same Sunna personality.
- Gemini is tried first in `auto` mode, then Groq on failure.
- AI output is constrained to short conversational replies with a local response timeout.

## Scheduled character messages
- One non-AI character message is sent each hour at minute 30 to enabled groups.
- Messages are selected randomly from a built-in pool and the previous message is avoided when possible.
- Morning and night messages remain fixed at 08:00 and 23:00 Makkah time.

## Validation
- Canvas remains fully removed.
- Command aliases and reply-based sessions are tested.
- Queue safety, Pinterest, MP3 normalization, AI fallback, and scheduler behavior have dedicated smoke tests.
