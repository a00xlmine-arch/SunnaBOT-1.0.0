# Architecture 1.0.6

`index.js`
-> configuration
-> Messenger adapter
-> command loader/router
-> dispatcher
-> services
-> games / XP / scheduler

الخدمات الاساسية:

- `services/youtube.js`: بحث وتنزيل وتطبيع الصوت.
- `services/pinterest.js`: بحث وترتيب والتحقق من الصور.
- `services/love.js`: صور الحسابين وبطاقة الحب.
- `services/ai.js`: Gemini/Groq وذاكرة المحادثة.
- `services/scheduler.js`: رسائل الوقت والصلاة.
- `services/groupPhotoLock.js`: حفظ واسترجاع صورة المجموعة.

لا توجد طبقة Canvas في هذه النسخة.
