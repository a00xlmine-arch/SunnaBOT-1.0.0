# Termux

```bash
pkg update
pkg install nodejs ffmpeg -y
cd ~/SunnaBOT-1.0.0/Sunna-Bot
npm install
npm run migrate:local
npm test
npm run verify
npm run doctor
npm start
```

لا تضع ملفات AppState او مفاتيح API في GitHub العام.
