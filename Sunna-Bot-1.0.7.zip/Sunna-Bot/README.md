# Sunna Bot 1.0.6

Sunna Bot هو بوت Facebook Messenger منظم ومخصص للمجموعات.

## الوظائف

- اوامر انجليزية باسماء عربية بديلة، ويعمل الاسمان معا.
- قائمة اوامر عربية بتصميم RTL مختصر.
- Pinterest مع بحث متعدد الصيغ وترتيب حسب صلة الشخصية والتحقق من جودة الصورة.
- `song` يعرض خمس نتائج ثم يختار العضو بالرد، ولا يسمح بتراكم طلبات التحميل.
- توحيد الصوت الى MP3 حقيقي مع دعم FFmpeg عند الحاجة.
- `love` يستخدم صورتَي الحسابين في بطاقة واحدة ونص RTL/LTR مستقر.
- العاب `rps` و`guess` و`ttt` تعمل بالرد على رسالة اللعبة.
- `prayer` يعرض مواقيت مكة المكرمة ويستخدم توقيت مكة للتذكيرات.
- رسالة صباح 08:00 ورسالة ليلية 23:00 بتوقيت مكة.
- تفاعل `✨️` مع كلمات bot ونسخها العربية واسم Sunna والنقطة في الرسائل العادية.
- `lockphoto on/off` لحماية صورة المجموعة لمدراء البوت.
- غرفة AI اختيارية تستخدم Gemini وGroq بنفس شخصية Sunna، مع fallback تلقائي بينهما.

## الاعداد

الملفات المحلية الحقيقية تبقى داخل `config/` ولا ترفع الى GitHub:

- `appstate.json`
- `admins.json`
- `groups.json`
- `secrets.json`

يمكن نقلها تلقائيا من النسخة القديمة في Termux:

```bash
npm run migrate:local
```

وعند تحديث نسخة قديمة تحتوي Canvas:

```bash
npm run cleanup:legacy
```

ثم ضع مفاتيح Gemini وGroq في `config/secrets.json`:

```json
{
  "puterAuthToken": "",
  "geminiApiKey": "",
  "groqApiKey": ""
}
```

حدد غرف الذكاء في `config/config.json` داخل `ai.chatGroupIds`.

الاعدادات تدعم ايضا `facebook.adminIds` و`facebook.groupIds` داخل `config/config.json`، وإذا كانت غير فارغة تكون هي المصدر المستخدم بدلا من ملفات IDs.

## التشغيل

Node.js 24+ مطلوب. FFmpeg مطلوب فقط عندما يحتاج مصدر YouTube الى تحويل فعلي.

```bash
npm install
npm test
npm run verify
npm run verify:ai
npm run cleanup:legacy
npm run doctor
npm start
```

## الامان

لا ترفع `appstate.json` أو `secrets.json` أو `admins.json` أو `groups.json` الى مستودع عام. مفاتيح Gemini وGroq وPuter تعامل كاسرار.

## المطور

Rin Il

### AI chat
Use `.ai on`, `.ai off`, or `.ai status` as a Bot Admin in a permitted group. Sunna replies only when a member replies directly to a message sent by the bot. Gemini and Groq share the same personality and Groq can be used as fallback.
