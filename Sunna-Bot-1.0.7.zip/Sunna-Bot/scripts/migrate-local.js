const os = require('os');
const path = require('path');
const fs = require('fs-extra');

async function copyIfMissing(sourceDir, targetDir, name) {
  const source = path.join(sourceDir, name);
  const target = path.join(targetDir, name);
  if (!fs.existsSync(source)) return false;
  if (fs.existsSync(target)) return false;
  await fs.copy(source, target);
  return true;
}

async function main() {
  const root = path.resolve(__dirname, '..');
  const targetDir = path.join(root, 'config');
  const previous = path.join(os.homedir(), 'SunnaBOT', 'Sunna-Bot', 'config');
  const names = ['appstate.json', 'admins.json', 'groups.json', 'secrets.json'];
  const previousData = path.join(previous, '..', 'data');

  if (!fs.existsSync(previous)) {
    throw new Error(`لم يتم العثور على نسخة Sunna القديمة في: ${previous}`);
  }

  let copied = 0;
  for (const name of names) {
    if (await copyIfMissing(previous, targetDir, name)) copied += 1;
  }

  const targetUsers = path.join(root, 'data', 'users.json');
  const sourceUsers = path.join(previousData, 'users.json');
  if (fs.existsSync(sourceUsers) && !fs.existsSync(targetUsers)) {
    await fs.ensureDir(path.dirname(targetUsers));
    await fs.copy(sourceUsers, targetUsers);
    copied += 1;
  }

  console.log(copied ? `تم نقل ${copied} ملفات تشغيل/بيانات محلية.` : 'الملفات موجودة بالفعل، لم يتم استبدال اي ملف.');
  console.log('يمكنك بعدها تشغيل: npm run doctor ثم npm start');
}

main().catch(error => {
  console.error(error.message || error);
  process.exit(1);
});
