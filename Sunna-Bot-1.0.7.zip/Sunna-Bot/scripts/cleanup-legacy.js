const fs = require('fs/promises');
const path = require('path');

async function main() {
  const root = path.resolve(__dirname, '..');
  const targets = [
    path.join(root, 'canvas'),
    path.join(root, 'commands', 'canvas.js')
  ];
  let removed = 0;

  for (const target of targets) {
    try { await fs.access(target); } catch (_) { continue; }
    await fs.rm(target, { recursive: true, force: true });
    removed += 1;
  }

  console.log(removed ? `تم تنظيف ${removed} مكونات قديمة.` : 'لا توجد مكونات قديمة تحتاج إلى تنظيف.');
}

main().catch(error => {
  console.error(error.message || error);
  process.exit(1);
});
