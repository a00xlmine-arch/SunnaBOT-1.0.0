const assert = require('assert');

function resolveConstructor(mod, label) {
  const ctor = mod?.[label] || mod?.default?.[label] || mod?.default || mod;
  assert.strictEqual(typeof ctor, 'function', `${label} SDK export is not a constructor.`);
  return ctor;
}

const google = require('@google/genai');
resolveConstructor(google, 'GoogleGenAI');

const groq = require('groq-sdk');
resolveConstructor(groq, 'Groq');

console.log('Gemini and Groq SDK imports verified.');
