const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');

const required = [
  'index.js', 'package.json', '.gitignore', 'config/config.json', 'data/users.json',
  'tests/profile-smoke.js', 'tests/pin-smoke.js', 'tests/ai-smoke.js', 'tests/scheduler-smoke.js', 'core/messenger.js', 'core/dispatcher.js',
  'core/commandRouter.js', 'core/commandLoader.js', 'core/eventLoader.js', 'core/permissions.js',
  'core/groupAccess.js', 'core/cooldowns.js', 'core/queue.js', 'core/deduplication.js', 'core/gameSessions.js',
  'services/profile.js', 'services/love.js', 'services/imageAI.js', 'services/imageMedia.js',
  'services/pinterest.js', 'services/youtube.js', 'services/prayer.js', 'services/groupPhotoLock.js',
  'services/scheduler.js', 'services/interaction.js', 'services/ai.js', 'services/sunnaPersonality.js',
  'games/guess.js', 'games/xo.js', 'database/xp.js', 'utils/messages.js', 'utils/files.js', 'utils/downloader.js',
  'utils/logger.js', 'docs/RELEASE_1.0.7.md', 'events/group-image.js', 'scripts/migrate-local.js', 'scripts/verify-ai.js', 'scripts/cleanup-legacy.js'
];

function read(rel) { return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel) { return JSON.parse(read(rel)); }
function jsFiles(dir) { return fs.readdirSync(path.join(root, dir)).filter(file => file.endsWith('.js')).sort(); }
function propertySource(rel, prop) {
  const source = read(rel);
  const match = source.match(new RegExp(`\\b${prop}\\s*:\\s*['\"]([^'\"]+)['\"]`));
  return match?.[1] || null;
}

for (const file of required) {
  const full = path.join(root, file);
  assert.ok(fs.existsSync(full), `Missing required file: ${file}`);
  assert.ok(fs.statSync(full).isFile() && fs.statSync(full).size > 0, `Empty required file: ${file}`);
}

for (const dir of ['core', 'commands', 'events', 'services', 'games', 'database', 'utils', 'scripts', 'tests', 'docs', 'config', 'data']) {
  const full = path.join(root, dir);
  assert.ok(fs.existsSync(full), `Missing directory: ${dir}`);
  assert.ok(fs.readdirSync(full).length > 0, `Empty directory: ${dir}`);
}
assert.ok(!fs.existsSync(path.join(root, 'canvas')), 'Canvas directory must be removed.');

const pkg = json('package.json');
assert.strictEqual(pkg.name, 'sunna-bot');
assert.strictEqual(pkg.type, 'commonjs');
assert.ok(pkg.engines?.node?.startsWith('>=24'), 'Node engine must be >=24.');
for (const dep of ['@lazyneoaz/metachat', '@heyputer/puter.js', '@hiudyy/ytdl', '@google/genai', 'groq-sdk', 'axios', 'dotenv', 'fs-extra', 'jimp', '@jimp/wasm-webp', 'pino', 'youtubei.js']) {
  assert.ok(pkg.dependencies?.[dep], `Missing dependency: ${dep}`);
}

const cfg = json('config/config.json');
assert.strictEqual(cfg.developer, 'Rin Il');
assert.strictEqual(cfg.prefix, '.');
assert.strictEqual(cfg.version, '1.0.7');
assert.strictEqual(cfg.timezone, 'Asia/Riyadh');
assert.strictEqual(cfg.schedules?.morning, '08:00');
assert.strictEqual(cfg.schedules?.night, '23:00');
assert.strictEqual(cfg.schedules?.hourly, true);
assert.strictEqual(cfg.schedules?.hourlyMinute, '30');
assert.strictEqual(cfg.prayer?.city, 'Makkah');
assert.strictEqual(cfg.prayer?.country, 'Saudi Arabia');
assert.ok(Array.isArray(cfg.ai?.chatGroupIds));
assert.strictEqual(cfg.ai?.provider, 'auto');
assert.ok(cfg.ai?.geminiModel && cfg.ai?.groqModel);
assert.ok(cfg.ai?.maxReplyLength > 0);
assert.ok(cfg.ai?.requestTimeoutMs > 0);
assert.deepStrictEqual(cfg.queues, { image: 1, music: 1, default: 2 });

for (const [real, example] of [
  ['config/appstate.json', 'config/appstate.example.json'],
  ['config/admins.json', 'config/admins.example.json'],
  ['config/groups.json', 'config/groups.example.json'],
  ['config/secrets.json', 'config/secrets.example.json']
]) {
  const chosen = fs.existsSync(path.join(root, real)) ? real : example;
  const value = json(chosen);
  if (real.includes('appstate')) assert.ok(Array.isArray(value));
  if (real.includes('admins')) assert.ok(Array.isArray(value.adminIds));
  if (real.includes('groups')) {
    assert.strictEqual(value.mode, 'allowlist');
    assert.ok(Array.isArray(value.allowedThreadIds));
  }
  if (real.includes('secrets')) {
    assert.ok(typeof value.puterAuthToken === 'string');
    assert.ok(typeof value.geminiApiKey === 'string');
    assert.ok(typeof value.groqApiKey === 'string');
  }
}

const names = new Map();
for (const file of jsFiles('commands')) {
  const rel = `commands/${file}`;
  const source = read(rel);
  const name = propertySource(rel, 'name');
  assert.ok(name, `Command has no name: ${file}`);
  assert.ok(/^[a-z][a-z0-9_-]*$/i.test(name), `Canonical command must be English: ${name}`);
  assert.ok(!names.has(name), `Duplicate canonical command: ${name}`);
  names.set(name, file);
  const aliasMatch = source.match(/aliases\s*:\s*\[([^\]]*)\]/s);
  assert.ok(aliasMatch, `Command has no aliases array: ${file}`);
  assert.ok([...aliasMatch[1]].some(ch => /[\u0600-\u06FF]/u.test(ch)), `Command must expose an Arabic alias: ${file}`);
}

const expected = ['help', 'info', 'ping', 'image', 'pin', 'song', 'love', 'rank', 'top', 'rps', 'guess', 'ttt', 'prayer', 'ai', 'enable', 'disable', 'lockphoto'];
for (const name of expected) assert.ok(names.has(name), `Missing command: ${name}`);
assert.strictEqual(names.size, 17);

const eventTypes = new Set();
for (const file of jsFiles('events')) {
  const rel = `events/${file}`;
  const type = propertySource(rel, 'type');
  assert.ok(type, `Event has no type: ${file}`);
  assert.ok(/handle\s*\(/.test(read(rel)), `Event has no handle(): ${file}`);
  eventTypes.add(type);
}
for (const type of ['startup', 'join', 'leave', 'group_image_changed']) assert.ok(eventTypes.has(type), `Missing event: ${type}`);

const dirs = ['core', 'commands', 'events', 'services', 'games', 'database', 'utils', 'scripts', 'tests'];
const reqRe = /require\((['"])(\.{1,2}\/[^'"]+)\1\)/g;
for (const dir of dirs) {
  for (const file of jsFiles(dir)) {
    const rel = `${dir}/${file}`;
    const src = read(rel);
    let match;
    reqRe.lastIndex = 0;
    while ((match = reqRe.exec(src))) {
      const target = path.resolve(root, path.dirname(rel), match[2]);
      assert.ok([target, `${target}.js`, path.join(target, 'index.js')].some(fs.existsSync), `Broken local require in ${rel}: ${match[2]}`);
    }
  }
}


console.log(`Structure verified: ${required.length} required files, ${names.size} command modules, ${eventTypes.size} events, Canvas removed.`);
