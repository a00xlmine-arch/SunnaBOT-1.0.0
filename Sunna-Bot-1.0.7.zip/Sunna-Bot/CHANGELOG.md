# Changelog

## 1.0.6
- حذف Canvas بالكامل من المشروع والاوامر والاختبارات والاعدادات.
- اصلاح طابور song: لا تتراكم طلبات التحميل، وكل عملية تحميل لها مهلة وفشل واضح، ولا يتم تفريغ طلبات قديمة دفعة واحدة.
- تحسين تنزيل الصوت والتحقق من MP3 وتحويل المصادر غير MP3 عبر FFmpeg.
- تحسين Pinterest: صيغ بحث متعددة، ترتيب حسب metadata، استبعاد الضوضاء البصرية والتدرجات وخلفيات الهواتف، تنزيل مباشر للصورة مع تحقق النوع، وتنظيف ملفات مؤقتة مضمون.
- الحفاظ على نظام song بخمس نتائج والاختيار بالرد وحذف القائمة بعد النجاح.
- اضافة Gemini وGroq رسميا باستخدام SDKs الحالية مع شخصية Sunna مشتركة وfallback تلقائي.
- اضافة تحديد غرف AI من `ai.chatGroupIds` وذاكرة محادثة محلية محدودة.
- اضافة اماكن اختيارية لـadmin IDs وgroup IDs في `config/config.json` مع المحافظة على الملفات الحالية.
- اضافة `npm run migrate:local` لنقل ملفات التشغيل من النسخة القديمة بدون استبدالها، مع نقل XP القديم اختياريا اذا كان موجودا.
- اضافة فحص استيراد فعلي لـ Gemini وGroq بعد `npm install`، وتحديث doctor وverify وstructure واختبارات runtime/AI بعد حذف Canvas.

## 1.0.5
- تحسين صور الحسابات وPinterest والصوت وLove وتفاعل Messenger.

## 1.0.4
- اضافة aliases عربية، menu عربية، prayer، scheduler، auto reaction، lockphoto، ونظام song بخمس نتائج.

## Release 1.0.7

- AI replies only to direct replies to Sunna messages inside enabled rooms.
- Added bot-admin-only `ai` / `ذكاء` room toggle with persistent config.
- Gemini and Groq share one Sunna personality and short-reply formatter.
- Added hourly non-AI character messages at minute 30, plus existing morning/night messages.
- Tightened AI timeouts and removed AI backlog behavior.
- Added command/feature verification for the new AI control path.

## Release 1.0.7

- AI now responds only to direct replies to Sunna messages inside enabled rooms.
- Added Bot Admin-only `.ai on|off|status` with persistent room configuration.
- Gemini and Groq use one shared Sunna personality; replies are intentionally short and conversational.
- Added a timeout around AI requests and no-backlog behavior for AI rooms.
- Added one non-AI character message each hour at minute 30, plus the fixed morning/night greetings.
- Added tests for AI trigger gating, room persistence, and hourly scheduling.
