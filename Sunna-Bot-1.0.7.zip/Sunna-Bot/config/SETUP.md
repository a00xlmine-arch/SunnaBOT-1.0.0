# Sunna Bot 1.0.6 setup

ملفات التشغيل المحلية:

- `config/appstate.json` جلسة Messenger.
- `config/admins.json` معرفات مدراء البوت.
- `config/groups.json` معرفات المجموعات المسموح بها.
- `config/secrets.json` مفاتيح الخدمات الخاصة.

يمكن نقل هذه الملفات تلقائيا من النسخة القديمة الموجودة في `~/SunnaBOT/Sunna-Bot/config` عبر:

```bash
npm run migrate:local
```

مفاتيح الذكاء الاصطناعي توضع في `config/secrets.json`:

```json
{
  "puterAuthToken": "",
  "geminiApiKey": "",
  "groqApiKey": ""
}
```

غرف Gemini/Groq توضع في `config/config.json` داخل `ai.chatGroupIds`.

لا ترفع الملفات الحقيقية الى GitHub.
