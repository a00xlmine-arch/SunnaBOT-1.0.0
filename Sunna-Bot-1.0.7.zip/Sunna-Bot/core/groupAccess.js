const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/files');

class GroupAccess {
  constructor(root, initial = null) {
    this.file = path.join(root, 'config/groups.json');
    this.data = initial && typeof initial === 'object'
      ? initial
      : { mode: 'allowlist', allowedThreadIds: [] };
    this.writeLock = Promise.resolve();
  }

  async load() {
    const current = await readJson(this.file, this.data);
    this.data = current && typeof current === 'object' ? current : this.data;
    if (this.data.mode !== 'allowlist') throw new Error('config/groups.json يجب ان يستخدم mode=allowlist.');
    if (!Array.isArray(this.data.allowedThreadIds)) throw new Error('allowedThreadIds يجب ان تكون مصفوفة.');
    return this;
  }

  isAllowed(threadID) {
    return Boolean(threadID) && this.data.allowedThreadIds.map(String).includes(String(threadID));
  }

  async enable(threadID) {
    const id = String(threadID);
    if (!this.data.allowedThreadIds.map(String).includes(id)) this.data.allowedThreadIds.push(id);
    await this.#save();
  }

  async disable(threadID) {
    const id = String(threadID);
    this.data.allowedThreadIds = this.data.allowedThreadIds.filter(x => String(x) !== id);
    await this.#save();
  }

  #save() {
    this.writeLock = this.writeLock.then(() => writeJsonAtomic(this.file, this.data));
    return this.writeLock;
  }
}

module.exports = GroupAccess;
