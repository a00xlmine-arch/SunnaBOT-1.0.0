class QueueBusyError extends Error {
  constructor(message = 'المهمة مشغولة حاليا.') {
    super(message);
    this.name = 'QueueBusyError';
    this.code = 'QUEUE_BUSY';
  }
}

class TaskQueue {
  constructor(concurrency = 1, options = {}) {
    this.concurrency = Math.max(1, Number(concurrency) || 1);
    this.maxPending = options.maxPending === undefined ? Infinity : Math.max(0, Number(options.maxPending));
    this.running = 0;
    this.pending = [];
  }

  get pendingCount() { return this.pending.length; }
  get runningCount() { return this.running; }
  get busy() { return this.running > 0 || this.pending.length > 0; }

  add(task, options = {}) {
    if (typeof task !== 'function') return Promise.reject(new TypeError('Queue task must be a function.'));
    if (options.rejectIfBusy && this.busy) {
      return Promise.reject(new QueueBusyError(options.busyMessage || 'المهمة مشغولة حاليا.'));
    }
    if (this.pending.length >= this.maxPending) {
      return Promise.reject(new QueueBusyError(options.busyMessage || 'طابور المهام ممتلئ حاليا.'));
    }
    return new Promise((resolve, reject) => {
      this.pending.push({ task, resolve, reject });
      this.#drain();
    });
  }

  async #drain() {
    while (this.running < this.concurrency && this.pending.length) {
      const item = this.pending.shift();
      this.running += 1;
      Promise.resolve()
        .then(item.task)
        .then(item.resolve, item.reject)
        .finally(() => {
          this.running -= 1;
          this.#drain();
        });
    }
  }
}

module.exports = TaskQueue;
module.exports.QueueBusyError = QueueBusyError;
