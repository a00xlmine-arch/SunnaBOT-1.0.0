const path = require('path');
const { readJson } = require('../utils/files');

function uniqueStrings(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(String).filter(Boolean))];
}

async function loadConfig(root) {
  const config = await readJson(path.join(root, 'config/config.json'), null);
  const appState = await readJson(path.join(root, config?.facebook?.appStateFile || 'config/appstate.json'), null);
  const secrets = await readJson(path.join(root, 'config/secrets.json'), null);
  const adminsFile = await readJson(path.join(root, 'config/admins.json'), null);
  const groupsFile = await readJson(path.join(root, 'config/groups.json'), null);

  if (!config) throw new Error('config/config.json غير موجود.');
  if (!Array.isArray(appState) || appState.length === 0) throw new Error('config/appstate.json يجب ان يحتوي على AppState صالح.');
  if (!secrets || typeof secrets !== 'object') throw new Error('config/secrets.json غير موجود او غير صالح.');
  if (!adminsFile || !Array.isArray(adminsFile.adminIds)) throw new Error('config/admins.json يجب ان يحتوي على adminIds.');
  if (!groupsFile || !Array.isArray(groupsFile.allowedThreadIds)) throw new Error('config/groups.json غير صالح.');

  const inlineAdmins = uniqueStrings(config.facebook?.adminIds);
  const inlineGroups = uniqueStrings(config.facebook?.groupIds);
  const adminIds = inlineAdmins.length ? inlineAdmins : uniqueStrings(adminsFile.adminIds);
  const allowedThreadIds = inlineGroups.length ? inlineGroups : uniqueStrings(groupsFile.allowedThreadIds);

  config.version = '1.0.7';
  config.timezone = 'Asia/Riyadh';
  config.schedules = { ...(config.schedules || {}), morning: '08:00', night: '23:00', prayerReminders: true, hourly: true, hourlyMinute: '30' };
  config.prayer = { ...(config.prayer || {}), city: 'Makkah', country: 'Saudi Arabia', method: 4 };
  config.ai = {
    enabled: true,
    provider: 'auto',
    chatGroupIds: [],
    geminiModel: 'gemini-3.8-flash',
    groqModel: 'openai/gpt-oss-20b',
    maxHistory: 12,
    maxOutputTokens: 180,
    maxReplyLength: 360,
    requestTimeoutMs: 20000,
    cooldownMs: 2500,
    ...(config.ai || {})
  };
  config.queues = { image: 1, music: 1, default: 2, ...(config.queues || {}) };

  return {
    config,
    credentials: {
      appState,
      puterAuthToken: String(secrets.puterAuthToken || ''),
      geminiApiKey: String(secrets.geminiApiKey || ''),
      groqApiKey: String(secrets.groqApiKey || '')
    },
    admins: { adminIds },
    groups: { mode: 'allowlist', allowedThreadIds }
  };
}

module.exports = { loadConfig };
