const axios = require('axios');
const { searchPinterest } = require('@hiudyy/ytdl');
const { getJimp } = require('../utils/imageCodec');

const PINTEREST_HEADERS = {
  Accept: 'application/json,text/plain,*/*',
  'X-Pinterest-AppState': 'active',
  'X-Pinterest-Source-Url': '/search/pins/',
  'X-Pinterest-PWS-Handler': 'www/search.js',
  Referer: 'https://www.pinterest.com/'
};

const BLOCKED_METADATA = /(?:gradient|solid\s+color|color\s+gradient|abstract\s+background|plain\s+background|wallpaper|lockscreen|background|aesthetic|collage|template|banner|icon|pfp|profile\s+picture|edit|meme)/i;

function normalizeText(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[\u0640]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

function tokens(value) {
  return [...new Set(normalizeText(value).split(/\s+/u).filter(token => token.length >= 2))];
}

function textRelevance(query, candidate) {
  const q = tokens(query);
  if (!q.length) return 0;
  const exact = normalizeText(query);
  const title = normalizeText(candidate?.title);
  const description = normalizeText(candidate?.description);
  const author = normalizeText(candidate?.author);
  const link = normalizeText(candidate?.link);
  const text = [title, description, author, link].join(' ');
  if (BLOCKED_METADATA.test(text)) return 0;

  let score = 0;
  let matched = 0;
  for (const token of q) {
    if (title.includes(token)) { score += 40; matched += 1; continue; }
    if (description.includes(token)) { score += 25; matched += 1; continue; }
    if (text.includes(token)) { score += 12; matched += 1; }
  }
  if (exact.length >= 3 && title.includes(exact)) score += 55;
  if (q.length > 1 && matched === q.length) score += 35;
  return Math.min(160, score);
}

async function pinterestResourceSearch(term, limit = 30) {
  const data = encodeURIComponent(JSON.stringify({
    options: { query: term, bookmarks: [''] },
    context: {}
  }));

  const response = await axios.get(
    `https://www.pinterest.com/resource/BaseSearchResource/get/?data=${data}`,
    {
      headers: PINTEREST_HEADERS,
      timeout: 20_000,
      responseType: 'json',
      validateStatus: status => status >= 200 && status < 300
    }
  );

  const raw = response.data?.resource_response?.data?.results;
  if (!Array.isArray(raw)) return [];
  const results = [];

  for (const item of raw) {
    if (!item || item.type === 'story') continue;
    const image = item.images?.orig || item.images?.['736x'];
    if (!image?.url || !/^https?:\/\/[^\s]+$/i.test(String(image.url))) continue;
    results.push({
      url: String(image.url),
      title: String(item.title || item.grid_title || ''),
      description: String(item.description || item.rich_summary?.display_description || ''),
      author: String(item.pinner?.full_name || item.pinner?.username || ''),
      link: String(item.link || (item.id ? `https://www.pinterest.com/pin/${item.id}/` : '')),
      width: Number(image.width || 0),
      height: Number(image.height || 0)
    });
    if (results.length >= limit) break;
  }
  return results;
}

async function safeLegacySearch(term, limit = 30) {
  try {
    const urls = await searchPinterest(term, { limit });
    return Array.isArray(urls)
      ? urls
        .filter(url => /^https?:\/\//i.test(String(url)))
        .map(url => ({ url: String(url), title: '', description: '', author: '', link: '' }))
      : [];
  } catch (_) {
    return [];
  }
}

function uniqueCandidates(items) {
  const map = new Map();
  for (const item of items) {
    const url = String(item?.url || '').split('#')[0];
    if (!/^https?:\/\/.*pinimg\.com\//i.test(url) || map.has(url)) continue;
    map.set(url, { ...item, url });
  }
  return [...map.values()];
}

async function search(query, limit = 18) {
  const value = String(query || '').trim();
  if (!value) throw new Error('اكتب ما تريد البحث عنه بعد الامر.');

  const terms = [
    value,
    `${value} character`,
    `${value} character portrait`,
    `${value} anime character`,
    `${value} official art`,
    `${value} clean portrait`
  ];
  const detailedGroups = await Promise.all(terms.map(term => pinterestResourceSearch(term, 24).catch(() => [])));
  const detailed = detailedGroups.flat();

  let candidates = uniqueCandidates(detailed).map(item => ({ ...item, source: 'resource' }));
  if (!candidates.length) {
    const legacyGroups = await Promise.all(terms.map(term => safeLegacySearch(term, 24).catch(() => [])));
    candidates = uniqueCandidates(legacyGroups.flat()).map(item => ({ ...item, source: 'legacy' }));
  }

  const ranked = candidates
    .map(item => {
      const relevance = textRelevance(value, item);
      const area = Number(item.width || 0) * Number(item.height || 0);
      return { ...item, relevance, area };
    })
    .sort((a, b) => b.relevance - a.relevance || b.area - a.area);

  const threshold = tokens(value).length > 1 ? 55 : 35;
  const strict = ranked.filter(item => item.relevance >= threshold);
  const usable = strict.length ? strict : ranked.filter(item => item.source !== 'legacy');
  return usable.slice(0, Math.max(1, Math.min(24, Number(limit) || 18)));
}

async function imageQuality(filePath) {
  try {
    const Jimp = await getJimp();
    const image = await Jimp.read(filePath);
    const { width, height, data } = image.bitmap;
    const pixels = width * height;
    if (width < 300 || height < 300 || pixels > 18_000_000) return -1;

    const ratio = width / height;
    if (ratio < 0.45 || ratio > 2.3) return -1;

    const stepX = Math.max(1, Math.floor(width / 32));
    const stepY = Math.max(1, Math.floor(height / 32));
    let edgeSum = 0;
    let edgeSamples = 0;
    let lumSum = 0;
    let lumSq = 0;
    let samples = 0;

    const luminance = (x, y) => {
      const index = ((y * width) + x) * 4;
      return (0.2126 * data[index]) + (0.7152 * data[index + 1]) + (0.0722 * data[index + 2]);
    };

    for (let y = 0; y < height - stepY; y += stepY) {
      for (let x = 0; x < width - stepX; x += stepX) {
        const here = luminance(x, y);
        const right = luminance(Math.min(width - 1, x + stepX), y);
        const down = luminance(x, Math.min(height - 1, y + stepY));
        const delta = Math.abs(here - right) + Math.abs(here - down);
        edgeSum += delta;
        edgeSamples += 2;
        lumSum += here;
        lumSq += here * here;
        samples += 1;
      }
    }

    if (!edgeSamples || !samples) return -1;
    const averageDelta = edgeSum / edgeSamples;
    const variance = Math.max(0, (lumSq / samples) - Math.pow(lumSum / samples, 2));
    if (averageDelta < 4.5 || (averageDelta < 7 && variance < 120)) return -1;

    const edgeScore = Math.min(70, averageDelta * 2.2);
    const sizeScore = Math.min(30, Math.log10(Math.max(1, pixels)) * 4.2);
    return Math.round(edgeScore + sizeScore);
  } catch (_) {
    return -1;
  }
}

module.exports = { search, imageQuality, normalizeText, textRelevance };
