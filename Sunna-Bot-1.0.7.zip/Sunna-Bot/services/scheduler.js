const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/files');
const prayer = require('./prayer');

const HOURLY_MESSAGES = [
  'الجو جميل اليوم.',
  'اشعر بالنعاس قليلا.',
  'انا متعبة شوي.',
  'احتاج قهوة فعلا.',
  'اليوم هادئ بشكل غريب.',
  'احب هدوء الليل.',
  'اشعر ان الوقت يمر بسرعة.',
  'اريد شيئا لذيذا الان.',
  'مزاجي هادئ اليوم.',
  'احتاج اغير جو قليلا.',
  'الموسيقى مزاجها مضبوط اليوم.',
  'اشعر انني اريد النوم ثم لا انام.',
  'الجو مناسب للسهر.',
  'لحظة... ماذا كنت افكر فيه؟',
  'انا جائعة مرة اخرى.',
  'اشعر بالكسل اليوم.',
  'هذه الساعة مرت بسرعة.',
  'احتاج استراحة صغيرة.',
  'انا بخير، فقط نعسانة.',
  'احب اللحظات الهادئة.',
  'اتمنى اليوم ما ينتهي بسرعة.',
  'مزاجي يحتاج موسيقى.',
  'اشعر بالراحة قليلا.',
  'اين اختفت القهوة؟',
  'اليوم يحتاج شيئا ممتعا.',
  'انا ساكتة اليوم بشكل مريب.',
  'اشعر انني احتاج ضحكة.',
  'الجو فعلا لطيف.',
  'انا محتارة ماذا افعل.',
  'السهر له جو خاص.',
  'اشعر بالهدوء اكثر من اللازم.',
  'ربما احتاج ان امشي قليلا.',
  'انا في مزاج جيد.',
  'الليل اليوم جميل.',
  'اشعر انني احتاج حضنا دافئا.',
  'اليوم مرهق بصراحة.',
  'اريد يوم اجازة من كل شيء.',
  'انا فضولية اعرف ماذا يحدث.',
  'اشعر انني اريد اللعب.',
  'مزاجي يريد شيئا عشوائيا.',
  'يبدو انني ساسهر مرة اخرى.'
];

function nowParts(timeZone) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());
  return Object.fromEntries(parts.filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
}

class Scheduler {
  constructor(bot) {
    this.bot = bot;
    this.timer = null;
    this.stateFile = path.join(bot.root, 'data/scheduleState.json');
    this.state = {};
  }

  async load() {
    this.state = await readJson(this.stateFile, {});
    if (!this.state || typeof this.state !== 'object' || Array.isArray(this.state)) this.state = {};
    return this;
  }

  async save() { await writeJsonAtomic(this.stateFile, this.state); }

  async start() {
    await this.load();
    if (this.timer) return;
    this.timer = setInterval(() => this.tick().catch(err => this.bot.logger.error({ err }, 'scheduler tick failed')), 20_000);
    this.timer.unref?.();
    await this.tick();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  async tick() {
    const tz = this.bot.config.timezone || 'Asia/Riyadh';
    const p = nowParts(tz);
    const date = `${p.year}-${p.month}-${p.day}`;
    const hm = `${p.hour}:${p.minute}`;

    await this.simpleSchedule(date, hm, 'morning', 'صباح الخير جميعا.\n\nاتمنى لكم يوما جميلا وهادئا.');
    await this.simpleSchedule(date, hm, 'night', 'تصبحون على خير جميعا.\n\nاتمنى لكم ليلة هادئة.');
    await this.hourlySchedule(date, hm);

    if (this.bot.config.schedules?.prayerReminders !== false) {
      try {
        await this.prayerTick(date, hm);
      } catch (error) {
        this.bot.logger.warn({ err: error }, 'prayer scheduler failed');
      }
    }
  }

  async simpleSchedule(date, hm, key, message) {
    const target = this.bot.config.schedules?.[key];
    if (target !== hm) return;
    let changed = false;
    for (const threadID of this.bot.groupAccess.data.allowedThreadIds.map(String)) {
      const stateKey = `${date}:${key}:${threadID}`;
      if (this.state[stateKey]) continue;
      try {
        await this.bot.messenger.sendMessage(message, threadID);
        this.state[stateKey] = true;
        changed = true;
      } catch (error) {
        this.bot.logger.warn({ err: error, threadID, key }, 'scheduled message failed');
      }
    }
    if (changed) await this.save();
  }

  pickHourlyMessage(threadID) {
    const key = `hourly:last:${threadID}`;
    const last = Number(this.state[key]);
    let index = Math.floor(Math.random() * HOURLY_MESSAGES.length);
    if (HOURLY_MESSAGES.length > 1 && Number.isInteger(last) && index === last) {
      index = (index + 1 + Math.floor(Math.random() * (HOURLY_MESSAGES.length - 1))) % HOURLY_MESSAGES.length;
    }
    this.state[key] = index;
    return HOURLY_MESSAGES[index];
  }

  async hourlySchedule(date, hm) {
    if (this.bot.config.schedules?.hourly === false) return;
    const minute = String(this.bot.config.schedules?.hourlyMinute || '30').padStart(2, '0');
    if (hm.slice(-2) !== minute) return;

    let changed = false;
    const hourKey = hm.slice(0, 2);
    for (const threadID of this.bot.groupAccess.data.allowedThreadIds.map(String)) {
      const stateKey = `${date}:hourly:${hourKey}:${threadID}`;
      if (this.state[stateKey]) continue;
      try {
        await this.bot.messenger.sendMessage(this.pickHourlyMessage(threadID), threadID);
        this.state[stateKey] = true;
        changed = true;
      } catch (error) {
        this.bot.logger.warn({ err: error, threadID }, 'hourly message failed');
      }
    }
    if (changed) await this.save();
  }

  async prayerTick(date, hm) {
    const timings = await prayer.getToday();
    let changed = false;
    for (const [key, time] of Object.entries(timings)) {
      if (!/^\d{2}:\d{2}$/.test(time) || time !== hm) continue;
      const name = prayer.NAMES[key] || key;
      for (const threadID of this.bot.groupAccess.data.allowedThreadIds.map(String)) {
        const stateKey = `${date}:prayer:${key}:${threadID}`;
        if (this.state[stateKey]) continue;
        try {
          await this.bot.messenger.sendMessage(`حان وقت صلاة ${name}.\nبتوقيت مكة المكرمة.`, threadID);
          this.state[stateKey] = true;
          changed = true;
        } catch (error) {
          this.bot.logger.warn({ err: error, threadID, key }, 'prayer reminder failed');
        }
      }
    }
    if (changed) await this.save();
  }
}

module.exports = Scheduler;
module.exports.HOURLY_MESSAGES = HOURLY_MESSAGES;
