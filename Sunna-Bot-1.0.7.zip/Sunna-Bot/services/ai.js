const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/files');
const { sanitizeReply } = require('./sunnaPersonality');
const { SYSTEM_INSTRUCTION } = require('./sunnaPersonality');

function nonEmpty(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function cleanHistory(items, maxHistory) {
  return (Array.isArray(items) ? items : []).slice(-Math.max(2, Number(maxHistory) || 12));
}

function normalizeProvider(value) {
  const provider = String(value || 'auto').toLowerCase();
  return ['auto', 'gemini', 'groq'].includes(provider) ? provider : 'auto';
}

function replySenderID(event) {
  const target = event?.replyTarget;
  return target?.senderID || target?.senderId || target?.senderFbId || target?.userID || target?.author || target?.uid || null;
}

function isDirectReplyToBot(event, botUserId) {
  if (!event?.replyTarget || !botUserId) return false;
  const sender = replySenderID(event);
  return sender !== null && String(sender) === String(botUserId);
}

function historyForGemini(history, userText, userName) {
  const transcript = [];
  for (const entry of cleanHistory(history, 12)) {
    const text = String(entry?.text || '').trim();
    if (!text) continue;
    const role = entry.role === 'model' ? 'سونا' : (entry.name || 'عضو');
    transcript.push(`${role}: ${text}`);
  }
  transcript.push(`${userName || 'عضو'}: ${String(userText || '').trim()}`);
  return transcript.join('\n');
}

function historyForGroq(history, userText, userName) {
  const items = cleanHistory(history, 12).map(entry => ({
    role: entry.role === 'model' ? 'assistant' : 'user',
    content: String(entry?.text || '')
  })).filter(entry => entry.content);
  items.push({ role: 'user', content: `${userName || 'عضو'}: ${userText}` });
  return items;
}

async function withTimeout(promise, timeoutMs, label) {
  const timeout = Math.max(1000, Number(timeoutMs) || 20000);
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timeout`)), timeout);
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
}

class AIService {
  constructor(bot) {
    this.bot = bot;
    this.file = path.join(bot.root, 'data/ai-conversations.json');
    this.configFile = path.join(bot.root, 'config/config.json');
    this.data = {};
    this.lastRequest = new Map();
    this.busy = new Set();
    this.gemini = null;
    this.groq = null;
    this.configWriteLock = Promise.resolve();
  }

  async load() {
    this.data = await readJson(this.file, {});
    if (!this.data || typeof this.data !== 'object' || Array.isArray(this.data)) this.data = {};
    return this;
  }

  isRoom(threadID) {
    const cfg = this.bot.config.ai || {};
    if (cfg.enabled === false) return false;
    const rooms = Array.isArray(cfg.chatGroupIds) ? cfg.chatGroupIds.map(String).filter(Boolean) : [];
    return rooms.includes(String(threadID));
  }

  hasProvider(key) { return nonEmpty(key); }

  providerOrder() {
    const configured = normalizeProvider(this.bot.config.ai?.provider);
    if (configured === 'gemini') return ['gemini', 'groq'];
    if (configured === 'groq') return ['groq', 'gemini'];
    return this.hasProvider(this.bot.credentials?.geminiApiKey)
      ? ['gemini', 'groq']
      : ['groq', 'gemini'];
  }

  async getName(uid) {
    try {
      const user = await this.bot.profile.getUser(uid);
      return user?.name || String(uid);
    } catch (_) {
      return String(uid);
    }
  }

  async generateGemini(history, userText, userName) {
    const key = this.bot.credentials?.geminiApiKey;
    if (!this.hasProvider(key)) throw new Error('GEMINI_API_KEY غير مضبوط.');
    if (!this.gemini) {
      const mod = require('@google/genai');
      const GoogleGenAI = mod.GoogleGenAI || mod.default?.GoogleGenAI || mod.default || mod;
      if (typeof GoogleGenAI !== 'function') throw new Error('تعذر تحميل مكتبة Gemini.');
      this.gemini = new GoogleGenAI({ apiKey: key });
    }

    const interaction = await withTimeout(this.gemini.interactions.create({
      model: String(this.bot.config.ai?.geminiModel || 'gemini-3.8-flash'),
      input: historyForGemini(history, userText, userName),
      system_instruction: SYSTEM_INSTRUCTION,
      generation_config: {
        max_output_tokens: Number(this.bot.config.ai?.maxOutputTokens || 180),
        thinking_level: 'low'
      },
      store: false
    }), Number(this.bot.config.ai?.requestTimeoutMs || 20000), 'Gemini');

    const text = String(interaction?.output_text || '').trim();
    if (!text) throw new Error('Gemini لم يرجع نصا.');
    return text;
  }

  async generateGroq(history, userText, userName) {
    const key = this.bot.credentials?.groqApiKey;
    if (!this.hasProvider(key)) throw new Error('GROQ_API_KEY غير مضبوط.');
    if (!this.groq) {
      const mod = require('groq-sdk');
      const Groq = mod.Groq || mod.default?.Groq || mod.default || mod;
      if (typeof Groq !== 'function') throw new Error('تعذر تحميل مكتبة Groq.');
      this.groq = new Groq({ apiKey: key });
    }

    const completion = await withTimeout(this.groq.chat.completions.create({
      model: String(this.bot.config.ai?.groqModel || 'openai/gpt-oss-20b'),
      max_tokens: Number(this.bot.config.ai?.maxOutputTokens || 180),
      reasoning_effort: 'low',
      messages: [
        { role: 'system', content: SYSTEM_INSTRUCTION },
        ...historyForGroq(history, userText, userName)
      ]
    }), Number(this.bot.config.ai?.requestTimeoutMs || 20000), 'Groq');

    const text = String(completion?.choices?.[0]?.message?.content || '').trim();
    if (!text) throw new Error('Groq لم يرجع نصا.');
    return text;
  }

  async generate(history, userText, userName) {
    const errors = [];
    for (const provider of this.providerOrder()) {
      try {
        if (provider === 'gemini') return { provider, text: await this.generateGemini(history, userText, userName) };
        return { provider, text: await this.generateGroq(history, userText, userName) };
      } catch (error) {
        errors.push(`${provider}: ${error?.message || 'unknown error'}`);
      }
    }
    throw new Error(errors.join(' | ') || 'لا يوجد مزود AI صالح.');
  }

  async save() {
    await writeJsonAtomic(this.file, this.data);
  }

  async setRoom(threadID, enabled) {
    const id = String(threadID);
    const rooms = Array.isArray(this.bot.config.ai?.chatGroupIds)
      ? this.bot.config.ai.chatGroupIds.map(String).filter(Boolean)
      : [];
    const exists = rooms.includes(id);
    if (enabled && !exists) rooms.push(id);
    if (!enabled && exists) rooms.splice(rooms.indexOf(id), 1);
    this.bot.config.ai.chatGroupIds = [...new Set(rooms)];

    this.configWriteLock = this.configWriteLock.then(() => writeJsonAtomic(this.configFile, this.bot.config));
    await this.configWriteLock;
    return enabled ? !exists : exists;
  }

  roomCount() {
    return Array.isArray(this.bot.config.ai?.chatGroupIds) ? this.bot.config.ai.chatGroupIds.length : 0;
  }

  async handle(event) {
    if (!this.isRoom(event.threadID)) return false;

    // AI is strictly reply-based: only a reply to a message sent by this bot is a trigger.
    if (!isDirectReplyToBot(event, this.bot.botUserId)) return false;

    const body = String(event.body || '').trim();
    if (!body || body.startsWith(this.bot.config.prefix)) return false;

    const threadID = String(event.threadID);
    const senderID = String(event.senderID);
    const cooldown = Math.max(0, Number(this.bot.config.ai?.cooldownMs || 2500));
    const now = Date.now();
    const last = this.lastRequest.get(`${threadID}:${senderID}`) || 0;
    if (now - last < cooldown) return true;
    this.lastRequest.set(`${threadID}:${senderID}`, now);

    // Never build a backlog of AI replies inside a group.
    if (this.busy.has(threadID)) return true;
    this.busy.add(threadID);

    try {
      const userName = await this.getName(senderID);
      const history = cleanHistory(this.data[threadID], this.bot.config.ai?.maxHistory || 12);
      const result = await this.generate(history, body, userName);
      const reply = sanitizeReply(result.text, Number(this.bot.config.ai?.maxReplyLength || 360));
      if (!reply) throw new Error('AI لم يرجع ردا صالحا.');

      const threadHistory = Array.isArray(this.data[threadID]) ? this.data[threadID] : [];
      threadHistory.push({ role: 'user', name: userName, text: body, at: new Date().toISOString() });
      threadHistory.push({ role: 'model', name: 'Sunna', text: reply, provider: result.provider, at: new Date().toISOString() });
      this.data[threadID] = cleanHistory(threadHistory, this.bot.config.ai?.maxHistory || 12);
      await this.save();
      await this.bot.messenger.sendMessage(reply, threadID);
      return true;
    } catch (error) {
      this.bot.logger.warn({ err: error, threadID }, 'AI response failed');
      await this.bot.messenger.sendMessage('سونا علقت شوي، جرب ترسلها مرة ثانية.', threadID).catch(() => {});
      return true;
    } finally {
      this.busy.delete(threadID);
    }
  }
}

module.exports = AIService;
module.exports.cleanHistory = cleanHistory;
module.exports.historyForGemini = historyForGemini;
module.exports.historyForGroq = historyForGroq;
module.exports.isDirectReplyToBot = isDirectReplyToBot;
